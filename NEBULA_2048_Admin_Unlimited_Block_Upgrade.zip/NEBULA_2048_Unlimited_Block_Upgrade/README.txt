NEBULA 2048 — BigInt Edition

1. Giữ index.html, ui-icons.js, animation.js, animation.css, bagua-aura-3d.js, background-settings.js và adminpanel.js cùng các thư mục assets, css, js, electron trong cùng thư mục game.
2. Mở index.html bằng trình duyệt. Không đổi tên hai file animation nếu chưa sửa đường dẫn trong index.html.
3. Bảng Admin chỉ xuất hiện khi adminpanel.js có mặt.

Đợt sửa lỗi:
- Fix renderBoss khi đã hạ hết Boss. Bản cũ cố chuyển Infinity thành BigInt nên dừng khi tải game.
- Dữ liệu localStorage không bị reset bởi bản vá này.

Lưu ý: hãy sao lưu dữ liệu game trước khi thay file nếu tiến trình đang quan trọng.

COLOR AURA UPDATE (2026-10-24)
- Aura and animated multicolor tile-face gradient begin at 2048; values below 2048 keep their normal tile styling.
- Aura has 30 tiers. Every doubling raises the tier and increases the aura reach, glow strength, and motion speed.
- Additional layers unlock progressively: star dust (tier 3), energy rings (5), cosmic rays (7), orbiting plasma nodes (9), nebula flare (11), singularity ring (15), quantum ripple (20), and apotheosis flare (25).
- At tier 30 the strongest aura layer is active; the tile value is still handled as BigInt and visual tiers are calculated from its exponent.
- Reduced-motion preferences are respected. Game logic, BigInt number handling, save schema, and optional adminpanel.js loading are unchanged.

ANIMATION MODULES
- animation.css: toàn bộ CSS aura, keyframes và các lớp hiệu ứng. Thêm/chỉnh kiểu hiển thị ở đây.
- animation.js: logic cấp aura, bảng màu, ngưỡng mở khóa hiệu ứng và HTML các lớp hiệu ứng. Thêm cấp/lớp mới ở đây.
- 2048 mở khóa aura cấp 1; mỗi lần giá trị ô tăng gấp đôi thì cấp aura tăng một, tối đa cấp 30.
- Chạy test từ thư mục game bằng: node nebula2048.test.js

COSMIC BACKGROUND UPDATE (2026-10-24)
- Added a lightweight animated Canvas 2D backdrop inspired by MinhDz-Eight_Trigrams: shader-like code streams, multicolor cosmic dust, and slow rotating Bagua/orbital rings.
- The background sits behind the game UI, ignores pointer input, and does not require Three.js or any external library.
- Existing Effects setting controls its intensity: Low reduces it, Standard is balanced, Max increases density/glow, Off hides it.
- Background effects are implemented in animation.js and styled in animation.css; game logic and save data are unchanged.


BINARY AURA UPDATE (2026-10-24)
- Each aura-enabled tile emits glowing binary-code streams reading 01010011001.
- Binary visual effects unlock in separate ranks rather than bundling all code effects at 1M: 2048+ = rank 1 / one effect; 1M+ = rank 2 / two effects; 1B+ = rank 3 / four effects; 1T+ = rank 4 / six effects; 1Qa+ = rank 5 / eight effects.
- The extra layers unlock gradually: orbital binary ring (rank 2), digital rain + pulse ring (rank 3), flying bit fragments + glyphs (rank 4), circuit frame + binary core (rank 5).
- Higher ranks continue increasing stream count (up to 28), spread distance, glow, and motion; the eight distinct effect layers are retained and strengthen at higher values.
- Effects Off hides tile aura layers, Low reduces their intensity, and reduced-motion preference disables the animation loop.
- No external assets or libraries are required.


CÀI ĐẶT NỀN MỚI (BÁT QUÁI / NGŨ HÀNH)
- Mục "Cài đặt nền & không gian" nằm trong Thống kê & cài đặt.
- Chọn kiểu nền: Vũ trụ đầy đủ, 3D, mã chạy, bụi sao hoặc tắt.
- Có thể đổi hệ Bát Quái/Ngũ Hành, 6 bảng màu, chất lượng nền, độ nổi, độ rõ mã và ảnh nền riêng.
- Cấu hình nền được lưu độc lập với save game tại localStorage trên máy hiện tại.
- background.html chạy trong iframe riêng để tránh xung đột JavaScript với game 2048.
- Giữ các thư mục assets, css, electron, js cạnh index.html; không cần mở background.html trực tiếp.


BACKGROUND CLEANUP (2026-10-25)
- Removed the old full-screen Canvas 2D background from animation.js and its CSS selectors.
- Removed the old static multi-gradient body background; a plain dark color remains only as fallback.
- background.html (the configurable Bagua/Wuxing 3D background) is now the sole animated scene background.
- Tile aura, progressive binary effects, and game logic are unchanged.


BACKGROUND THEME PRESETS (2026-10-25)
- Added 10 full-color animated CSS atmospheric backdrops: Tinh Van, Cuc Quang, Thien Ha, Hai Vuc, Liet Diem, Hoa Anh Dao, Rung Ngoc, Cyberpunk, Hoang Kim, and Han Bang.
- The background picker uses visual swatches; selections persist separately from the game save.
- The opacity slider remains a separate overall background-strength control; the theme presets control actual hue and gradient style.
- The Three.js canvas clear alpha is reduced in the embedded background bridge so the selected color atmospheres remain visible behind the 3D orbital scene.
- No remote assets or additional libraries were added.


AURA MATRIX + NEW FAMILIES (2026-10-25)
- Added a persisted "Phong cách aura quanh khối" selector: Auto Evolution, Matrix, Plasma, Inferno, Frost, Arcane, Void, Cyber Glitch, Solaris, and Celestial.
- Matrix aura produces glowing falling binary columns around aura tiles. Selecting Matrix makes it visible starting at 2048; Auto Evolution unlocks Matrix at tier 2 while preserving the evolving rainbow palette at tier 1.
- New cumulative aura layers unlock progressively: electric plasma (tier 4), frost crystals (6), drifting embers (8), arcane runes (10), RGB glitch (12), black-hole lens (14), spectral wings (18), solar halo (22), and fractal corona (27). Existing binary, star, ring, ray, nebula, quantum, and apotheosis effects remain.
- All layers remain behind the number text and ignore pointer input. Effects Off hides the layers; Low reduces their intensity. The selected aura palette is saved in the background-settings preferences, separate from game save data.
- No third-party libraries or image assets were added for these aura families.


ULTIMATE 3D BAGUA TILE AURA (2026-10-25)
- A spectacular Bát Quái aura unlocks once any tile reaches or exceeds exactly 10^306, evaluated with BigInt (no Number precision loss).
- The game commonly doubles tiles, so the aura appears on the first tile value that crosses this threshold and remains active for larger tiles.
- bagua-aura-3d.js renders one shared transparent Three.js/WebGL overlay for all eligible tiles, with multiple tilted octagonal rings, counter-rotating planes, eight orbiting trigram symbols, flying energy particles, orbital pearls, and a rotating Taiji seal centered over the tile at low opacity so the value stays readable.
- The 3D scene is activated only while at least one eligible tile is visible; this avoids running a permanent WebGL animation for ordinary games. If WebGL is unavailable, the layered CSS 3D fallback in animation.css remains visible.
- The regular high-tier auras remain cumulative. Effects Off hides the Bagua aura; Low reduces its intensity; reduced-motion settings reduce motion.
- The exact BigInt threshold and fallback markup live in animation.js; CSS 3D styling/keyframes live in animation.css; real rotating 3D scene logic lives in bagua-aura-3d.js.
- Regression tests explicitly check values below, at, and above 10^306 and the presence of the Three.js renderer.


CINEMATIC BAGUA AURA EVOLUTION (2026-10-25)
- Reworked the 10-tier Bagua ladder using exact BigInt decimal magnitude. The aura starts at 1e306 and advances each 100 decimal exponents: 1e406 is tier 2, up to 1e1206 tier 10.
- At 1e1306, evolution advances to Càn Khôn Bát Quái (tier 1 of 10) without visual regression; the cumulative aura-rank continues from 11 through 20 at 1e2206.
- At 1e2306, the Vô Cực Càn Khôn phase begins at cumulative rank 21. Additional 100-exponent milestones continue adding orbital rings, trigrams, crystals, energy rays, pearls, runes, and star fields up to rank 30.
- The shared WebGL/Three.js scene now responds to each tile's Bagua rank and phase. New visual modules are added cumulatively; phase changes also shift the scene palette. CSS 3D fallback has extra tier rings if WebGL is unavailable.
- The Taiji symbol sits at the center of the tile at ~22% opacity to preserve readability of the tile number. Ring and label geometry remain around it; the number itself is unchanged.
- BigInt value logic, save format, the background setting iframe, aura selectors, and core gameplay are unchanged. Test tiers: 1e306, 1e406, 1e1206, 1e1306, 1e2206, 1e2306.


FLEX KHỐI UPDATE (2026-10-25)
- Clicking “Flex khối” enters selection mode. Click any occupied board tile to open a centered full-screen focus view; empty cells are rejected.
- The selected tile is rendered with its current value and progression-based aura, including the Bagua aura extras when the 1e306 threshold is reached.
- Drag with the left mouse button to rotate the entire model in X/Y. Hold Shift while dragging to roll around Z; the mouse wheel zooms and double-click/reset restores the default view.
- The view blocks gameplay movement while open. Escape or “Quay lại game” closes it. No tile value, score, or save state is modified by Flex view.
- The view uses CSS 3D transforms and the same aura visual metadata, so it remains interactive without requiring a separate WebGL renderer for the selected block.


FLEX MODE (ROTATABLE TILE)
- Click "Flex khối", then click any occupied tile.
- The selected tile and its aura are shown centered in a full-screen focus view.
- Drag with the left mouse button to rotate X/Y; Shift+drag rolls around Z.
- Use the mouse wheel to zoom and double-click or the reset button to reset view.
- Press Escape or "Quay lại game" to close. This is a visual-only view and does not change game progress.


FLEX VIEW VISUAL FIX (2026-10-25)
- Fixed the selected tile drifting away from the model center: positioning now explicitly pins the tile to 50%/50% and uses a stable translate3d transform that cannot be overridden by regular tile animations.
- Long scientific-notation values auto-fit into a single line instead of wrapping at the end of the tile.
- The Flex view now shows its own CSS 3D Bagua rings and eight trigrams even while the board's separate WebGL overlay is active; the duplicate generic trigram badges are hidden.
- Reduced the overexposed circular nebula glow and removed generic multicolor pseudo-rings from the ultimate Bagua view so the octagonal rings, energy lines, and glyph orbit are easier to see.
- Moved the Taiji seal to the tile center at low opacity while keeping the number readable.
- Tested with: node nebula2048.test.js; JavaScript syntax checks; CSS parser; local-resource path check.

PERFORMANCE NOTES (Flex Rotatable optimized build)
--------------------------------------------------
- The bundled Three.js library remains local; the game does not need a CDN or network connection.
- The decorative Bagua background renders at a bounded 24/30/40 FPS by quality preset, and pauses while the app tab is hidden or the Flex overlay covers it.
- The large-tile Bagua aura overlay is capped at 30 FPS, uses a lower capped device-pixel ratio, reuses cached canvas layout and avoids per-frame computed-style/layout reads.
- The Flex overlay suspends the hidden background renderer and pauses tile animations behind it. All effect layers remain in the project and resume when Flex closes.


FLEX MAX-AURA OUT-OF-MEMORY GUARD (2026-10-25)
- When Flex opens, the game's Bagua WebGL overlay now disposes cached textures, materials, geometry, render lists, and its WebGL context instead of only hiding the canvas. The resources are recreated only if the board needs them again.
- The separate background iframe is unloaded while Flex is open, releasing its own Three.js/WebGL context and particle buffers; the saved settings are reapplied when returning to the game.
- Flex keeps every aura family and the Bagua CSS effects, but removes expensive large drop-shadow/filter compositing and per-stream forced GPU promotion only within Flex. The ordinary board retains its full visual styling.
- Flex preview caps binary code streams at 12 rather than 28 independent animated text layers; the normal board still uses all 28 at the highest binary level.
- Identical star-cloud geometry is now shared across tile positions instead of cached separately by board index.
- Regression checks cover resource disposal, iframe release/resume, and the Flex stream budget. This reduces peak GPU memory pressure; actual OOM prevention still depends on browser/driver/device memory limits.

Flex Bát Quái alignment patch (2026-10-25)
- Flex's full-size aura layer now uses a centered CSS grid to anchor the selected tile.
- The Bagua overlay is explicitly centered at 50%/50% with fixed proportional dimensions,
  eliminating the prior dependency on negative inset sizing for large aura stages.
- The patch is CSS-only and adds no WebGL renderer, mesh, particle, or memory allocation.

FLEX 3D CENTER LOCK PATCH (2026-10-25)
- Replaced the grid-flow tile placement with a fixed absolute 50%/50% anchor inside the full-size Flex aura cell.
- The centered tile no longer receives a Z-only translation while the surrounding CSS 3D Bagua layers rotate under perspective; both share the same center origin.
- The Bagua wrapper uses the same full-size coordinate plane and is centered by translate(-50%, -50%), preventing the 3D rings from appearing offset from the tile.
- This is CSS-only and does not allocate new WebGL resources, particles, or meshes; the existing OOM protections remain active.

STAGE IV — BLACK HOLE AURA (2026-10-25)
--------------------------------------
- At 1e3306, the progression replaces the complete Vô Cực Càn Khôn appearance with a dedicated Black Hole aura. The older trigram/seal decorations are not layered under or over the new effect.
- The Black Hole scene uses a dark event horizon, multi-layer accretion disks, photon rings, gravitational-lensing arcs, twin plasma jets, orbiting light beads, and a star field. Rings and disks rotate independently to create a cinematic 3D silhouette.
- Stage IV begins at level 1 at 1e3306; the level rises every 100 decimal exponents, reaching level 10 at 1e4206. Later magnitudes remain in the Black Hole family rather than falling back to Vô Cực.
- The game uses exact BigInt magnitude checks for the stage threshold. Flex reuses the lightweight CSS-3D fallback instead of creating an additional WebGL context, preserving the existing Flex out-of-memory protections. Shared ring geometry and fixed-radius star-cloud geometry avoid unnecessary cache growth.
- The black hole's centered dark core keeps the selected tile value legible; the CSS fallback also works when WebGL is unavailable.


SVG UI + GOD MODE FIX (2026-10-25)
---------------------------------
- Replaced pictographic emoji UI icons with locally embedded SVG icons through ui-icons.js. The project has no external icon CDN dependency. Traditional Bagua trigram glyphs are retained as authentic symbols.
- God Mode now bypasses skill Mana costs and cooldowns, prevents gold/Essence deductions for upgrades and Perks, and displays free purchase states in the UI. The one-time Dimension Perk and level caps remain enforced intentionally.
- Admin Panel God Mode checkbox now calls the actual game setter, refreshes the panel state, and shows a confirmation.
- Admin Set Level now applies the clamped level to game state, clears EXP so a reward does not immediately overwrite it, refreshes the dashboard, and saves the game. Levels 10+ expand a 4x4 board to 5x5 when needed.
- Regression suite includes pictographic-emoji scanning for game UI/effects/Electron source (excluding the eight traditional Bagua trigram symbols), plus God Mode purchase, skill, and Set Level checks.
- Run `node nebula2048.test.js` inside the game folder to verify the main regression suite.


ADMIN SKILL — UNLIMITED-REPEAT TILE UPGRADE
------------------------------------------
- The optional Admin Panel now includes “Skill Admin · Nâng cấp khối tự do”. Enter how many doublings to apply, arm the skill, then click an occupied board tile.
- Each upgrade is an exact BigInt doubling (value << count), costs no Mana/gold/Essence, refreshes the active maximum-tile record, and is saved. Undo captures the board before the upgrade.
- Per action the count is capped at 100,000 to avoid freezing the browser while converting huge BigInts to display strings. Use it repeatedly as often as needed; there is no cumulative-use limit.
- Empty cells are rejected without exiting selection. Press Esc or use the Admin cancel button to cancel. Selecting Flex or another skill cancels the pending Admin targeting mode.
- Regression tests cover the Admin targeting API, selection markup, BigInt doubling arithmetic, undo/save path, and the safety limit.
