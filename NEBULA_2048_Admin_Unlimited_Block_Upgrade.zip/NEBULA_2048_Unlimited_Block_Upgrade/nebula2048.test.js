/* Offline regression tests for NEBULA 2048's persistent BigInt rules. Run: node nebula2048.test.js */
'use strict';
const fs = require('fs');
const assert = require('assert');
const source = fs.readFileSync('index.html', 'utf8');
const animation = fs.readFileSync('animation.js', 'utf8');
const animationCss = fs.readFileSync('animation.css', 'utf8');
const baguaAura3D = fs.readFileSync('bagua-aura-3d.js', 'utf8');
const backgroundSettings = fs.readFileSync('background-settings.js', 'utf8');
const backgroundBridge = fs.readFileSync('js/background-bridge.js', 'utf8');
const backgroundHtml = fs.readFileSync('background.html', 'utf8');
const backgroundCss = fs.readFileSync('background-settings.css', 'utf8');
const backgroundApp = fs.readFileSync('js/app.js', 'utf8');
const uiIcons = fs.readFileSync('ui-icons.js', 'utf8');
const adminPanel = fs.readFileSync('adminpanel.js', 'utf8');
const electronMain = fs.readFileSync('electron/main.js', 'utf8');
const suffixes = [null, 'K', 'M', 'B', 'T', 'Qa', 'Qi', 'Sx', 'Sp', 'Oc', 'No', 'De', 'Ud', 'Dd', 'Td', 'Qad', 'Qid', 'Sxd', 'Spd', 'Ocd', 'Nod', 'Vig', 'Uv', 'Dv', 'Tv', 'Qav', 'Qiv', 'Sxv', 'Spv', 'Ocv', 'Nov', 'Tri', 'Utr', 'Dtr', 'Ttr', 'Qatr', 'Qitr', 'Sxtr', 'Sptr', 'Octr', 'Notr', 'Qag', 'Uqa', 'Dqa', 'Tqa', 'Qaqa', 'Qiqa', 'Sxqa', 'Spqa', 'Ocqa', 'Noqa', 'Qig', 'Uqi', 'Dqi', 'Tqi', 'Qaqi', 'Qiqi', 'Sxqi', 'Spqi', 'Ocqi', 'Noqi', 'Sex', 'Use', 'Dse', 'Tse', 'Qase', 'Qise', 'Sxse', 'Spse', 'Ocse', 'Nose', 'Sep', 'Usp', 'Dsp', 'Tsp', 'Qasp', 'Qisp', 'Spsp', 'Ocsp', 'Nosp', 'Oct', 'Uoc', 'Doc', 'Toc', 'Qaoc', 'Qioc', 'Sxoc', 'Spoc', 'Ococ', 'Nooc', 'Non', 'Unn', 'Dnn', 'Tnn', 'Qann', 'Qinn', 'Sxnn', 'Spnn', 'Ocnn', 'Nonn', 'Cen', 'Uc'];
function format(n) { const text = BigInt(n).toString(); if (n < 1000n) return text; const e = Math.floor((text.length - 1) / 3) * 3; const s = suffixes[e / 3]; return s && e <= 306 ? `${text.slice(0, text.length - e)}${s}` : `${text[0]}.${text.slice(1, 3).padEnd(2, '0')}e${text.length - 1}`; }
function sale(count) { return 1n << BigInt(Math.max(0, count - 1)); }
function prestige(count) { return 1000n << BigInt(count); }

// Fresh state and legacy-save migration fields are defined in production code.
assert.match(source, /schemaVersion:\s*4/);
assert.match(source, /function migrateSave/);
assert.match(source, /preserveExistingSave/);
// Invalid import parsing must be guarded and backup must remain present.
assert.match(source, /Khôi phục thất bại/);
assert.match(source, /BACKUP_STORAGE_KEY/);
// BigInt merge and values above Number.MAX_VALUE stay exact.
const huge = (2n ** 2048n) * 2n;
assert.equal(huge, 2n ** 2049n);
assert.equal(format(1000n), '1K');
assert.equal(format(10n ** 303n).endsWith('Uc'), true);
assert.equal(format(10n ** 400n), '1.00e400');
// Prestige economy through thousands of rebirths has no floating point ceiling.
assert.equal(sale(0), 1n); assert.equal(sale(1), 1n); assert.equal(sale(2), 2n); assert.equal(sale(7), 64n);
assert.equal(prestige(0), 1000n); assert.equal(prestige(1), 2000n); assert.equal(prestige(1000), 1000n << 1000n);
// Endless Boss threshold remains a valid integer after named Bosses are exhausted.
assert.equal(1024n << 7n, 131072n);
assert.match(source, /Boss Vô Tận/);
assert.match(source, /hp:\s*asBigInt/);
assert.match(animation, /const ultra = n >= 2048n;/);
assert.match(animation, /const auraTier = ultra \? Math\.max\(1, Math\.min\(30, exponent - 10\)\) : 0;/);
assert.match(animation, /const binaryLevel = !ultra \? 0 : n < 1_000_000n \? 1/);
assert.match(animation, /const binaryEffectCount = binaryLevel === 0 \? 0 : binaryLevel === 1 \? 1 : Math\.min\(8, \(binaryLevel - 1\) \* 2\)/);
assert.match(animation, /auraTier >= 25 \? '<span class="aura-extra aura-apotheosis"><\/span>'/);
assert.match(animation, /binaryEffectCount >= 8 \? 'aura-binary-circuit-on aura-binary-core-on'/);
assert.match(animation, /--aura-glow-far/);
assert.match(animationCss, /\.cell\.aura-apotheosis-on \.aura-apotheosis/);
assert.match(animation, /auraTier >= 20 \? 'aura-quantum-on' : ''/);
assert.match(animation, /--aura-slow-speed/);
assert.match(animation, /class=\"aura-extra aura-binary\"/);
assert.match(animation, /01010011001/);
assert.match(animation, /--binary-distance/);
assert.match(animationCss, /@keyframes binary-code-eject/);
assert.match(animationCss, /\.cell\.aura-binary-on \.aura-binary/);
assert.match(animationCss, /body\.effects-off \.cell\.has-aura \.aura-extra/);
assert.match(source, /href="animation.css"/);
assert.match(source, /src="animation.js"/);
assert.match(animationCss, /@keyframes tile-aura-spin/);
assert.match(animationCss, /aura-quantum/);
assert.match(animation, /auraTier >= 1 \? '<span class=\"aura-extra aura-matrix\"/);
assert.match(animation, /auraTier >= 4 \? '<span class=\"aura-extra aura-electric\"/);
assert.match(animation, /auraTier >= 6 \? '<span class=\"aura-extra aura-frost\"/);
assert.match(animation, /auraTier >= 8 \? '<span class=\"aura-extra aura-embers\"/);
assert.match(animation, /auraTier >= 10 \? '<span class=\"aura-extra aura-runes\"/);
assert.match(animation, /auraTier >= 12 \? '<span class=\"aura-extra aura-glitch\"/);
assert.match(animation, /auraTier >= 14 \? '<span class=\"aura-extra aura-void\"/);
assert.match(animation, /auraTier >= 18 \? '<span class=\"aura-extra aura-wings\"/);
assert.match(animation, /auraTier >= 22 \? '<span class=\"aura-extra aura-halo\"/);
assert.match(animation, /auraTier >= 27 \? '<span class=\"aura-extra aura-fractal\"/);
assert.match(animationCss, /body\[data-aura-theme=\"matrix\"\] \.cell\.has-aura \.aura-matrix/);
assert.match(animationCss, /@keyframes aura-matrix-fall/);
assert.match(animationCss, /@keyframes aura-electric-jolt/);
assert.match(animationCss, /@keyframes aura-fractal-spin/);
assert.match(source, /id=\"bgAuraStyleSetting\"/);
assert.match(backgroundSettings, /auraStyle: 'evolve'/);
assert.match(backgroundSettings, /bgAuraStyleSetting: settings.auraStyle/);
// Exercise tier boundaries in the actual separated animation module.
const vm = require('vm');
const animationContext = { window: {} };
vm.runInNewContext(animation, animationContext);
const meta = animationContext.window.NebulaAnimation.tileVisualMeta;
assert.equal(meta(1024n).auraTier, 0);
assert.equal(meta(2048n).auraTier, 1);
assert.equal(meta(2048n).binaryLevel, 1);
assert.equal(meta(2048n).binaryEffectCount, 1);
assert.equal(meta(2048n).extras.includes('01010011001'), true);
assert.equal(meta(2048n).extras.includes('aura-binary'), true);
assert.equal((meta(2048n).extras.match(/class="binary-stream"/g) || []).length, 4);
const oneM = meta(1_000_000n);
assert.equal(oneM.binaryLevel, 2);
assert.equal(oneM.binaryEffectCount, 2);
assert.equal(oneM.extras.includes('aura-binary-orbit'), true);
assert.equal(oneM.extras.includes('aura-binary-rain'), false);
assert.equal((oneM.extras.match(/class="binary-stream"/g) || []).length, 6);
const oneB = meta(1_000_000_000n);
assert.equal(oneB.binaryLevel, 3);
assert.equal(oneB.binaryEffectCount, 4);
assert.equal(oneB.extras.includes('aura-binary-orbit'), true);
assert.equal(oneB.extras.includes('aura-binary-rain'), true);
assert.equal(oneB.extras.includes('aura-binary-pulse'), true);
assert.equal((oneB.extras.match(/class="binary-stream"/g) || []).length, 8);
const oneT = meta(1_000_000_000_000n);
assert.equal(oneT.binaryLevel, 4);
assert.equal(oneT.binaryEffectCount, 6);
assert.equal(oneT.extras.includes('aura-binary-fragments'), true);
assert.equal(oneT.extras.includes('aura-binary-glyphs'), true);
const oneQa = meta(1_000_000_000_000_000n);
assert.equal(oneQa.binaryLevel, 5);
assert.equal(oneQa.binaryEffectCount, 8);
assert.equal(oneQa.extras.includes('aura-binary-circuit'), true);
assert.equal(oneQa.extras.includes('aura-binary-core'), true);
assert.equal(meta(4096n).auraTier, 2);
assert.equal(meta(4096n).extras.includes('aura-matrix'), true);
assert.equal(meta(16384n).extras.includes('aura-electric'), true);
assert.equal(meta(65536n).extras.includes('aura-frost'), true);
assert.equal(meta(262144n).extras.includes('aura-embers'), true);
assert.equal(meta(1048576n).extras.includes('aura-runes'), true);
assert.equal(meta(4194304n).extras.includes('aura-glitch'), true);
assert.equal(meta(2n ** 24n).extras.includes('aura-void'), true);
assert.equal(meta(2n ** 28n).extras.includes('aura-wings'), true);
assert.equal(meta(2n ** 32n).extras.includes('aura-halo'), true);
assert.equal(meta(2n ** 37n).extras.includes('aura-fractal'), true);
assert.equal(meta(2n ** 40n).auraTier, 30);
// The ultimate Bagua aura unlocks only when the exact BigInt value reaches 10^306.
assert.match(animation, /const BAGUA_AURA_THRESHOLD = 10n \*\* 306n;/);
assert.match(animation, /const baguaUnlocked = n >= BAGUA_AURA_THRESHOLD;/);
const justBelowBagua = meta(2n ** 1016n);
assert.equal(justBelowBagua.baguaUnlocked, false);
assert.equal(justBelowBagua.extras.includes('aura-bagua'), false);
const atBaguaThreshold = meta(10n ** 306n);
assert.equal(atBaguaThreshold.baguaUnlocked, true);
assert.equal(atBaguaThreshold.extras.includes('aura-bagua'), true);
assert.equal(atBaguaThreshold.auraClass.includes('aura-bagua-on'), true);
assert.equal(meta(2n ** 1017n).baguaUnlocked, true);
// Ten-tier Bagua cycles use exact decimal magnitude boundaries and never regress.
const baguaAt = (exp) => meta(10n ** BigInt(exp));
const b306 = baguaAt(306);
const b406 = baguaAt(406);
const b1206 = baguaAt(1206);
const ck1306 = baguaAt(1306);
const ck2206 = baguaAt(2206);
const wu2306 = baguaAt(2306);
const bh3305 = baguaAt(3305);
const bh3306 = baguaAt(3306);
const bh3406 = baguaAt(3406);
const bh4206 = baguaAt(4206);
const bh4306 = baguaAt(4306);
assert.equal(b306.baguaStage, 1); assert.equal(b306.baguaLevel, 1); assert.equal(b306.baguaRank, 1);
assert.equal(meta((10n ** 406n) - 1n).baguaLevel, 1);
assert.equal(b406.baguaStage, 1); assert.equal(b406.baguaLevel, 2); assert.equal(b406.baguaRank, 2);
assert.equal(b1206.baguaStage, 1); assert.equal(b1206.baguaLevel, 10); assert.equal(b1206.baguaRank, 10);
assert.equal(meta((10n ** 1306n) - 1n).baguaStage, 1); assert.equal(meta((10n ** 1306n) - 1n).baguaLevel, 10);
assert.equal(baguaAt(1305).baguaStage, 1); assert.equal(baguaAt(1305).baguaLevel, 10);
assert.equal(ck1306.baguaStage, 2); assert.equal(ck1306.baguaLevel, 1); assert.equal(ck1306.baguaRank, 11);
assert.equal(ck2206.baguaStage, 2); assert.equal(ck2206.baguaLevel, 10); assert.equal(ck2206.baguaRank, 20);
assert.equal(wu2306.baguaStage, 3); assert.equal(wu2306.baguaLevel, 1); assert.equal(wu2306.baguaRank, 21);
// Stage IV switches at 1e3306; it replaces the Vô Cực visuals and stays black-hole themed at larger values.
assert.equal(bh3305.baguaStage, 3); assert.equal(bh3305.isBlackHole, false);
assert.equal(meta((10n ** 3306n) - 1n).isBlackHole, false);
assert.equal(bh3306.baguaStage, 4); assert.equal(bh3306.baguaLevel, 1); assert.equal(bh3306.baguaRank, 31);
assert.equal(bh3306.isBlackHole, true); assert.equal(bh3306.baguaStageName, 'HỐ ĐEN VÔ CỰC');
assert.match(bh3306.extras, /aura-black-hole-fallback/);
assert.doesNotMatch(bh3306.extras, /class="aura-extra aura-bagua"/);
assert.doesNotMatch(bh3306.extras, /aura-apotheosis|aura-fractal|aura-binary/);
assert.equal(bh3406.baguaStage, 4); assert.equal(bh3406.baguaLevel, 2); assert.equal(bh3406.baguaRank, 32);
assert.equal(bh4206.baguaStage, 4); assert.equal(bh4206.baguaLevel, 10); assert.equal(bh4206.baguaRank, 40);
assert.equal(bh4306.baguaStage, 5); assert.equal(bh4306.isBlackHole, true); assert.match(bh4306.baguaStageName, /HỐ ĐEN VÔ TẬN/);
assert.match(bh3306.auraClass, /aura-blackhole-on/);
assert.equal(b406.extras.includes('CẤP 2/10'), true);
assert.match(b406.style, /--bagua-rank:2/);
assert.match(baguaAura3D, /function addEvolutionLayers/);
assert.match(baguaAura3D, /function addBlackHoleLayers/);
assert.match(baguaAura3D, /if \(stage >= 4\) \{[\s\S]*?addBlackHoleLayers\(root, index, stage, level, palette, layers\)/);
assert.match(baguaAura3D, /black-hole-event-horizon-sphere/);
assert.match(baguaAura3D, /black-hole-annulus/);
assert.match(baguaAura3D, /case 30: \/\/ Apotheosis array/);
assert.match(baguaAura3D, /taiji\.material\.opacity = \.22/);
assert.match(animationCss, /\.bagua-taiji \{[\s\S]*?top: 50%;[\s\S]*?opacity: \.22/);
assert.match(animationCss, /\.cell\.aura-bagua-stage-2 \.aura-bagua/);
assert.match(animationCss, /\.cell\.aura-bagua-stage-3 \.aura-bagua/);
assert.match(animationCss, /\.cell\.aura-bagua-on \.aura-bagua/);
assert.match(animationCss, /\.cell\.aura-blackhole-on \.aura-black-hole-fallback/);
assert.match(animationCss, /black-hole-disk-back-spin/);
assert.match(animationCss, /\.flex-view-overlay\.flex-view-black-hole \.flex-view-ring-a/);
assert.match(source, /visual\.isBlackHole/);
assert.match(animationCss, /@keyframes aura-bagua-rotate/);
assert.match(animationCss, /\.aura-bagua \.bagua-trigram/);
assert.match(source, /src="js\/libs\/three\.min\.js"[\s\S]*src="animation\.js"[\s\S]*src="bagua-aura-3d\.js"/);
assert.match(baguaAura3D, /new THREE\.WebGLRenderer/);
assert.match(baguaAura3D, /THREE\.TorusGeometry/);
assert.match(baguaAura3D, /glyphOrbit/);
assert.match(baguaAura3D, /layer\.object\.rotation\.z \+= delta \* layer\.speed/);
assert.match(animationCss, /perspective\(900px\) rotateX\(67deg\) rotateY\(14deg\)/);
assert.match(animationCss, /bagua-aura-3d-canvas/);
assert.equal(meta(10n ** 90n).binaryEffectCount, 8);
assert.equal((meta(10n ** 90n).extras.match(/class="binary-stream"/g) || []).length, 28);
// Atomic rebirth, achievements, quests, settings and optional admin support remain wired in.
assert.match(source, /const rollback = deepCopy\(game\)/);
assert.match(source, /const ACHIEVEMENTS/); assert.match(source, /const QUESTS/); assert.match(source, /const EQUIPMENT/);
assert.match(source, /adminpanel\.js/);
// Background settings must stay modular, persistent, and isolated from the core game runtime.
assert.match(source, /backgroundSettingsBox/);
assert.match(source, /backgroundSettingsJumpBtn/);
assert.match(source, /src="\.\/background-settings\.js"/);
assert.match(source, /id="nebulaBackgroundFrame"/);
assert.match(backgroundSettings, /nebula2048\.backgroundSettings\.v1/);
assert.match(backgroundSettings, /compressImage/);
assert.match(backgroundSettings, /bgThemeSetting/);
assert.match(backgroundSettings, /NEBULA_BACKGROUND_SETTINGS/);
assert.match(backgroundBridge, /app\._nebulaSceneDisabled/);
assert.match(backgroundBridge, /setDrawRange/);
assert.match(backgroundHtml, /js\/background-bridge\.js/);
assert.match(backgroundCss, /#nebulaBackgroundHost/);
console.log('NEBULA 2048 core, BigInt, save, prestige, and background-settings regression tests passed.');

// Flex mode selects any occupied tile, centers its actual aura and supports pointer rotation without a settings studio.
assert.match(source, /id="flexSelectPrompt"/);
assert.match(source, /id="flexViewOverlay"/);
assert.doesNotMatch(source, /id="flexStudioScreen"/);
assert.match(source, /function chooseFlexTile\(index\)/);
assert.match(source, /function openFlexView\(tile\)/);
assert.match(source, /function flexViewPointerDown\(event\)/);
assert.match(source, /function flexViewPointerMove\(event\)/);
assert.match(source, /function flexViewWheel\(event\)/);
assert.match(source, /rotateX\(\$\{flexViewRotation\.x\}deg\) rotateY\(\$\{flexViewRotation\.y\}deg\)/);
assert.match(source, /id="flexViewTrigrams"/);
assert.match(source, /visual \? visual\.extras : ''/);
assert.doesNotMatch(source, /flexApplyBtn|data-flex-control=|function applyFlexToGame/);
assert.doesNotMatch(source, /normalizedTile\.flexStyle = flexStyle/);
assert.match(source, /if \(flexViewOpen\) \{/);
assert.match(animationCss, /\.flex-view-overlay/);
assert.match(animationCss, /\.flex-view-stage\.is-dragging/);
assert.match(animationCss, /\.flex-view-ring-a/);
// Regression: selected tile geometry must stay centered, labels cannot wrap and
// Flex must show the Bagua CSS fallback even when the board WebGL renderer is active.
assert.match(animationCss, /\.flex-view-aura > \.flex-view-tile\s*\{[\s\S]*?left:\s*50%\s*!important;[\s\S]*?top:\s*50%\s*!important;[\s\S]*?transform:\s*translate3d\(-50%,\s*-50%,\s*28px\)\s*!important;/);
assert.match(animationCss, /\.flex-view-number\s*\{[\s\S]*?white-space:\s*nowrap\s*!important;/);
assert.match(animationCss, /html\.bagua-webgl-ready \.flex-view-aura\.aura-bagua-on \.aura-bagua\s*\{[\s\S]*?visibility:\s*visible\s*!important;/);
assert.match(animationCss, /\.flex-view-aura\.aura-bagua-on \.bagua-ring-outer/);
assert.match(source, /const valueFontSize = Math\.max\(15, Math\.min\(54,/);
assert.match(source, /\$\('flexViewTrigrams'\)\.hidden = true;/);
console.log('NEBULA Flex centering, one-line value label, Bagua fallback, mouse rotation and zoom checks passed.');

// Performance regressions: keep the complete visual systems but avoid unnecessary renders,
// repeated DOM layout reads, and duplicate mesh draw calls. The backdrop must pause under Flex.
assert.match(backgroundApp, /_minRenderIntervalMs = 1000 \/ 30/);
assert.match(backgroundApp, /setRenderSuspended\(suspended\)/);
assert.match(backgroundApp, /syncRenderLoop\(\)/);
assert.match(backgroundBridge, /NEBULA_BACKGROUND_SUSPEND/);
assert.match(backgroundSettings, /syncFlexRenderPause/);
assert.match(baguaAura3D, /FRAME_INTERVAL_MS = 1000 \/ 30/);
assert.match(baguaAura3D, /cachedCanvasRect/);
assert.match(baguaAura3D, /refreshCell = !aura \|\| aura\.userData\.cellElement !== cell \|\| layoutChanged/);
assert.match(baguaAura3D, /new THREE\.InstancedMesh/);
assert.match(animationCss, /body\.flex-view-active \.board-wrap \*::before[\s\S]*?animation-play-state: paused !important/);
console.log('NEBULA performance scheduling, renderer suspension, cached layout and instanced aura tests passed.');

// OOM hardening: free retained GPU resources when Flex covers the board and unload the
// independent background WebGL iframe; Flex caps per-stream DOM compositing without
// removing the aura families.
assert.match(baguaAura3D, /textureCache\.clear\(\)/);
assert.match(baguaAura3D, /geometryCache\.clear\(\)/);
assert.match(baguaAura3D, /materialCache\.clear\(\)/);
assert.match(baguaAura3D, /forceContextLoss/);
assert.match(backgroundSettings, /nebulaFlexReleased/);
assert.match(backgroundSettings, /Do not recreate a released background iframe while Flex is still active/);
const hugeForFlex = meta(10n ** 200n, { flexPreview: true });
assert.equal((hugeForFlex.extras.match(/class="binary-stream"/g) || []).length, 12);
const farBlackHole = meta(10n ** 10002n, { flexPreview: true });
assert.equal(farBlackHole.isBlackHole, true);
assert.match(farBlackHole.extras, /aura-black-hole-fallback/);
assert.doesNotMatch(farBlackHole.extras, /class="aura-extra aura-bagua"/);
assert.equal((meta(10n ** 200n).extras.match(/class="binary-stream"/g) || []).length, 28);
assert.equal((meta(10n ** 10002n).extras.match(/class="binary-stream"/g) || []).length, 0);
assert.match(animationCss, /FLEX OOM GUARD/);
assert.match(animationCss, /body\.flex-view-active \.flex-view-aura \.aura-extra::before/);
console.log('NEBULA max-aura Flex OOM guard, WebGL disposal, stream budget and background-context release checks passed.');

// Final 3D alignment guard: tile, aura, and the Bagua wrapper share a common
// absolute 50%/50% coordinate system and the tile has no Z-only offset under perspective.
assert.match(animationCss, /FLEX 3D CENTER LOCK \(v2\)/);
const flexCenterFix = animationCss.slice(animationCss.lastIndexOf('FLEX 3D CENTER LOCK (v2)'));
assert.match(flexCenterFix, /body\.flex-view-active \.flex-view-aura\.cell > \.flex-view-tile\s*\{[\s\S]*?position:\s*absolute\s*!important;[\s\S]*?left:\s*50%\s*!important;[\s\S]*?top:\s*50%\s*!important;[\s\S]*?transform:\s*translate\(-50%,\s*-50%\)\s*!important;/);
assert.match(flexCenterFix, /body\.flex-view-active \.flex-view-aura\.aura-bagua-on > \.aura-bagua\s*\{[\s\S]*?left:\s*50%\s*!important;[\s\S]*?top:\s*50%\s*!important;[\s\S]*?transform:\s*translate\(-50%,\s*-50%\)\s*!important;/);
assert.doesNotMatch(flexCenterFix, /transform:\s*translateZ\(18px\)\s*!important;/);
console.log('NEBULA final Flex 3D center-lock alignment checks passed.');

// Bagua CSS-3D symbols must scale with the expansion of the 2D aura at high ranks.
assert.match(source, /--flex-bagua-scale/);
assert.match(source, /Math\.min\(2\.65, 1\.35 \+ \(Math\.max\(1, visual\.baguaRank\) - 1\) \* 0\.045\)/);
const flexBaguaScaleCss = animationCss.slice(animationCss.lastIndexOf('FLEX BAGUA SYMBOL SCALE SYNC'));
assert.match(flexBaguaScaleCss, /scale\(var\(--flex-bagua-scale, 1\.35\)\)/);
assert.match(flexBaguaScaleCss, /width:\s*114%\s*!important/);
console.log('NEBULA Flex Bagua 3D glyph/geometry scale synchronization checks passed.');


// SVG icon migration: visible app/admin icons use the local SVG helper, not emoji characters.
assert.match(source, /src="ui-icons\.js"/);
assert.match(source, /window\.NebulaIcons\.svg/);
assert.match(uiIcons, /window\.NebulaIcons = Object\.freeze\(\{ svg, mount \}\)/);
assert.match(uiIcons, /function svg\(name, className/);
assert.match(adminPanel, /window\.NebulaIcons\.svg\('skull'\)\} Hạ Boss/);
assert.match(source, /data-svg-icon="target"[^>]*><\/span> Nhiệm vụ dài hạn/);
assert.match(source, /data-svg-icon="settings"[^>]*><\/span> Thống kê & cài đặt/);
assert.match(source, /data-svg-icon="grid"[^>]*><\/span><small>Bàn cờ/);
assert.match(source, /data-svg-icon="undo"[^>]*><\/span> Đặt lại góc/);
assert.match(source, /data-svg-icon="sparkle"/);
const emojiSources = [
  ['index.html', source], ['background.html', backgroundHtml], ['adminpanel.js', adminPanel],
  ['animation.js', animation], ['animation.css', animationCss], ['bagua-aura-3d.js', baguaAura3D],
  ['background-settings.js', backgroundSettings], ['background-settings.css', backgroundCss],
  ['js/app.js', backgroundApp], ['js/background-bridge.js', backgroundBridge],
  ['js/code-background.js', fs.readFileSync('js/code-background.js', 'utf8')],
  ['js/bagua-textures.js', fs.readFileSync('js/bagua-textures.js', 'utf8')],
  ['ui-icons.js', uiIcons], ['electron/main.js', electronMain]
];
const pictographicEmoji = /[\p{Emoji_Presentation}\p{Extended_Pictographic}]/u;
const traditionalTrigrams = new Set(Array.from({ length: 8 }, (_, index) => String.fromCodePoint(0x2630 + index)));
for (const [name, text] of emojiSources) {
  const remainingPictographs = Array.from(text).filter(character => pictographicEmoji.test(character) && !traditionalTrigrams.has(character));
  assert.deepEqual(remainingPictographs, [], `${name} still contains pictographic emoji; use local SVG or plain text instead`);
}
console.log('NEBULA SVG icon migration checks passed across UI, styles, effects and Electron menus (traditional Bagua trigram symbols explicitly retained).');

// God Mode must affect actual game rules, not just the Admin checkbox display.
assert.match(source, /function canUseSkill\(id, showToast = true\) \{[\s\S]*?if \(adminGodMode\) return true;/);
assert.match(source, /function spendSkill\(id\) \{[\s\S]*?if \(adminGodMode\) \{ game\.mana = getMaxManaFor\(\); game\.cooldowns\[id\] = 0; return; \}/);
assert.match(source, /if \(!adminGodMode && game\.gold < cost\)/);
assert.match(source, /if \(!adminGodMode\) \{ game\.gold -= cost; game\.stats\.goldSpent \+= cost; \}/);
assert.match(source, /if \(!adminGodMode && game\.essence < cost\)/);
assert.match(source, /if \(!adminGodMode\) game\.essence -= cost/);
assert.match(source, /const skillFree = adminGodMode;[\s\S]*?button\.disabled = !skillFree/);
assert.match(source, /adminGodMode \? '<span class="free-price">MIỄN PHÍ<\/span>'/);
assert.match(source, /setGodMode\(enabled\) \{[\s\S]*?adminGodMode = Boolean\(enabled\);[\s\S]*?render\(\); saveGame\(\);/);
assert.match(adminPanel, /api\.setGodMode\(enabled\);\s*refreshStats\(\);/);
assert.match(source, /setLevel\(level\) \{[\s\S]*?game\.level = nextLevel;[\s\S]*?game\.exp = 0;[\s\S]*?saveGame\(\); render\(\);[\s\S]*?return game\.level;/);
assert.match(adminPanel, /const appliedLevel = api\.setLevel\(level\);[\s\S]*?refreshStats\(\);[\s\S]*?announce\(`Đã đặt cấp nhân vật thành Lv\. \$\{appliedLevel\}\.`\);/);
assert.match(source, /godMode: adminGodMode/);
console.log('NEBULA God Mode resource-free purchases, skill availability and Admin level setter checks passed.');

// Admin free block-upgrade skill: choose a tile and double it by an arbitrary
// configured number of times (within a per-action safety cap), with BigInt exactness.
assert.match(source, /let adminBlockUpgradePending = null/);
assert.match(source, /const MAX_ADMIN_BLOCK_UPGRADE_DOUBLINGS = 100000/);
assert.match(source, /function armAdminBlockUpgradeSelection\(times\)/);
assert.match(source, /function applyAdminBlockUpgradeAt\(index\)/);
assert.match(source, /const newValue = oldValue << BigInt\(times\)/);
assert.match(source, /game\.runMaxTile = maxBigInt\(asBigInt\(game\.runMaxTile, 0n\), newValue\)/);
assert.match(adminPanel, /id="adminBlockUpgradeTimes" type="number" min="1" max="100000"/);
assert.match(adminPanel, /id="adminArmBlockUpgrade"/);
assert.match(adminPanel, /id="adminCancelBlockUpgrade"/);
assert.match(adminPanel, /api\.armAdminBlockUpgrade\(times\)/);
assert.match(source, /applyAdminBlockUpgradeAt\(index\)/);
assert.match(source, /ADMIN SKILL: chọn một khối có số/);
assert.match(adminPanel, /Skill Admin · Nâng cấp khối tự do/);
assert.match(adminPanel, /api\.cancelAdminBlockUpgrade\(\)/);
assert.equal(2048n << 1n, 4096n);
assert.equal(2048n << 10n, 2_097_152n);
assert.equal((2n ** 306n) << 1000n, 2n ** 1306n);
assert.equal((2n ** 10000n) << 100000n, 2n ** 110000n);
console.log('NEBULA Admin unlimited-repeat block upgrade skill and BigInt doubling checks passed.');
