/* NEBULA 2048 — aura tier logic, separated from the game engine. */
(function (global) {
  'use strict';

  function toBigInt(value) {
    try {
      if (typeof value === 'bigint') return value;
      if (value == null || value === '') return 0n;
      return BigInt(value);
    } catch (_) {
      return 0n;
    }
  }

  const BAGUA_AURA_THRESHOLD = 10n ** 306n;
  const iconSvg = (name) => global.NebulaIcons && typeof global.NebulaIcons.svg === 'function'
    ? global.NebulaIcons.svg(name)
    : '<svg class="ui-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><circle cx="12" cy="12" r="10"/><path d="M12 2a5 5 0 0 1 0 10 5 5 0 0 0 0 10"/><circle cx="12" cy="7" r="1.2"/><circle cx="12" cy="17" r="1.2"/></svg>';
  const BAGUA_TAIJI_SVG = iconSvg('taiji');
  const BAGUA_SPARKLE_SVG = iconSvg('sparkle');
  const BAGUA_SPARKLES_SVG = iconSvg('sparkles');
  const BAGUA_AURA_MARKUP = '<span class="aura-extra aura-bagua" aria-hidden="true">' +
    '<span class="bagua-aura-flare"></span>' +
    '<span class="bagua-energy-lines"></span>' +
    '<span class="bagua-ring bagua-ring-outer"></span>' +
    '<span class="bagua-ring bagua-ring-inner"></span>' +
    '<span class="bagua-ring bagua-ring-vertical"></span>' +
    '<span class="bagua-ring bagua-ring-cross"></span>' +
    '<span class="bagua-ring bagua-ring-runes"></span>' +
    '<span class="bagua-ring bagua-ring-core"></span>' +
    '<span class="bagua-glyph-orbit">' +
    '<span class="bagua-trigram bagua-north">☵</span>' +
    '<span class="bagua-trigram bagua-northeast">☶</span>' +
    '<span class="bagua-trigram bagua-east">☳</span>' +
    '<span class="bagua-trigram bagua-southeast">☴</span>' +
    '<span class="bagua-trigram bagua-south">☲</span>' +
    '<span class="bagua-trigram bagua-southwest">☷</span>' +
    '<span class="bagua-trigram bagua-west">☱</span>' +
    '<span class="bagua-trigram bagua-northwest">☰</span>' +
    '</span>' +
    '<span class="bagua-taiji-halo"></span>' +
    '<span class="bagua-taiji">' + BAGUA_TAIJI_SVG + '</span>' +
    '<span class="bagua-seal">%%BAGUA_SEAL%%</span>' +
    '<span class="bagua-orbiter bagua-orbiter-one">' + BAGUA_SPARKLE_SVG + '</span>' +
    '<span class="bagua-orbiter bagua-orbiter-two">' + BAGUA_SPARKLES_SVG + '</span>' +
    '<span class="bagua-orbiter bagua-orbiter-three">' + BAGUA_SPARKLE_SVG + '</span>' +
    '<span class="bagua-orbiter bagua-orbiter-four">' + BAGUA_SPARKLES_SVG + '</span>' +
    '<span class="bagua-star bagua-star-one">' + BAGUA_SPARKLE_SVG + '</span>' +
    '<span class="bagua-star bagua-star-two">' + BAGUA_SPARKLES_SVG + '</span>' +
    '<span class="bagua-particle bagua-particle-1"></span>' +
    '<span class="bagua-particle bagua-particle-2"></span>' +
    '<span class="bagua-particle bagua-particle-3"></span>' +
    '<span class="bagua-particle bagua-particle-4"></span>' +
    '<span class="bagua-particle bagua-particle-5"></span>' +
    '<span class="bagua-particle bagua-particle-6"></span>' +
    '<span class="bagua-particle bagua-particle-7"></span>' +
    '<span class="bagua-particle bagua-particle-8"></span>' +
    '<span class="bagua-particle bagua-particle-9"></span>' +
    '<span class="bagua-particle bagua-particle-10"></span>' +
    '<span class="bagua-particle bagua-particle-11"></span>' +
    '<span class="bagua-particle bagua-particle-12"></span>' +
    '</span>';

  const BLACK_HOLE_MARKUP = '<span class="aura-extra aura-black-hole-fallback" aria-hidden="true">' +
    '<span class="black-hole-starfield"></span>' +
    '<span class="black-hole-lens black-hole-lens-outer"></span>' +
    '<span class="black-hole-jet black-hole-jet-top"></span>' +
    '<span class="black-hole-jet black-hole-jet-bottom"></span>' +
    '<span class="black-hole-disk black-hole-disk-back"></span>' +
    '<span class="black-hole-disk black-hole-disk-mid"></span>' +
    '<span class="black-hole-disk black-hole-disk-front"></span>' +
    '<span class="black-hole-photon-ring black-hole-photon-ring-outer"></span>' +
    '<span class="black-hole-shadow"></span>' +
    '<span class="black-hole-horizon"></span>' +
    '<span class="black-hole-photon-ring black-hole-photon-ring-inner"></span>' +
    '<span class="black-hole-hotspot black-hole-hotspot-one"></span>' +
    '<span class="black-hole-hotspot black-hole-hotspot-two"></span>' +
    '<span class="black-hole-hotspot black-hole-hotspot-three"></span>' +
    '<span class="black-hole-label">%%BLACK_HOLE_SEAL%%</span>' +
    '</span>';

  function binaryExponent(value) {
    const n = toBigInt(value);
    return n > 0n ? n.toString(2).length - 1 : 0;
  }

  // 2048 unlocks tier 1. Every doubling adds one tier, capped at tier 30.
  // Add new unlockable visual layers in this module without touching the game engine.
  function tileVisualMeta(value, options = {}) {
    const flexPreview = !!(options && options.flexPreview);
    const n = toBigInt(value);
    const exponent = binaryExponent(n);
    // Decimal exponent is the exact floor(log10(value)) for positive BigInts,
    // based on digit count rather than floating-point logarithms.
    const decimalExponent = n > 0n ? n.toString().length - 1 : -1;
    const cycle = exponent % 360;
    const hue1 = (cycle * 41 + 197) % 360;
    const hue2 = (hue1 + 68 + (cycle % 5) * 7) % 360;
    const hue3 = (hue1 + 157 + (cycle % 7) * 5) % 360;
    const hue4 = (hue1 + 238 + (cycle % 3) * 11) % 360;
    const hue5 = (hue1 + 304) % 360;
    const ultra = n >= 2048n;
    const baguaUnlocked = n >= BAGUA_AURA_THRESHOLD;
    // Ten Bagua tiers span 1e306..1e1206. The next 10-tier cycle starts
    // at 1e1306 (Càn Khôn Bát Quái), then 1e2306 starts Vô Cực Càn Khôn.
    // Every cycle is 1000 decimal exponents wide; each tier adds 100 exponents.
    const baguaStage = baguaUnlocked ? Math.floor((decimalExponent - 306) / 1000) + 1 : 0;
    const baguaStageBaseExponent = baguaUnlocked ? 306 + (baguaStage - 1) * 1000 : 0;
    const baguaLevel = baguaUnlocked ? Math.min(10, Math.floor((decimalExponent - baguaStageBaseExponent) / 100) + 1) : 0;
    const baguaRank = baguaUnlocked ? (baguaStage - 1) * 10 + baguaLevel : 0;
    const stageNames = ['', 'BÁT QUÁI', 'CÀN KHÔN BÁT QUÁI', 'VÔ CỰC CÀN KHÔN', 'HỐ ĐEN VÔ CỰC'];
    const baguaStageName = baguaStage < stageNames.length
      ? (stageNames[baguaStage] || '')
      : `HỐ ĐEN VÔ TẬN · CHU KỲ ${baguaStage - 3}`;
    const isBlackHole = baguaUnlocked && baguaStage >= 4;
    const baguaMarkup = baguaUnlocked && !isBlackHole
      ? BAGUA_AURA_MARKUP.replace('%%BAGUA_SEAL%%', `${baguaStageName} · CẤP ${baguaLevel}/10`)
      : '';
    const blackHoleMarkup = isBlackHole
      ? BLACK_HOLE_MARKUP.replace('%%BLACK_HOLE_SEAL%%', `${baguaStageName} · CẤP ${baguaLevel}/10`)
      : '';
    const auraTier = ultra ? Math.max(1, Math.min(30, exponent - 10)) : 0;
    const auraOpacity = auraTier ? Math.min(.94, .27 + auraTier * .022) : 0;
    const auraOpacityBorder = auraOpacity * .8;
    const auraOpacityMid = auraOpacity * .55;
    const auraOpacityFar = auraOpacity * .25;
    const auraBlur = auraTier ? Math.min(23, 3 + auraTier * .66) : 0;
    const auraExpand = auraTier ? Math.min(45, 3 + auraTier * 1.4) : 0;
    const auraGlow = auraTier ? Math.min(190, 12 + auraTier * 5.2) : 0;
    const auraGlowMid = auraGlow * 1.7;
    const auraGlowFar = auraGlow * 2.4;
    const auraSpeed = auraTier ? Math.max(1.25, 7.6 - auraTier * .19) : 7.6;
    const auraBreatheSpeed = auraTier ? Math.max(.72, 2.9 - auraTier * .065) : 2.9;
    const auraFastSpeed = Math.max(.9, auraSpeed * .76);
    const auraSlowSpeed = Math.max(1.4, auraSpeed * 1.4);
    const auraVerySlowSpeed = Math.max(2, auraSpeed * 1.8);
    const auraQuantumSpeed = Math.max(2.5, auraSpeed * 2.2);
    // Binary-code effects are unlocked in distinct magnitude bands, not all at once.
    // 2048+ = rank 1; >=1M = rank 2 / 2 effects; >=1B = rank 3 / 4 effects.
    // Each further 1,000x magnitude adds another rank and two visual layers up to 8.
    const binaryLevel = !ultra ? 0 : n < 1_000_000n ? 1 : Math.min(99, 2 + Math.floor((n.toString().length - 7) / 3));
    const binaryEffectCount = binaryLevel === 0 ? 0 : binaryLevel === 1 ? 1 : Math.min(8, (binaryLevel - 1) * 2);
    // Flex mode uses fewer independent text layers to avoid hundreds of GPU-composited
    // text-shadow surfaces; the normal board keeps the full stream count.
    const binaryCount = binaryLevel ? Math.min(flexPreview ? 12 : 28, 4 + (binaryLevel - 1) * 2) : 0;
    const binaryDistance = binaryLevel ? Math.min(180, 38 + (binaryLevel - 1) * 8) : 38;
    const binarySpeed = binaryLevel ? Math.max(1.05, 3.4 - (binaryLevel - 1) * .16) : 3.4;
    const binaryOpacity = binaryLevel ? Math.min(.98, .58 + (binaryLevel - 1) * .035) : .58;
    const binaryStreams = binaryLevel ? Array.from({ length: binaryCount }, (_, i) => {
      const angle = Math.round((360 / binaryCount) * i + binaryLevel * 7) % 360;
      const delay = -((i / binaryCount) * binarySpeed).toFixed(2);
      return `<span class="binary-stream" style="--binary-angle:${angle}deg;--binary-delay:${delay}s">01010011001</span>`;
    }).join('') : '';
    const binaryExtra = binaryLevel ? `<span class="aura-extra aura-binary" aria-hidden="true">${binaryStreams}</span>` : '';
    const binaryLayers = [
      binaryEffectCount >= 2 ? '<span class="aura-extra aura-binary-orbit"></span>' : '',
      binaryEffectCount >= 4 ? '<span class="aura-extra aura-binary-rain"></span>' : '',
      binaryEffectCount >= 4 ? '<span class="aura-extra aura-binary-pulse"></span>' : '',
      binaryEffectCount >= 6 ? '<span class="aura-extra aura-binary-fragments"></span>' : '',
      binaryEffectCount >= 6 ? '<span class="aura-extra aura-binary-glyphs"></span>' : '',
      binaryEffectCount >= 8 ? '<span class="aura-extra aura-binary-circuit"></span>' : '',
      binaryEffectCount >= 8 ? '<span class="aura-extra aura-binary-core"></span>' : ''
    ].filter(Boolean).join('');
    // New aura families unlock gradually with tile magnitude. Matrix is present
    // from tier 1 so users can select it manually; in Auto mode it activates at tier 2.
    // Stage IV replaces the entire Vô Cực Càn Khôn visual family with a dedicated
    // black-hole theme; previous rune, Matrix and Bagua overlays are not stacked on top.
    const extras = isBlackHole ? blackHoleMarkup : binaryExtra + binaryLayers
      + (auraTier >= 1 ? '<span class="aura-extra aura-matrix" aria-hidden="true"></span>' : '')
      + (auraTier >= 3 ? '<span class="aura-extra aura-stars"></span>' : '')
      + (auraTier >= 4 ? '<span class="aura-extra aura-electric"></span>' : '')
      + (auraTier >= 5 ? '<span class="aura-extra aura-rings"></span>' : '')
      + (auraTier >= 6 ? '<span class="aura-extra aura-frost"></span>' : '')
      + (auraTier >= 7 ? '<span class="aura-extra aura-rays"></span>' : '')
      + (auraTier >= 8 ? '<span class="aura-extra aura-embers"></span>' : '')
      + (auraTier >= 9 ? '<span class="aura-extra aura-orbs"></span>' : '')
      + (auraTier >= 10 ? '<span class="aura-extra aura-runes"></span>' : '')
      + (auraTier >= 11 ? '<span class="aura-extra aura-flare"></span>' : '')
      + (auraTier >= 12 ? '<span class="aura-extra aura-glitch"></span>' : '')
      + (auraTier >= 14 ? '<span class="aura-extra aura-void"></span>' : '')
      + (auraTier >= 15 ? '<span class="aura-extra aura-singularity"></span>' : '')
      + (auraTier >= 18 ? '<span class="aura-extra aura-wings"></span>' : '')
      + (auraTier >= 20 ? '<span class="aura-extra aura-quantum"></span>' : '')
      + (auraTier >= 22 ? '<span class="aura-extra aura-halo"></span>' : '')
      + (auraTier >= 25 ? '<span class="aura-extra aura-apotheosis"></span>' : '')
      + (auraTier >= 27 ? '<span class="aura-extra aura-fractal"></span>' : '')
      + baguaMarkup;
    const style = `--tile-hue:${hue1};--tile-hue2:${hue2};--tile-hue3:${hue3};--tile-hue4:${hue4};--tile-hue5:${hue5};--aura-opacity:${auraOpacity};--aura-opacity-border:${auraOpacityBorder};--aura-opacity-mid:${auraOpacityMid};--aura-opacity-far:${auraOpacityFar};--aura-blur:${auraBlur}px;--aura-expand:${auraExpand}%;--aura-inset:-${auraExpand}%;--aura-glow:${auraGlow}px;--aura-glow-mid:${auraGlowMid}px;--aura-glow-far:${auraGlowFar}px;--aura-speed:${auraSpeed}s;--aura-fast-speed:${auraFastSpeed}s;--aura-slow-speed:${auraSlowSpeed}s;--aura-very-slow-speed:${auraVerySlowSpeed}s;--aura-quantum-speed:${auraQuantumSpeed}s;--aura-breathe-speed:${auraBreatheSpeed}s;--binary-distance:${binaryDistance}px;--binary-speed:${binarySpeed}s;--binary-opacity:${binaryOpacity};--binary-level:${binaryLevel};--binary-effect-count:${binaryEffectCount};--bagua-level:${baguaLevel};--bagua-stage:${baguaStage};--bagua-rank:${baguaRank};--bagua-intensity:${baguaUnlocked ? (1 + baguaRank * 0.085).toFixed(3) : 0};`;
    const effectClasses = isBlackHole
      ? ['aura-blackhole-on', `aura-bagua-on aura-bagua-stage-${baguaStage} aura-bagua-level-${baguaLevel} aura-bagua-rank-${baguaRank}`].join(' ')
      : [
        binaryLevel >= 1 ? 'aura-binary-on' : '',
        binaryEffectCount >= 2 ? 'aura-binary-orbit-on' : '',
        binaryEffectCount >= 4 ? 'aura-binary-rain-on aura-binary-pulse-on' : '',
        binaryEffectCount >= 6 ? 'aura-binary-fragments-on aura-binary-glyphs-on' : '',
        binaryEffectCount >= 8 ? 'aura-binary-circuit-on aura-binary-core-on' : '',
        auraTier >= 2 ? 'aura-matrix-on' : '',
        auraTier >= 3 ? 'aura-stars-on' : '',
        auraTier >= 4 ? 'aura-electric-on' : '',
        auraTier >= 5 ? 'aura-rings-on' : '',
        auraTier >= 6 ? 'aura-frost-on' : '',
        auraTier >= 7 ? 'aura-rays-on' : '',
        auraTier >= 8 ? 'aura-embers-on' : '',
        auraTier >= 9 ? 'aura-orbs-on' : '',
        auraTier >= 10 ? 'aura-runes-on' : '',
        auraTier >= 11 ? 'aura-flare-on' : '',
        auraTier >= 12 ? 'aura-glitch-on' : '',
        auraTier >= 14 ? 'aura-void-on' : '',
        auraTier >= 15 ? 'aura-singularity-on' : '',
        auraTier >= 18 ? 'aura-wings-on' : '',
        auraTier >= 20 ? 'aura-quantum-on' : '',
        auraTier >= 22 ? 'aura-halo-on' : '',
        auraTier >= 25 ? 'aura-apotheosis-on' : '',
        auraTier >= 27 ? 'aura-fractal-on' : '',
        baguaUnlocked ? `aura-bagua-on aura-bagua-stage-${baguaStage} aura-bagua-level-${baguaLevel} aura-bagua-rank-${baguaRank}` : ''
      ].filter(Boolean).join(' ');
    return { ultra, auraTier, binaryLevel, binaryEffectCount, baguaUnlocked, isBlackHole, baguaStage, baguaLevel, baguaRank, baguaStageName, baguaExponent: decimalExponent, auraClass: auraTier ? `has-aura aura-tier-${auraTier} ${effectClasses}` : '', style, extras };
  }

  global.NebulaAnimation = Object.freeze({ tileVisualMeta, binaryExponent });
})(window);
