/* NEBULA 2048 — local SVG icon set. No external requests or font dependencies. */
(() => {
  'use strict';
  const paths = {
    sparkle: '<path d="M12 2.8 14.3 9.7 21.2 12l-6.9 2.3L12 21.2l-2.3-6.9L2.8 12l6.9-2.3L12 2.8Z"/><path d="m19 2 .7 2.3L22 5l-2.3.7L19 8l-.7-2.3L16 5l2.3-.7L19 2Z"/>',
    sparkles: '<path d="m12 3 1.9 5.8L20 11l-6.1 2.2L12 19l-1.9-5.8L4 11l6.1-2.2L12 3Z"/><path d="m19 15 .9 2.1L22 18l-2.1.9L19 21l-.9-2.1L16 18l2.1-.9L19 15Z"/><path d="m5 2 .7 1.8L7.5 4.5l-1.8.7L5 7l-.7-1.8-1.8-.7 1.8-.7L5 2Z"/>',
    galaxy: '<circle cx="12" cy="12" r="2.2"/><ellipse cx="12" cy="12" rx="9.5" ry="4.3" transform="rotate(-32 12 12)"/><ellipse cx="12" cy="12" rx="9.5" ry="4.3" transform="rotate(47 12 12)"/><path d="M19 4.5h.01M4.5 18h.01"/>',
    volume: '<path d="M4 10v4h4l5 4V6l-5 4H4Z"/><path d="M16 9a5 5 0 0 1 0 6M18.5 6.5a8.5 8.5 0 0 1 0 11"/>',
    volumeOff: '<path d="M4 10v4h4l5 4V6l-5 4H4Z"/><path d="m17 9 5 6m0-6-5 6"/>',
    undo: '<path d="M9 14 4 9l5-5"/><path d="M4 9h9a7 7 0 0 1 0 14h-2"/>',
    plus: '<path d="M12 5v14M5 12h14"/>',
    download: '<path d="M12 3v12m-5-5 5 5 5-5"/><path d="M5 17v4h14v-4"/>',
    upload: '<path d="M12 16V4m-5 5 5-5 5 5"/><path d="M5 17v4h14v-4"/>',
    flex: '<path d="M5 13c1-2 2.2-3 3.7-3H12l2-3c.8-1.2 2.4-1.1 3 .2l1.2 2.6 2.4.6c1.6.4 2 2.5.7 3.6l-3 2.6c-1.1 1-2.5 1.4-4 1.4H9.5C7 18 5 16.3 5 13Z"/><path d="M8.5 10 7 7.8c-.7-1-.3-2.4.9-2.8l2-.7 1.6 2.3"/>',
    chain: '<path d="M10 13a5 5 0 0 0 7.1 0l2.1-2.1a5 5 0 0 0-7.1-7.1l-1.2 1.2"/><path d="M14 11a5 5 0 0 0-7.1 0l-2.1 2.1a5 5 0 0 0 7.1 7.1l1.2-1.2"/>',
    diamond: '<path d="m12 3 8.5 6-8.5 12L3.5 9 12 3Z"/><path d="M3.5 9h17M8.5 9 12 21l3.5-12L12 3 8.5 9Z"/>',
    burst: '<path d="m12 2 1.8 6.3L20 5l-3.3 6.2L23 13l-6.3 1.8L20 21l-6.2-3.3L12 24l-1.8-6.3L4 21l3.3-6.2L1 13l6.3-1.8L4 5l6.2 3.3L12 2Z" transform="translate(0 -1) scale(1 .95)"/>',
    energy: '<path d="m13 2-9 12h7l-1 8 10-13h-7l0-7Z"/>',
    hammer: '<path d="m14 5 5 5M12 7l5-5 5 5-5 5"/><path d="m3 21 10-10 3 3L6 24" transform="translate(0 -3)"/><path d="m4 20 8-8"/>',
    swap: '<path d="M4 7h15l-3-3m3 3-3 3M20 17H5l3 3m-3-3 3-3"/>',
    levelup: '<path d="M4 18h16M12 18V4m-6 6 6-6 6 6"/>',
    shuffle: '<path d="M16 3h5v5M4 20 21 3M21 16v5h-5M4 4l6 6m4 4 7 7"/>',
    skull: '<path d="M12 3a8 8 0 0 0-8 8c0 2.6 1.2 4.7 3.2 6.1V21h9.6v-3.9A7.8 7.8 0 0 0 20 11a8 8 0 0 0-8-8Z"/><circle cx="9" cy="11" r="1.5"/><circle cx="15" cy="11" r="1.5"/><path d="M10 16h4m-3 5v-3m2 3v-3"/>',
    eagle: '<path d="M2 7 9 9l3-4 3 4 7-2-4 7-6 7-6-7-4-7Z"/><path d="m9 9 3 3 3-3M10.5 14h3"/><circle cx="12" cy="9" r=".5"/>',
    rune: '<path d="m12 2 8 5v10l-8 5-8-5V7l8-5Z"/><path d="M8 8h8M9 8l3 8 3-8M7 17h10"/>',
    dragon: '<path d="M4 18c2-4 1-7-1-9 4 0 6 2 7 4 0-5 3-8 8-10-1 4 0 6 3 8-1 5-5 9-11 9H5l3-3-4 1Z"/><path d="m14 9 2 1m-5 5 3 1"/>',
    crown: '<path d="m3 8 5 4 4-7 4 7 5-4-2 12H5L3 8Z"/><path d="M5 17h14"/>',
    blackhole: '<circle cx="12" cy="12" r="3.2"/><ellipse cx="12" cy="12" rx="10" ry="4.8" transform="rotate(-24 12 12)"/><ellipse cx="12" cy="12" rx="8" ry="6.4" transform="rotate(55 12 12)"/>',
    eye: '<path d="M2 12s3.5-6 10-6 10 6 10 6-3.5 6-10 6S2 12 2 12Z"/><circle cx="12" cy="12" r="2.5"/>',
    backpack: '<path d="M8 5V4a4 4 0 0 1 8 0v1M6 7h12a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V9a2 2 0 0 1 2-2Z"/><path d="M4 12H2v5h2m16-5h2v5h-2M9 12h6v4H9z"/>',
    coin: '<circle cx="12" cy="12" r="9"/><path d="M15 8.5c-.7-.7-1.7-1-3-1-1.8 0-3 .9-3 2.2s1.1 1.8 3 2.3 3 1.1 3 2.4-1.3 2.3-3.2 2.3c-1.3 0-2.4-.4-3.2-1.2M12 5.5v13"/>',
    coins: '<ellipse cx="9" cy="6" rx="6" ry="3"/><path d="M3 6v5c0 1.7 2.7 3 6 3 1 0 1.9-.1 2.7-.4M3 9c0 1.7 2.7 3 6 3 1 0 1.9-.1 2.7-.4M15 11c3.3 0 6 1.3 6 3s-2.7 3-6 3-6-1.3-6-3 2.7-3 6-3Z"/><path d="M9 14v4c0 1.7 2.7 3 6 3s6-1.3 6-3v-4"/>',
    settings: '<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.9l.1.1-1.8 3.1-.2-.1a1.8 1.8 0 0 0-1.9.1 1.8 1.8 0 0 0-.9 1.6V22H9v-.3a1.8 1.8 0 0 0-2.8-1.5l-.2.1-1.8-3.1.1-.1a1.8 1.8 0 0 0-.9-3.1H3V10h.4a1.8 1.8 0 0 0 1-3.1l-.2-.1L6 3.7l.2.1a1.8 1.8 0 0 0 2.8-1.5V2h6v.3a1.8 1.8 0 0 0 2.8 1.5l.2-.1 1.8 3.1-.1.1a1.8 1.8 0 0 0 .9 3.1h.4v4h-.4a1.7 1.7 0 0 0-1.2 1Z"/>',
    recycle: '<path d="m7 5 2-3 3 5H9l-2 3-2-3Z"/><path d="M15 6h4l3 5-3 2-2-4h-4M17 16l-2 4H9l-1-3h4l2-3M5 14l-3 4 3 4h5l1-3H6l-2-3"/>',
    trophy: '<path d="M8 21h8M12 17v4M7 4h10v5a5 5 0 0 1-10 0V4Z"/><path d="M7 6H3v2a4 4 0 0 0 4 4m10-6h4v2a4 4 0 0 1-4 4"/>',
    sword: '<path d="m14 4 6-2-2 6-10 10-4-4L14 4Z"/><path d="m8 18-4 4m-1-7 4 4"/>',
    swords: '<path d="m4 3 7 7-3 3-7-7 3-3ZM14 13l7 7-3 3-7-7 3-3ZM18 3l3 2-2 8-3-3 2-7ZM6 14l-3 7 3 1 4-6"/>',
    image: '<rect x="3" y="4" width="18" height="16" rx="2"/><circle cx="8.5" cy="9" r="1.5"/><path d="m21 15-5-5L5 20"/>',
    close: '<path d="m6 6 12 12M18 6 6 18"/>',
    flame: '<path d="M12 22c4 0 7-3 7-7 0-3-2-5-4-7 0 3-1 4-2 4 0-5-3-8-5-10 0 5-1 7-3 10-2 4 0 10 7 10Z"/><path d="M12 22c-2 0-3-2-3-4 0-1.5 1-3 2-4 0 2 2 2 2 4s0 3-1 4Z"/>',
    snowflake: '<path d="M12 2v20M4 6l16 12M20 6 4 18M8 4l4 3 4-3M8 20l4-3 4 3M3 10l1-4 4 1m8 10 4 1 1-4M21 10l-1-4-4 1M3 14l1 4 4-1"/>',
    wand: '<path d="m4 20 12-12M14 4l1-2 1 2 2 1-2 1-1 2-1-2-2-1 2-1ZM20 13l.7 1.3L22 15l-1.3.7L20 17l-.7-1.3L18 15l1.3-.7L20 13ZM5 3l.8 1.7L7.5 5.5l-1.7.8L5 8l-.8-1.7-1.7-.8 1.7-.8L5 3Z"/>',
    bug: '<path d="M8 8 6 5m10 3 2-3M5 12H2m20 0h-3M5 17H2m20 0h-3M12 4a5 5 0 0 0-5 5v6a5 5 0 0 0 10 0V9a5 5 0 0 0-5-5ZM8 11h8m-8 4h8"/>',
    sun: '<circle cx="12" cy="12" r="4"/><path d="M12 2v2m0 16v2M4.9 4.9l1.4 1.4m11.4 11.4 1.4 1.4M2 12h2m16 0h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/>',
    stars: '<path d="m12 3 2 5.5 5.5 2-5.5 2L12 18l-2-5.5-5.5-2 5.5-2L12 3Z"/><path d="m19 15 .8 2.2L22 18l-2.2.8L19 21l-.8-2.2L16 18l2.2-.8L19 15ZM5 2l.6 1.4L7 4l-1.4.6L5 6l-.6-1.4L3 4l1.4-.6L5 2Z"/>',
    mouse: '<rect x="6" y="2" width="12" height="20" rx="6"/><path d="M12 2v6m-6 0h12"/>',
    pause: '<path d="M8 5v14M16 5v14"/>',
    play: '<path d="m7 4 13 8-13 8V4Z"/>',
    maximize: '<path d="M8 3H3v5m13-5h5v5M3 16v5h5m13-5v5h-5"/>',
    folder: '<path d="M3 6a2 2 0 0 1 2-2h5l2 2h7a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V6Z"/>',
    clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l4 2"/>',
    hourglass: '<path d="M6 3h12M6 21h12M7 3c0 5 5 5 5 9s-5 4-5 9m10-18c0 5-5 5-5 9s5 4 5 9"/>',
    lantern: '<path d="M9 3h6l2 4H7l2-4ZM7 7h10l-1 13H8L7 7ZM9 10h6m-6 3h6M10 1h4"/>',
    tooth: '<path d="M7 3C3 3 3 7 4 10l2 9c.4 2 2 3 3 1l2-5 2 5c1 2 2.6 1 3-1l4-9c1-3 0-7-4-7-2 0-3 1-5 1S9 3 7 3Z"/>',
    bolt: '<path d="m13 2-9 12h7l-1 8 10-13h-7l0-7Z"/>',
    fortune: '<path d="M12 3c-4 0-7 3-7 7 0 5 7 11 7 11s7-6 7-11c0-4-3-7-7-7Z"/><path d="M9 10h6m-3-3v7"/>',
    crystal: '<path d="m8 2 8 0 6 7-10 13L2 9l6-7Z"/><path d="M2 9h20M8 2l4 20 4-20M8 2l-1 7m9-7 1 7"/>',
    scroll: '<path d="M7 3h11a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H7a3 3 0 0 1-3-3V6a3 3 0 0 1 3-3Z"/><path d="M8 7h8m-8 4h8m-8 4h5"/>',
    grid: '<rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/>',
    atom: '<circle cx="12" cy="12" r="2"/><ellipse cx="12" cy="12" rx="10" ry="4" transform="rotate(60 12 12)"/><ellipse cx="12" cy="12" rx="10" ry="4" transform="rotate(-60 12 12)"/>',
    dragonEye: '<path d="M2 12s4-5 10-5 10 5 10 5-4 5-10 5S2 12 2 12Z"/><circle cx="12" cy="12" r="2"/><path d="M5 6 3 3m16 3 2-3"/>',
    shield: '<path d="M12 22s8-4 8-11V5l-8-3-8 3v6c0 7 8 11 8 11Z"/><path d="m9 12 2 2 4-4"/>',
    trending: '<path d="M3 17 9 11l4 4 8-9"/><path d="M15 6h6v6"/>',
    link: '<path d="M10 13a5 5 0 0 0 7.1 0l2.1-2.1a5 5 0 0 0-7.1-7.1l-1.2 1.2"/><path d="M14 11a5 5 0 0 0-7.1 0l-2.1 2.1a5 5 0 0 0 7.1 7.1l1.2-1.2"/>',
    moon: '<path d="M20.5 15.5A8.5 8.5 0 0 1 8.5 3.5 8.8 8.8 0 1 0 20.5 15.5Z"/><path d="m17 3 .7 2L20 5.7l-2.3.7L17 8.7l-.7-2.3-2.3-.7 2.3-.7L17 3Z"/>',
    arrowUp: '<path d="M12 20V4m-6 6 6-6 6 6"/>',
    chevronRight: '<path d="m9 18 6-6-6-6"/>',
    check: '<path d="m4 12 5 5L20 6"/>',
    timer: '<circle cx="12" cy="13" r="8"/><path d="M12 13 16 9M9 2h6m-3 0v3"/>',
    wrench: '<path d="M14 7a5 5 0 0 0-6 6l-5 5a2 2 0 0 0 3 3l5-5a5 5 0 0 0 6-6l-3 3-3-3 3-3Z"/>',
    target: '<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1"/>',
    book: '<path d="M4 4h12a3 3 0 0 1 3 3v13H7a3 3 0 0 1-3-3V4Z"/><path d="M7 20V7a3 3 0 0 1 3-3m0 6h5m-5 4h5"/>',
    gamepad: '<path d="M7 8h10a5 5 0 0 1 4.8 6.5l-1 3a2 2 0 0 1-3.3.8L15 16H9l-2.5 2.3a2 2 0 0 1-3.3-.8l-1-3A5 5 0 0 1 7 8Z"/><path d="M8 11v4m-2-2h4m6-1h.01M18 14h.01"/>',
    box: '<path d="m12 3 9 5-9 5-9-5 9-5Z"/><path d="M3 8v8l9 5 9-5V8M12 13v8"/>',
    wallet: '<rect x="3" y="5" width="18" height="15" rx="2"/><path d="M3 8h15a3 3 0 0 0 0-6H7a4 4 0 0 0-4 4Zm14 6h4m-4 0a1 1 0 1 0 0 .01"/>',
    wandSparkles: '<path d="m4 20 11-11M14 4l1-2 1 2 2 1-2 1-1 2-1-2-2-1 2-1ZM20 13l.7 1.3L22 15l-1.3.7L20 17l-.7-1.3L18 15l1.3-.7L20 13Z"/>',
    aperture: '<circle cx="12" cy="12" r="9"/><path d="m12 3 4 7h5m-1 6-8-1-2 6m-7-5 5-7-3-4m14 2-6 5 1 5"/>',
    taiji: '<circle cx="12" cy="12" r="10"/><path d="M12 2a5 5 0 0 1 0 10 5 5 0 0 0 0 10"/><circle cx="12" cy="7" r="1.2" fill="currentColor"/><circle cx="12" cy="17" r="1.2" fill="currentColor"/><path d="M12 2a10 10 0 0 1 0 20"/>',
    blank: '<circle cx="12" cy="12" r="8"/>'
  };
  const aliases = {
    star: 'sparkle', starCore: 'stars', skillMana: 'energy', celestial: 'galaxy', background: 'galaxy',
    flexBlock: 'flex', bag: 'backpack', gold: 'coins', essence: 'crystal', recycle: 'recycle',
    close: 'close', blackHole: 'blackhole', hourglass: 'hourglass', settings: 'settings',
    moonStars: 'moon', specialNova: 'burst', aether: 'energy', prism: 'diamond', spell: 'wandSparkles',
    money: 'coins', strength: 'flex', eye: 'eye', save: 'download', restore: 'upload',
    continue: 'play', fullscreen: 'maximize', pause: 'pause', time: 'clock', runeEye: 'eye',
    bossFang: 'tooth', stellarLedger: 'scroll', memoryCrystal: 'crystal', dimension: 'grid',
    defense: 'shield', spellbook: 'book', upgrade: 'levelup', power: 'bolt', swap: 'swap'
  };
  function svg(name, className = 'ui-icon') {
    const raw = String(name || 'sparkles');
    const key = aliases[raw] || raw;
    const body = paths[key] || paths.sparkles;
    const classes = String(className || 'ui-icon').replace(/[^a-zA-Z0-9 _-]/g, ' ').trim() || 'ui-icon';
    return `<svg class="ui-icon ${classes}" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">${body}</svg>`;
  }
  function mount(root = document) {
    if (!root || !root.querySelectorAll) return;
    root.querySelectorAll('[data-svg-icon]').forEach(slot => {
      if (slot.dataset.svgMounted === '1') return;
      slot.innerHTML = svg(slot.dataset.svgIcon || 'sparkles');
      slot.dataset.svgMounted = '1';
    });
  }
  if (document.head && !document.getElementById('nebulaSvgIconStyles')) {
    const style = document.createElement('style');
    style.id = 'nebulaSvgIconStyles';
    style.textContent = '.ui-icon{width:1em;height:1em;display:inline-block;flex:0 0 auto;vertical-align:-.16em;overflow:visible}.inline-icon{display:inline-flex;align-items:center;justify-content:center;vertical-align:middle;line-height:0}.inline-icon>.ui-icon{width:1em;height:1em}[data-svg-icon]{vertical-align:middle}';
    document.head.appendChild(style);
  }
  window.NebulaIcons = Object.freeze({ svg, mount });
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', () => mount(document), { once: true });
  else mount(document);
})();
