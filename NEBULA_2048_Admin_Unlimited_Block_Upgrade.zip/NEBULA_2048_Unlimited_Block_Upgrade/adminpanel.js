/*
 * NEBULA 2048 — Optional Admin Panel
 * Place this file next to index.html to enable the testing menu.
 * Remove this file (and reload) to hide the menu completely.
 */
(() => {
  'use strict';

  const api = window.NEBULA_GAME_API;
  if (!api) return;

  const style = document.createElement('style');
  style.id = 'nebulaAdminStyles';
  style.textContent = `
    #nebulaAdminToggle{position:fixed;z-index:10000;right:16px;bottom:18px;display:flex;align-items:center;gap:8px;border:1px solid rgba(94,231,247,.42);border-radius:14px;padding:11px 15px;color:#e9fbff;background:linear-gradient(135deg,rgba(12,27,48,.98),rgba(39,25,76,.98));box-shadow:0 10px 35px rgba(0,0,0,.4),0 0 22px rgba(94,231,247,.15);font:800 12px/1.1 system-ui,sans-serif;letter-spacing:.08em;cursor:pointer;backdrop-filter:blur(14px)}
    #nebulaAdminToggle .admin-led{width:8px;height:8px;border-radius:50%;background:#6ee7b7;box-shadow:0 0 12px #6ee7b7}
    #nebulaAdminPanel{position:fixed;z-index:9999;right:16px;bottom:76px;width:min(390px,calc(100vw - 24px));max-height:min(760px,calc(100dvh - 104px));overflow:auto;overscroll-behavior:contain;display:none;color:#eaf1ff;background:rgba(8,13,25,.97);border:1px solid rgba(148,163,184,.24);border-radius:18px;box-shadow:0 24px 80px rgba(0,0,0,.58),0 0 35px rgba(94,231,247,.09);backdrop-filter:blur(20px);font:12px/1.45 system-ui,sans-serif}
    #nebulaAdminPanel.open{display:block;animation:nebulaAdminIn .18s ease-out}
    @keyframes nebulaAdminIn{from{opacity:0;transform:translateY(9px) scale(.985)}to{opacity:1;transform:translateY(0) scale(1)}}
    #nebulaAdminPanel *{box-sizing:border-box}
    #nebulaAdminPanel .admin-head{position:sticky;top:0;z-index:2;display:flex;align-items:center;justify-content:space-between;gap:10px;padding:14px 15px;border-bottom:1px solid rgba(148,163,184,.16);background:rgba(11,18,33,.97)}
    #nebulaAdminPanel .admin-title{margin:0;font-size:13px;letter-spacing:.09em;font-weight:900}
    #nebulaAdminPanel .admin-subtitle{margin-top:3px;color:#94a3b8;font-size:10px}
    #nebulaAdminPanel .admin-close{border:1px solid rgba(148,163,184,.2);border-radius:9px;background:#172237;padding:6px 10px;color:#dce8ff;cursor:pointer}
    #nebulaAdminPanel .admin-body{padding:12px;display:grid;gap:10px}
    #nebulaAdminPanel .admin-card{padding:11px;border:1px solid rgba(148,163,184,.14);border-radius:12px;background:linear-gradient(140deg,rgba(20,30,50,.82),rgba(13,20,34,.76))}
    #nebulaAdminPanel .admin-card h3{margin:0 0 9px;font-size:11px;letter-spacing:.08em;text-transform:uppercase;color:#b9c8e3}
    #nebulaAdminPanel .admin-stats{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:6px}
    #nebulaAdminPanel .admin-stat{padding:8px;border-radius:9px;background:rgba(100,116,139,.1);min-width:0}
    #nebulaAdminPanel .admin-stat small{display:block;color:#91a0bb;font-size:9px;text-transform:uppercase;letter-spacing:.05em}
    #nebulaAdminPanel .admin-stat strong{display:block;margin-top:3px;overflow-wrap:anywhere;color:#f1f6ff;font-size:13px}
    #nebulaAdminPanel .admin-row{display:flex;align-items:center;gap:7px;flex-wrap:wrap}
    #nebulaAdminPanel .admin-row>*{min-width:0}
    #nebulaAdminPanel .admin-row .grow{flex:1 1 100px}
    #nebulaAdminPanel .admin-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:7px}
    #nebulaAdminPanel label{display:grid;gap:4px;color:#a9b7cf;font-size:10px}
    #nebulaAdminPanel input[type=number],#nebulaAdminPanel select{width:100%;min-height:34px;color:#e8f1ff;background:#101a2d;border:1px solid rgba(148,163,184,.24);border-radius:8px;padding:7px 8px;font:inherit;outline:none}
    #nebulaAdminPanel input:focus,#nebulaAdminPanel select:focus{border-color:#5ee7f7;box-shadow:0 0 0 2px rgba(94,231,247,.1)}
    #nebulaAdminPanel .admin-check{display:flex;align-items:center;gap:8px;margin-bottom:8px;padding:8px 9px;border:1px solid rgba(248,201,107,.22);border-radius:9px;background:rgba(248,201,107,.055);color:#ffe8ad;font-weight:800}
    #nebulaAdminPanel .admin-check input{accent-color:#f8c96b;width:16px;height:16px}
    #nebulaAdminPanel .admin-btn{min-height:34px;padding:8px 10px;border:1px solid rgba(94,231,247,.2);border-radius:9px;background:rgba(35,54,78,.78);color:#e8f8ff;font:800 10px/1.2 system-ui,sans-serif;cursor:pointer;transition:transform .12s ease,border-color .12s ease,background .12s ease}
    #nebulaAdminPanel .admin-btn:hover{transform:translateY(-1px);border-color:rgba(94,231,247,.55);background:rgba(42,67,93,.95)}
    #nebulaAdminPanel .admin-btn.primary{color:#07131c;border:0;background:linear-gradient(115deg,#5ee7f7,#a78bfa)}
    #nebulaAdminPanel .admin-btn.gold{border-color:rgba(248,201,107,.32);background:rgba(112,78,24,.24)}
    #nebulaAdminPanel .admin-btn.danger{border-color:rgba(251,113,133,.28);background:rgba(124,31,55,.28)}
    #nebulaAdminPanel .admin-note{color:#8190aa;font-size:10px;line-height:1.5;margin-top:7px}
    #nebulaAdminPanel .admin-status{padding:8px 9px;background:rgba(110,231,183,.07);border:1px solid rgba(110,231,183,.17);border-radius:8px;color:#a7f3d0;font-size:10px}
    #nebulaAdminPanel .admin-footer{padding:0 13px 13px;color:#64748b;font-size:9px}
    @media(max-width:760px){#nebulaAdminToggle{right:10px;bottom:calc(88px + env(safe-area-inset-bottom));padding:10px 12px}#nebulaAdminPanel{right:8px;bottom:calc(142px + env(safe-area-inset-bottom));width:calc(100vw - 16px);max-height:calc(100dvh - 165px);border-radius:15px}#nebulaAdminPanel .admin-body{padding:9px;gap:8px}#nebulaAdminPanel .admin-card{padding:9px}}
  `;
  document.head.appendChild(style);

  const toggle = document.createElement('button');
  toggle.id = 'nebulaAdminToggle';
  toggle.type = 'button';
  toggle.innerHTML = '<span class="admin-led"></span><span>ADMIN</span>';
  toggle.setAttribute('aria-controls', 'nebulaAdminPanel');
  toggle.setAttribute('aria-expanded', 'false');
  toggle.title = 'Mở công cụ kiểm thử';

  const panel = document.createElement('section');
  panel.id = 'nebulaAdminPanel';
  panel.setAttribute('aria-label', 'NEBULA Admin Panel');
  panel.innerHTML = `
    <div class="admin-head">
      <div><h2 class="admin-title">${window.NebulaIcons.svg('sparkle')} NEBULA / ADMIN</h2><div class="admin-subtitle">Bảng điều khiển kiểm thử cục bộ</div></div>
      <button class="admin-close" id="adminClose" type="button">${window.NebulaIcons.svg('close')} Đóng</button>
    </div>
    <div class="admin-body">
      <div class="admin-card">
        <h3>Trạng thái game</h3>
        <div class="admin-stats">
          <div class="admin-stat"><small>Điểm</small><strong id="adminScore">0</strong></div>
          <div class="admin-stat"><small>Vàng</small><strong id="adminGold">0</strong></div>
          <div class="admin-stat"><small>Linh thạch</small><strong id="adminEssence">0</strong></div>
          <div class="admin-stat"><small>Cấp</small><strong id="adminLevel">Lv. 1</strong></div>
          <div class="admin-stat"><small>Ô lớn nhất</small><strong id="adminMaxTile">2</strong></div>
          <div class="admin-stat"><small>Bàn cờ</small><strong id="adminBoard">4×4</strong></div>
          <div class="admin-stat"><small>Số lần tái sinh</small><strong id="adminPrestigeCount">0</strong></div>
          <div class="admin-stat"><small>Hệ số bán kho</small><strong id="adminSaleMultiplier">×1</strong></div>
        </div>
      </div>

      <div class="admin-card">
        <h3>Chuyển Sinh / kiểm thử kinh tế</h3>
        <div class="admin-grid">
          <label>Số lần tái sinh<input id="adminSetPrestigeCount" type="number" min="0" max="1000000000000" step="1" value="0"></label>
          <label>Vàng cần cho lần kế tiếp<input id="adminNextPrestigeCost" type="text" value="1.000" readonly></label>
        </div>
        <div class="admin-row" style="margin-top:8px">
          <button class="admin-btn primary grow" id="adminApplyPrestigeCount" type="button">Áp dụng số lần tái sinh</button>
          <button class="admin-btn gold grow" id="adminQuickPrestige1" type="button">Đặt = 1</button>
          <button class="admin-btn gold grow" id="adminQuickPrestige5" type="button">Đặt = 5</button>
        </div>
        <div class="admin-note">Chỉ dành cho kiểm thử: hệ số bán kho theo số lần tái sinh là 0 lần ×1, lần 1 ×1, lần 2 ×2, lần 3 ×4, lần 4 ×8, lần 5 ×16, lần 6 ×32...; điều kiện vàng lần lượt là 1.000, 2.000, 4.000, 8.000... Không cấp Linh Thạch hoặc chạy reset lượt như tái sinh thật.</div>
      </div>

      <div class="admin-card">
        <h3>Chế độ kiểm thử</h3>
        <label class="admin-check"><input id="adminGodMode" type="checkbox"> God Mode — Mana/kỹ năng miễn phí, mua nâng cấp không tốn tài nguyên</label>
        <div class="admin-row">
          <label class="grow">Đặt cấp nhân vật<input id="adminSetLevel" type="number" min="1" max="9999" value="10"></label>
          <button class="admin-btn" id="adminSetLevelBtn" type="button">Áp dụng cấp</button>
        </div>
        <div class="admin-note">God Mode chỉ có hiệu lực trong phiên trình duyệt hiện tại, không ghi vào bản lưu.</div>
      </div>

      <div class="admin-card">
        <h3>Skill Admin · Nâng cấp khối tự do</h3>
        <label>Số lần nhân đôi mỗi lần chọn<input id="adminBlockUpgradeTimes" type="number" min="1" max="100000" step="1" value="10"></label>
        <div class="admin-row" style="margin-top:8px">
          <button class="admin-btn primary grow" id="adminArmBlockUpgrade" type="button">${window.NebulaIcons.svg('levelup')} Chọn khối để nâng cấp</button>
          <button class="admin-btn" id="adminCancelBlockUpgrade" type="button">Hủy chọn</button>
        </div>
        <div class="admin-note">Bấm chọn khối rồi bấm vào một ô có số trên bàn cờ. Mỗi lần tương đương nhân đôi giá trị một lần (×2), không tốn Mana hay tài nguyên. Tối đa 100.000 lần trong một thao tác để bảo vệ trình duyệt; có thể dùng lại liên tiếp mà không giới hạn tổng số lần. Nhấn Esc để hủy.</div>
      </div>

      <div class="admin-card">
        <h3>Cấp tài nguyên</h3>
        <div class="admin-grid">
          <label>Vàng<input id="adminGrantGold" type="number" min="0" value="10000"></label>
          <label>Linh thạch<input id="adminGrantEssence" type="number" min="0" value="100"></label>
          <label>EXP<input id="adminGrantExp" type="number" min="0" value="1000"></label>
          <label>Mana<input id="adminGrantMana" type="number" min="0" value="100"></label>
          <label>Điểm<input id="adminGrantScore" type="number" min="0" value="5000"></label>
        </div>
        <div style="margin-top:8px"><button class="admin-btn primary" id="adminGrantBtn" type="button">＋ Cấp tài nguyên</button></div>
      </div>

      <div class="admin-card">
        <h3>Tạo ô để thử</h3>
        <div class="admin-grid">
          <label>Giá trị ô (số bất kỳ)<input id="adminTileValue" type="text" inputmode="text" value="2048" list="adminTileValueSuggestions" autocomplete="off"><datalist id="adminTileValueSuggestions"><option value="2"><option value="2048"><option value="65536"><option value="1048576"><option value="2^100"><option value="2^500"><option value="2^1000"><option value="2^10000"></datalist></label>
          <label>Loại ô<select id="adminTileType"><option value="">Ô thường</option><option value="prism">Lăng Kính</option><option value="nova">Siêu Tân Tinh</option><option value="aether">Tinh Thể Lam</option></select></label>
        </div>
        <label class="admin-check" style="margin-top:8px;margin-bottom:8px"><input id="adminTileRune" type="checkbox"> Gắn Linh Ấn</label>
        <div class="admin-row"><button class="admin-btn primary grow" id="adminSpawnTile" type="button">Tạo ô trên bàn cờ</button><button class="admin-btn" id="adminFillBoard" type="button">Lấp kín bàn</button></div>
        <div class="admin-note">Nhập số nguyên đầy đủ, hoặc dạng 2^1000 (giá trị 2 mũ 1000). Hệ thống dùng BigInt nên giá trị ô không bị giới hạn ở 1e308; số mũ nhập từ 1 đến 100.000. Nếu bàn đã kín, tạo ô sẽ thay thế ngẫu nhiên một vị trí.</div>
      </div>

      <div class="admin-card">
        <h3>Kiểm thử hiệu ứng gộp</h3>
        <div class="admin-row">
          <label class="grow">Mốc hiệu ứng<select id="adminEffectValue"><option value="16">16 · Nhẹ</option><option value="64">64 · Lam</option><option value="256">256 · Tím</option><option value="1024">1.024 · Bùng nổ</option><option value="2048" selected>2.048 · Huyền thoại</option><option value="4096">4.096 · Cosmic</option><option value="16384">16.384 · Singularity</option><option value="65536">65.536 · Apotheosis</option><option value="262144">262.144 · Siêu cấp</option><option value="1048576">1.048.576 · Cực hạn</option></select></label>
          <button class="admin-btn gold" id="adminTestFx" type="button">${window.NebulaIcons.svg('sparkles')} Chạy FX</button>
        </div>
        <div class="admin-note">Chạy hiệu ứng trực tiếp để xem trước, không cộng điểm hay thay đổi bàn cờ.</div>
      </div>

      <div class="admin-card">
        <h3>Boss / trạng thái</h3>
        <div class="admin-row"><button class="admin-btn primary grow" id="adminSpawnBoss" type="button">${window.NebulaIcons.svg('skull')} Triệu hồi Boss</button><button class="admin-btn gold grow" id="adminDamageBoss" type="button">${window.NebulaIcons.svg('swords')} Gây 50 sát thương</button><button class="admin-btn danger grow" id="adminKillBoss" type="button">${window.NebulaIcons.svg('skull')} Hạ Boss</button></div>
        <div class="admin-row" style="margin-top:7px"><button class="admin-btn grow" id="adminGameOver" type="button">Thử Game Over</button><button class="admin-btn grow" id="adminClearBoard" type="button">Xóa bàn & tạo lại</button></div>
      </div>

      <div class="admin-card">
        <h3>Vòng chơi</h3>
        <div class="admin-row"><button class="admin-btn grow" id="adminRestartRun" type="button">Khởi động lượt mới</button><button class="admin-btn danger grow" id="adminResetAll" type="button">Reset toàn bộ save</button></div>
        <div class="admin-note">Reset toàn bộ sẽ xóa tiến trình NEBULA 2048 đã lưu trong trình duyệt này.</div>
      </div>
      <div class="admin-card">
        <h3>ADMIN / Save & công thức</h3>
        <div class="admin-row"><button class="admin-btn grow" id="adminInspectSave" type="button">Xem save</button><button class="admin-btn grow" id="adminValidateSave" type="button">Kiểm tra toàn vẹn</button><button class="admin-btn gold grow" id="adminBackupNow" type="button">Sao lưu thủ công</button><button class="admin-btn danger grow" id="adminRestoreBackup" type="button">Phục hồi dự phòng</button></div>
        <div class="admin-row" style="margin-top:7px"><label class="grow">Số lần mô phỏng<input id="adminSimulateCount" type="number" min="1" max="500" value="25"></label><button class="admin-btn grow" id="adminSimulateMerges" type="button">TEST mô phỏng gộp</button><button class="admin-btn grow" id="adminCheckFormulas" type="button">TEST công thức</button></div>
        <div class="admin-note">Các nút TEST đánh dấu rõ thao tác kiểm thử. Phục hồi dự phòng sẽ thay trạng thái đang chơi bằng bản sao lưu cục bộ.</div>
      </div>
      <div class="admin-status" id="adminStatus">Admin Panel đã được nạp từ adminpanel.js.</div>
    </div>
    <div class="admin-footer">LOCAL TEST TOOLS · Tệp tùy chọn · Không gửi dữ liệu ra ngoài</div>
  `;

  document.body.append(toggle, panel);

  const $ = id => panel.querySelector(`#${id}`);
  const BIG_SUFFIXES = [null, "K", "M", "B", "T", "Qa", "Qi", "Sx", "Sp", "Oc", "No", "De", "Ud", "Dd", "Td", "Qad", "Qid", "Sxd", "Spd", "Ocd", "Nod", "Vig", "Uv", "Dv", "Tv", "Qav", "Qiv", "Sxv", "Spv", "Ocv", "Nov", "Tri", "Utr", "Dtr", "Ttr", "Qatr", "Qitr", "Sxtr", "Sptr", "Octr", "Notr", "Qag", "Uqa", "Dqa", "Tqa", "Qaqa", "Qiqa", "Sxqa", "Spqa", "Ocqa", "Noqa", "Qig", "Uqi", "Dqi", "Tqi", "Qaqi", "Qiqi", "Sxqi", "Spqi", "Ocqi", "Noqi", "Sex", "Use", "Dse", "Tse", "Qase", "Qise", "Sxse", "Spse", "Ocse", "Nose", "Sep", "Usp", "Dsp", "Tsp", "Qasp", "Qisp", "Sxsp", "Spsp", "Ocsp", "Nosp", "Oct", "Uoc", "Doc", "Toc", "Qaoc", "Qioc", "Sxoc", "Spoc", "Ococ", "Nooc", "Non", "Unn", "Dnn", "Tnn", "Qann", "Qinn", "Sxnn", "Spnn", "Ocnn", "Nonn", "Cen", "Uc"];
  const fmt = value => {
    const text = typeof value === 'bigint' ? value.toString() : String(value ?? '0').trim().replaceAll(',', '');
    if (/^-?\d+$/.test(text)) {
      if (text.startsWith('-')) return '-' + fmt(text.slice(1));
      if (BigInt(text) < 1000n) return text.replace(/\B(?=(\d{3})+(?!\d))/g, ',');
      const exponent = Math.floor((text.length - 1) / 3) * 3;
      const suffix = BIG_SUFFIXES[exponent / 3];
      if (suffix && exponent <= 306) {
        const wholeDigits = text.length - exponent;
        const decimals = exponent === 3 ? 1 : 2;
        const keep = wholeDigits + decimals;
        const leading = text.slice(0, keep).padEnd(keep, '0');
        let rounded = BigInt(leading || '0');
        if (text.length > keep && text.charCodeAt(keep) >= 53) rounded += 1n;
        let fixed = rounded.toString().padStart(keep, '0');
        fixed = fixed.length <= decimals
          ? '0.' + fixed.padStart(decimals, '0')
          : fixed.slice(0, -decimals) + '.' + fixed.slice(-decimals);
        return fixed + suffix;
      }
      return `${text[0]}${text.length > 1 ? '.' + text.slice(1, 3).padEnd(2, '0') : ''}e${text.length - 1}`;
    }
    const n = Number(value) || 0;
    return Number.isFinite(n) ? Math.floor(n).toLocaleString('vi-VN') : '0';
  };
  const number = id => Math.max(0, Math.floor(Number($(id).value) || 0));
  const rawText = id => $(id).value.trim();
  const announce = message => { $('adminStatus').textContent = message; refreshStats(); };
  function refreshStats() {
    const s = api.getState();
    $('adminScore').textContent = fmt(s.score);
    $('adminGold').textContent = fmt(s.gold);
    $('adminEssence').textContent = fmt(s.essence);
    $('adminLevel').textContent = `Lv. ${fmt(s.level)}`;
    $('adminMaxTile').textContent = fmt(s.maxTile);
    $('adminBoard').textContent = `${s.size}×${s.size} · ${s.boardTiles} ô`;
    $('adminPrestigeCount').textContent = fmt(s.prestigeCount || 0);
    $('adminSaleMultiplier').textContent = `×${fmt(s.salePrestigeMultiplier || 1)}`;
    if (document.activeElement !== $('adminSetPrestigeCount')) {
      $('adminSetPrestigeCount').value = String(Math.max(0, Math.floor(Number(s.prestigeCount) || 0)));
    }
    $('adminNextPrestigeCost').value = fmt(s.nextPrestigeGoldRequirement || 1000);
    $('adminGodMode').checked = !!s.godMode;
  }
  function setOpen(open) {
    panel.classList.toggle('open', !!open);
    toggle.setAttribute('aria-expanded', String(!!open));
    toggle.innerHTML = open ? '<span class="admin-led"></span><span>ADMIN / ON</span>' : '<span class="admin-led"></span><span>ADMIN</span>';
    if (open) refreshStats();
  }
  toggle.addEventListener('click', () => setOpen(!panel.classList.contains('open')));
  $('adminClose').addEventListener('click', () => setOpen(false));
  $('adminGodMode').addEventListener('change', event => {
    const enabled = Boolean(event.target.checked);
    api.setGodMode(enabled);
    refreshStats();
    announce(enabled ? 'God Mode đã bật: kỹ năng và nâng cấp miễn phí.' : 'God Mode đã tắt.');
  });
  $('adminSetLevelBtn').addEventListener('click', () => {
    const level = Math.max(1, Math.min(9999, number('adminSetLevel')));
    const appliedLevel = api.setLevel(level);
    $('adminSetLevel').value = String(appliedLevel);
    refreshStats();
    announce(`Đã đặt cấp nhân vật thành Lv. ${appliedLevel}.`);
  });
  $('adminArmBlockUpgrade').addEventListener('click', () => {
    const raw = number('adminBlockUpgradeTimes');
    const times = Math.max(1, Math.min(100000, raw || 1));
    $('adminBlockUpgradeTimes').value = String(times);
    const armed = api.armAdminBlockUpgrade(times);
    if (armed) {
      announce(`Skill Admin sẵn sàng: chọn một khối để nhân đôi ${fmt(times)} lần.`);
      setOpen(false);
    }
  });
  $('adminCancelBlockUpgrade').addEventListener('click', () => {
    api.cancelAdminBlockUpgrade();
    announce('Đã hủy chế độ chọn khối nâng cấp.');
  });
  $('adminGrantBtn').addEventListener('click', () => {
    api.grantResources({ gold: number('adminGrantGold'), essence: number('adminGrantEssence'), exp: number('adminGrantExp'), mana: number('adminGrantMana'), score: number('adminGrantScore') });
    announce('Đã cấp tài nguyên cho phiên kiểm thử.');
  });
  function applyPrestigeCount(value) {
    const count = Math.max(0, Math.min(1e12, Math.floor(Number(value) || 0)));
    api.setPrestigeCount(count);
    const updated = api.getState();
    announce(`Đã đặt số lần tái sinh = ${fmt(count)}; hệ số bán kho hiện tại ×${fmt(updated.salePrestigeMultiplier || 1)}.`);
  }
  $('adminApplyPrestigeCount').addEventListener('click', () => applyPrestigeCount($('adminSetPrestigeCount').value));
  $('adminQuickPrestige1').addEventListener('click', () => applyPrestigeCount(1));
  $('adminQuickPrestige5').addEventListener('click', () => applyPrestigeCount(5));
  $('adminSpawnTile').addEventListener('click', () => {
    const index = api.spawnTile({ value: rawText('adminTileValue'), type: $('adminTileType').value, rune: $('adminTileRune').checked });
    announce(`Đã tạo ô kiểm thử tại vị trí ${index + 1}.`);
  });
  $('adminFillBoard').addEventListener('click', () => {
    const value = rawText('adminTileValue');
    api.fillBoard(value); announce(`Đã lấp bàn cờ bằng giá trị ${value}.`);
  });
  $('adminTestFx').addEventListener('click', () => {
    const value = number('adminEffectValue'); api.testEffect(value);
    announce(`Đã chạy hiệu ứng gộp ô ${fmt(value)} (không đổi điểm/bàn cờ).`);
  });
  $('adminSpawnBoss').addEventListener('click', () => { const ok = api.summonBoss(); announce(ok ? 'Đã triệu hồi Boss.' : 'Không thể triệu hồi thêm Boss khi Boss hiện tại còn sống.'); });
  $('adminDamageBoss').addEventListener('click', () => { const ok = api.damageBoss(50); announce(ok ? 'Đã gây 50 sát thương lên Boss.' : 'Chưa có Boss để tấn công.'); });
  $('adminKillBoss').addEventListener('click', () => { const ok = api.damageBoss(1e12); announce(ok ? 'Đã gửi sát thương kết liễu Boss.' : 'Chưa có Boss để kết liễu.'); });
  $('adminGameOver').addEventListener('click', () => { api.forceGameOver(); announce('Đã bật trạng thái Game Over để kiểm thử màn hình kết thúc.'); });
  $('adminClearBoard').addEventListener('click', () => { api.clearBoard(); announce('Bàn cờ đã được làm mới với hai ô khởi đầu.'); });
  $('adminRestartRun').addEventListener('click', () => {
    if (!window.confirm('Khởi động lượt mới? Nâng cấp vĩnh viễn, Di Vật và kỷ lục vẫn được giữ.')) return;
    api.restartRun(); announce('Đã bắt đầu lượt mới.');
  });
  $('adminResetAll').addEventListener('click', () => {
    if (!window.confirm('RESET TOÀN BỘ tiến trình đang lưu? Thao tác này không thể hoàn tác.')) return;
    api.resetAll(); announce('Đã tạo tiến trình mới và lưu lại game.');
  });
  $('adminInspectSave').addEventListener('click', () => { const s = api.inspectSave(); announce(`Save ${s.key} · schema ${s.schemaVersion} · chính ${s.primaryBytes} bytes (${s.validPrimary ? 'hợp lệ' : 'lỗi'}) · dự phòng ${s.backupBytes} bytes (${s.validBackup ? 'hợp lệ' : 'lỗi'}).`); });
  $('adminValidateSave').addEventListener('click', () => { const s = api.validateSave(); announce(s.healthy ? 'ADMIN TEST: có ít nhất một bản lưu hợp lệ.' : 'ADMIN TEST: không tìm thấy bản lưu hợp lệ.'); });
  $('adminBackupNow').addEventListener('click', () => { api.backupNow(); announce('ADMIN TEST: đã tạo bản sao lưu thủ công.'); });
  $('adminRestoreBackup').addEventListener('click', () => { if (window.confirm('Phục hồi bản dự phòng và thay trạng thái hiện tại?')) announce(api.restoreBackup() ? 'ADMIN TEST: đã phục hồi dự phòng.' : 'ADMIN TEST: không thể phục hồi dự phòng.'); });
  $('adminSimulateMerges').addEventListener('click', () => { const count = Math.max(1, Math.min(500, number('adminSimulateCount'))); api.simulateMerges(count); announce(`ADMIN TEST: đã mô phỏng ${count} lần hợp nhất.`); });
  $('adminCheckFormulas').addEventListener('click', () => { const f = api.checkFormulas(); announce(`ADMIN TEST: 0/1/2/3/7/1000 lần CS có hệ số bán ${f.multipliers.map(x => `×${fmt(x.sale)}`).join(', ')}. Định dạng lớn: ${f.formats.join(' · ')}.`); });
  document.addEventListener('keydown', event => {
    if (event.ctrlKey && event.shiftKey && event.key.toLowerCase() === 'a') {
      event.preventDefault(); setOpen(!panel.classList.contains('open'));
    }
    if (event.key === 'Escape' && panel.classList.contains('open')) setOpen(false);
  });
  window.setInterval(() => { if (panel.classList.contains('open')) refreshStats(); }, 1300);
  refreshStats();
})();
