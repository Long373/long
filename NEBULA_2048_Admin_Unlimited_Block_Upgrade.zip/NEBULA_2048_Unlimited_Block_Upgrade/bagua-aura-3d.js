/* NEBULA 2048 — Ultimate 3D Bagua aura.
 * One transparent WebGL overlay renders all tiles at/above 10^306, instead of
 * creating an independent renderer for every tile. CSS 3D remains as fallback. */
(function () {
  'use strict';

  function boot() {
    const THREE = window.THREE;
    const wrap = document.getElementById('boardWrap');
    const board = document.getElementById('board');
    if (!wrap || !board || !THREE || !THREE.WebGLRenderer) return;

    let renderer = null;
    let scene = null;
    let camera = null;
    let canvas = null;
    let frameId = 0;
    let lastTime = 0;
    let lastRenderTime = 0;
    const FRAME_INTERVAL_MS = 1000 / 30;
    let pixelWidth = 0;
    let pixelHeight = 0;
    let layoutDirty = true;
    let cachedCanvasRect = null;
    const auraByIndex = new Map();
    const textureCache = new Map();
    const geometryCache = new Map();
    const materialCache = new Map();
    const reducedMotion = !!(window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches);

    function textureFor(text, color, fontSize, family) {
      const key = [text, color, fontSize, family].join('|');
      if (textureCache.has(key)) return textureCache.get(key);
      const c = document.createElement('canvas');
      // The trigrams are displayed small around a tile; 128px textures retain crisp edges
      // while halving texture memory and upload size compared with the former 256px maps.
      c.width = 128; c.height = 128;
      const ctx = c.getContext('2d');
      ctx.clearRect(0, 0, c.width, c.height);
      const texture = new THREE.CanvasTexture(c);
      if (text === 'taiji-svg') {
        // Render the central seal from a local SVG data URL rather than relying on a system emoji font.
        const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 128 128"><circle cx="64" cy="64" r="57" fill="none" stroke="${color}" stroke-width="4"/><path d="M64 7 A57 57 0 0 1 64 121 A28.5 28.5 0 0 1 64 64 A28.5 28.5 0 0 0 64 7 Z" fill="${color}"/><circle cx="64" cy="35.5" r="8" fill="#151322"/><circle cx="64" cy="92.5" r="8" fill="${color}"/></svg>`;
        const image = new Image();
        image.onload = () => { ctx.clearRect(0, 0, c.width, c.height); ctx.drawImage(image, 5, 5, 118, 118); texture.needsUpdate = true; };
        image.src = `data:image/svg+xml;charset=utf-8,${encodeURIComponent(svg)}`;
      } else {
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.font = `900 ${Math.max(10, Math.min(fontSize * 0.5, 76))}px ${family || 'serif'}`;
        ctx.shadowColor = color;
        ctx.shadowBlur = 12;
        ctx.fillStyle = color;
        ctx.fillText(text, 64, 64);
        ctx.shadowBlur = 4;
        ctx.strokeStyle = 'rgba(255,255,255,.8)';
        ctx.lineWidth = .6;
        ctx.strokeText(text, 64, 64);
        texture.needsUpdate = true;
      }
      textureCache.set(key, texture);
      return texture;
    }

    function material(color, opacity, additive) {
      const key = `${color}:${opacity}:${!!additive}`;
      if (materialCache.has(key)) return materialCache.get(key);
      const mat = new THREE.MeshBasicMaterial({
        color,
        transparent: true,
        opacity,
        side: THREE.DoubleSide,
        depthWrite: false,
        depthTest: false,
        blending: additive ? THREE.AdditiveBlending : THREE.NormalBlending
      });
      materialCache.set(key, mat);
      return mat;
    }

    function lineMaterial(color, opacity) {
      const key = `line:${color}:${opacity}`;
      if (materialCache.has(key)) return materialCache.get(key);
      const mat = new THREE.LineBasicMaterial({
        color,
        transparent: true,
        opacity,
        depthWrite: false,
        depthTest: false,
        blending: THREE.AdditiveBlending
      });
      materialCache.set(key, mat);
      return mat;
    }

    function torus(radius, tube, arc) {
      const key = `torus:${radius}:${tube}:${arc == null ? 6.283185307179586 : arc}`;
      // 96 segments are visually smooth at the rendered tile scale and reduce vertex work.
      if (!geometryCache.has(key)) geometryCache.set(key, new THREE.TorusGeometry(radius, tube, 7, 96, arc == null ? Math.PI * 2 : arc));
      return geometryCache.get(key);
    }

    function octagon(radius) {
      const key = `octagon:${radius}`;
      if (!geometryCache.has(key)) {
        const points = [];
        for (let i = 0; i < 8; i++) {
          const a = Math.PI / 8 + Math.PI * 2 * i / 8;
          points.push(new THREE.Vector3(Math.cos(a) * radius, Math.sin(a) * radius, 0));
        }
        geometryCache.set(key, new THREE.BufferGeometry().setFromPoints(points));
      }
      return geometryCache.get(key);
    }

    function spriteFor(text, color, fontSize, width, height, family) {
      const map = textureFor(text, color, fontSize, family);
      const spriteKey = `sprite:${text}:${color}:${fontSize}:${family || 'serif'}`;
      let mat = materialCache.get(spriteKey);
      if (!mat) {
        mat = new THREE.SpriteMaterial({
          map,
          transparent: true,
          opacity: 1,
          depthWrite: false,
          depthTest: false,
          blending: THREE.AdditiveBlending
        });
        materialCache.set(spriteKey, mat);
      }
      const sprite = new THREE.Sprite(mat);
      sprite.scale.set(width, height, 1);
      return sprite;
    }

    function paletteForStage(stage) {
      if (stage >= 4) {
        // Stage IV abandons the Bagua palette for a supermassive-black-hole look:
        // event-horizon black, hot amber accretion, photon white and ionized cyan.
        return { gold: 0xffa24d, light: 0xffe7d2, cyan: 0x6beeff, violet: 0x9268ff, rose: 0xff4c71, jade: 0x61f4ff, white: 0xf7fbff };
      }
      const palettes = [
        { gold: 0xffd36c, light: 0xffedb0, cyan: 0x50eaff, violet: 0xa77dff, rose: 0xff83df, jade: 0x62ffd1, white: 0xeaffff },
        { gold: 0xffd66b, light: 0xfff1c9, cyan: 0x66ffd7, violet: 0x9a83ff, rose: 0xff6a9e, jade: 0x56ffb0, white: 0xf4fffa },
        { gold: 0xfff0a6, light: 0xffffff, cyan: 0x6df7ff, violet: 0xec7cff, rose: 0xff4fba, jade: 0x8bffef, white: 0xffffff }
      ];
      return palettes[Math.max(0, (Math.max(1, stage) - 1) % palettes.length)];
    }

    const TRIGRAM_GLYPHS = ['☰', '☱', '☲', '☳', '☴', '☵', '☶', '☷'];
    const ARCANE_GLYPHS = ['✦', '✧', 'taiji-svg', '◈', '◇', '✥', '✺', '⊙'];

    function addRuneOrbit(root, radius, count, color, layers, speed, opts = {}) {
      const orbit = new THREE.Group();
      orbit.rotation.set(opts.rx == null ? .76 : opts.rx, opts.ry == null ? -.2 : opts.ry, opts.rz || 0);
      root.add(orbit);
      const glyphs = opts.glyphs || TRIGRAM_GLYPHS;
      for (let i = 0; i < count; i++) {
        const a = Math.PI * 2 * i / count;
        const sprite = spriteFor(glyphs[i % glyphs.length], `#${color.toString(16).padStart(6, '0')}`, opts.fontSize || 48, opts.width || .2, opts.height || .2, '"Segoe UI Symbol", "Noto Sans Symbols 2", serif');
        sprite.position.set(Math.cos(a) * radius, Math.sin(a) * radius, (i % 3 - 1) * (opts.depth || .09));
        sprite.renderOrder = 19;
        orbit.add(sprite);
      }
      layers.push({ object: orbit, speed, baseX: opts.rx == null ? .76 : opts.rx, baseY: opts.ry == null ? -.2 : opts.ry, wobble: opts.wobble || .055, phase: opts.phase || count * .13 });
      return orbit;
    }

    function addCrystalRing(root, radius, count, color, layers, speed, opts = {}) {
      const orbit = new THREE.Group();
      orbit.rotation.set(opts.rx == null ? .88 : opts.rx, opts.ry == null ? .25 : opts.ry, 0);
      root.add(orbit);
      const key = `bagua-crystal-geo:${opts.size || .085}`;
      if (!geometryCache.has(key)) geometryCache.set(key, new THREE.OctahedronGeometry(opts.size || .085, 0));
      const crystalMat = material(color, opts.opacity || .88, true);
      // Crystals share geometry/material. Instancing preserves the ring while reducing
      // dozens of draw calls to one, especially at the higher Bagua ranks.
      const crystals = new THREE.InstancedMesh(geometryCache.get(key), crystalMat, count);
      const dummy = new THREE.Object3D();
      for (let i = 0; i < count; i++) {
        const a = Math.PI * 2 * i / count;
        dummy.position.set(Math.cos(a) * radius, Math.sin(a) * radius, Math.sin(a * 2) * .22);
        dummy.rotation.set(a * .7, a * .45, a);
        dummy.scale.set(1, 1 + (i % 3) * .55, 1);
        dummy.updateMatrix();
        crystals.setMatrixAt(i, dummy.matrix);
      }
      crystals.instanceMatrix.needsUpdate = true;
      crystals.renderOrder = 15;
      orbit.add(crystals);
      layers.push({ object: orbit, speed, baseX: opts.rx == null ? .88 : opts.rx, baseY: opts.ry == null ? .25 : opts.ry, wobble: .045, phase: count * .19 });
      return orbit;
    }

    function addRayFan(root, count, innerRadius, outerRadius, color, opacity, layers, speed, opts = {}) {
      const geometryKey = `bagua-rayfan:${count}:${innerRadius}:${outerRadius}`;
      if (!geometryCache.has(geometryKey)) {
        const pts = [];
        for (let i = 0; i < count; i++) {
          const a = Math.PI * 2 * i / count;
          const inner = innerRadius + (i % 4) * .018;
          const outer = outerRadius - (i % 5) * .022;
          pts.push(new THREE.Vector3(Math.cos(a) * inner, Math.sin(a) * inner, (i % 3 - 1) * .025));
          pts.push(new THREE.Vector3(Math.cos(a) * outer, Math.sin(a) * outer, (i % 5 - 2) * .025));
        }
        geometryCache.set(geometryKey, new THREE.BufferGeometry().setFromPoints(pts));
      }
      const plane = new THREE.Group();
      plane.rotation.set(opts.rx == null ? 1.06 : opts.rx, opts.ry == null ? -.16 : opts.ry, 0);
      const rays = new THREE.LineSegments(geometryCache.get(geometryKey), lineMaterial(color, opacity));
      rays.renderOrder = 16;
      plane.add(rays);
      root.add(plane);
      layers.push({ object: plane, speed, baseX: opts.rx == null ? 1.06 : opts.rx, baseY: opts.ry == null ? -.16 : opts.ry, wobble: .035, phase: count * .07 });
      return plane;
    }

    function addOrbitalPearls(root, count, radius, palette, layers, speed, opts = {}) {
      const orbit = new THREE.Group();
      orbit.rotation.set(opts.rx == null ? .93 : opts.rx, opts.ry == null ? .11 : opts.ry, 0);
      root.add(orbit);
      const size = opts.size || .045;
      const geoKey = `bagua-pearl-geo:${size}`;
      if (!geometryCache.has(geoKey)) geometryCache.set(geoKey, new THREE.SphereGeometry(size, 10, 10));
      const geo = geometryCache.get(geoKey);
      const colors = [palette.gold, palette.cyan, palette.violet, palette.rose, palette.jade];
      // Keep the same five-color orbit, but group matching pearl colors into instanced meshes.
      // A 48-pearl rank now needs at most five draw calls instead of 48.
      const dummy = new THREE.Object3D();
      for (let colorIndex = 0; colorIndex < colors.length; colorIndex++) {
        const indices = [];
        for (let i = 0; i < count; i++) if (i % colors.length === colorIndex) indices.push(i);
        if (!indices.length) continue;
        const pearls = new THREE.InstancedMesh(geo, material(colors[colorIndex], .92, true), indices.length);
        indices.forEach((i, instanceIndex) => {
          const a = Math.PI * 2 * i / count;
          const r = radius + Math.sin(a * 3) * .08;
          dummy.position.set(Math.cos(a) * r, Math.sin(a) * r, Math.cos(a * 2) * (opts.depth || .18));
          dummy.rotation.set(0, 0, 0);
          dummy.scale.setScalar(i % 5 === 0 ? 1.65 : 1);
          dummy.updateMatrix();
          pearls.setMatrixAt(instanceIndex, dummy.matrix);
        });
        pearls.instanceMatrix.needsUpdate = true;
        orbit.add(pearls);
      }
      layers.push({ object: orbit, speed, baseX: opts.rx == null ? .93 : opts.rx, baseY: opts.ry == null ? .11 : opts.ry, wobble: .05, phase: count * .11 });
      return orbit;
    }

    function addStarCloud(root, index, count, radiusMin, radiusMax, color, layers, speed) {
      const positions = [];
      // Identical tier/radius clouds share one immutable geometry across tiles.
      // The old key included the board index and accumulated duplicate GPU buffers
      // whenever a max-aura tile moved to another cell.
      let seed = (count * 31 + Math.round(radiusMin * 1000) * 17 + Math.round(radiusMax * 1000) * 13 + 271) * 7919;
      function rnd() { seed = (seed * 16807) % 2147483647; return (seed - 1) / 2147483646; }
      for (let i = 0; i < count; i++) {
        const a = rnd() * Math.PI * 2;
        const r = radiusMin + rnd() * (radiusMax - radiusMin);
        positions.push(Math.cos(a) * r, Math.sin(a) * r, (rnd() - .5) * .8);
      }
      const key = `bagua-star-cloud:${count}:${radiusMin}:${radiusMax}`;
      if (!geometryCache.has(key)) {
        const geo = new THREE.BufferGeometry();
        geo.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
        geometryCache.set(key, geo);
      }
      const cloudMatKey = `bagua-star-cloud-mat:${color}:${count}`;
      if (!materialCache.has(cloudMatKey)) materialCache.set(cloudMatKey, new THREE.PointsMaterial({ color, size: count > 150 ? .022 : .032, transparent: true, opacity: .82, depthWrite: false, depthTest: false, blending: THREE.AdditiveBlending, sizeAttenuation: true }));
      const cloud = new THREE.Points(geometryCache.get(key), materialCache.get(cloudMatKey));
      cloud.renderOrder = 18;
      const group = new THREE.Group();
      group.add(cloud);
      root.add(group);
      layers.push({ object: group, speed, baseX: .1, baseY: .2, wobble: .04, phase: count * .017 });
      return group;
    }

    function addEvolutionLayers(root, rank, stage, palette, layers, index) {
      // Each rank permanently adds a visual module. Stages 2 and 3 start at
      // ranks 11 and 21, so the aura never visually regresses on ascension.
      for (let tier = 2; tier <= Math.min(30, rank); tier++) {
        switch (tier) {
          case 2:
            addRingPlane(root, { radius: 1.88, tube: .015, color: palette.rose, edgeColor: palette.light, opacity: .88, rx: .31, ry: 1.28, speed: -.57, wobble: .05, phase: .5, octagon: true, arc: true, arcColor: palette.jade, z: .17 }, layers);
            addRuneOrbit(root, 1.94, 8, palette.cyan, layers, .56, { rx: .54, ry: .78, fontSize: 50, width: .22, height: .22, depth: .13, phase: .4 });
            addOrbitalPearls(root, 12, 1.82, palette, layers, -.48, { size: .049, depth: .22, rx: 1.04, ry: -.16 });
            break;
          case 3:
            addRuneOrbit(root, 2.0, 8, palette.cyan, layers, .56, { rx: .54, ry: .78, fontSize: 50, width: .22, height: .22, depth: .13, phase: .4 });
            addRayFan(root, 48, .84, 2.0, palette.light, .56, layers, -.22, { rx: 1.18, ry: .4 });
            addStarCloud(root, index, 64, 1.0, 2.0, palette.white, layers, .11);
            break;
          case 4:
            addRingPlane(root, { radius: .88, tube: .021, color: palette.violet, edgeColor: palette.cyan, opacity: .9, rx: 1.42, ry: .35, speed: .81, wobble: .07, phase: 1.1, octagon: true, arc: true, arcColor: palette.gold, z: .22 }, layers);
            addCrystalRing(root, 1.56, 8, palette.cyan, layers, -.72, { size: .09, rx: .72, ry: .46 });
            break;
          case 5:
            addCrystalRing(root, 1.56, 8, palette.cyan, layers, -.72, { size: .09, rx: .72, ry: .46 });
            addOrbitalPearls(root, 16, 1.93, palette, layers, .63, { size: .046, depth: .3, rx: .54, ry: .94 });
            addStarCloud(root, index, 90, .9, 2.12, palette.rose, layers, -.08);
            break;
          case 6:
            addRayFan(root, 48, .84, 2.04, palette.gold, .54, layers, .22, { rx: 1.22, ry: -.22 });
            break;
          case 7:
            addOrbitalPearls(root, 12, 2.02, palette, layers, -.66, { size: .052, depth: .32, rx: .67, ry: .82 });
            break;
          case 8:
            addStarCloud(root, index, 100, 1.02, 2.28, palette.white, layers, .09);
            addRingPlane(root, { radius: 2.12, tube: .009, color: palette.jade, edgeColor: palette.cyan, opacity: .72, rx: .24, ry: .98, speed: .18, wobble: .035, phase: 2.1, octagon: false, arc: true, arcColor: palette.rose, z: -.18 }, layers);
            break;
          case 9:
            addRuneOrbit(root, 2.18, 16, palette.rose, layers, .38, { rx: 1.1, ry: -.48, fontSize: 36, width: .14, height: .14, depth: .16, glyphs: ARCANE_GLYPHS, phase: 1.7 });
            break;
          case 10:
            addRingPlane(root, { radius: 2.28, tube: .018, color: palette.gold, edgeColor: palette.light, opacity: .9, rx: 1.3, ry: .72, speed: -.28, wobble: .04, phase: 2.8, octagon: true, arc: true, arcColor: palette.cyan, z: .2 }, layers);
            addRingPlane(root, { radius: .66, tube: .014, color: palette.rose, edgeColor: palette.violet, opacity: .9, rx: .18, ry: 1.4, speed: .9, wobble: .065, phase: .9, octagon: false, arc: true, arcColor: palette.gold, z: .27 }, layers);
            addRayFan(root, 80, .72, 2.34, palette.light, .65, layers, -.13, { rx: .8, ry: .37 });
            break;
          case 11: // Càn Khôn Bát Quái: a more elaborate dual-cosmos foundation.
            addRingPlane(root, { radius: 2.4, tube: .023, color: palette.gold, edgeColor: palette.light, opacity: .98, rx: 1.35, ry: -.38, speed: .31, wobble: .06, phase: .8, octagon: true, arc: true, arcColor: palette.rose, z: .24 }, layers);
            addRingPlane(root, { radius: 2.52, tube: .013, color: palette.jade, edgeColor: palette.cyan, opacity: .88, rx: .34, ry: 1.22, speed: -.42, wobble: .055, phase: 1.8, octagon: true, arc: true, arcColor: palette.violet, z: -.2 }, layers);
            addOrbitalPearls(root, 16, 2.36, palette, layers, .55, { size: .048, depth: .38, rx: .8, ry: -.42 });
            break;
          case 12:
            addRuneOrbit(root, 2.46, 16, palette.light, layers, -.48, { rx: .74, ry: 1.04, fontSize: 41, width: .17, height: .17, depth: .2, phase: .8 });
            break;
          case 13:
            addCrystalRing(root, 2.0, 16, palette.rose, layers, .62, { size: .075, rx: 1.28, ry: -.3 });
            break;
          case 14:
            addRayFan(root, 112, .68, 2.55, palette.cyan, .68, layers, -.25, { rx: .35, ry: 1.12 });
            break;
          case 15:
            addRuneOrbit(root, 2.7, 24, palette.jade, layers, .33, { rx: 1.28, ry: .22, fontSize: 30, width: .125, height: .125, depth: .2, glyphs: ARCANE_GLYPHS, phase: .7 });
            break;
          case 16:
            addOrbitalPearls(root, 24, 2.55, palette, layers, -.7, { size: .05, depth: .42, rx: .88, ry: .58 });
            addStarCloud(root, index, 160, 1.25, 2.8, palette.white, layers, .07);
            break;
          case 17:
            addRingPlane(root, { radius: 2.76, tube: .016, color: palette.violet, edgeColor: palette.rose, opacity: .9, rx: 1.48, ry: .17, speed: .42, wobble: .045, phase: 1.8, octagon: true, arc: true, arcColor: palette.jade, z: .17 }, layers);
            addCrystalRing(root, 1.14, 12, palette.gold, layers, -.54, { size: .1, rx: .5, ry: .9 });
            break;
          case 18:
            addRuneOrbit(root, 2.82, 32, palette.cyan, layers, .27, { rx: .9, ry: -.64, fontSize: 27, width: .11, height: .11, depth: .22, glyphs: ARCANE_GLYPHS, phase: 2.1 });
            break;
          case 19:
            addOrbitalPearls(root, 32, 2.72, palette, layers, -.46, { size: .045, depth: .44, rx: 1.1, ry: -.3 });
            addRayFan(root, 144, 1.02, 2.82, palette.gold, .72, layers, .16, { rx: 1.3, ry: .5 });
            break;
          case 20: // Càn Khôn grand array.
            for (let k = 0; k < 4; k++) addRingPlane(root, { radius: 2.38 + k * .15, tube: .012 + (k % 2) * .004, color: [palette.gold, palette.cyan, palette.violet, palette.rose][k], edgeColor: palette.light, opacity: .92, rx: .2 + k * .3, ry: 1.2 - k * .22, speed: (k % 2 ? -1 : 1) * (.18 + k * .06), wobble: .04, phase: k * .7, octagon: true, arc: true, arcColor: palette.jade, z: (k - 1.5) * .07 }, layers);
            addRayFan(root, 180, .6, 2.95, palette.light, .72, layers, -.14, { rx: .82, ry: .12 });
            break;
          case 21: // Vô Cực Càn Khôn begins a new, visually denser stage.
            addRingPlane(root, { radius: 3.03, tube: .025, color: palette.rose, edgeColor: palette.white, opacity: .98, rx: 1.34, ry: .44, speed: -.36, wobble: .07, phase: 1.3, octagon: true, arc: true, arcColor: palette.cyan, z: .25 }, layers);
            addRingPlane(root, { radius: 3.17, tube: .013, color: palette.violet, edgeColor: palette.light, opacity: .94, rx: .38, ry: 1.36, speed: .47, wobble: .06, phase: 2.2, octagon: true, arc: true, arcColor: palette.gold, z: -.23 }, layers);
            addOrbitalPearls(root, 36, 3.0, palette, layers, .58, { size: .043, depth: .5, rx: .64, ry: .9 });
            break;
          case 22:
            addRuneOrbit(root, 3.18, 40, palette.white, layers, -.39, { rx: .68, ry: .98, fontSize: 24, width: .1, height: .1, depth: .25, glyphs: ARCANE_GLYPHS, phase: 1.7 });
            break;
          case 23:
            addCrystalRing(root, 2.7, 32, palette.cyan, layers, .64, { size: .06, rx: 1.08, ry: -.44 });
            break;
          case 24:
            addRayFan(root, 224, .54, 3.3, palette.rose, .76, layers, -.22, { rx: .29, ry: 1.27 });
            break;
          case 25:
            addOrbitalPearls(root, 48, 3.16, palette, layers, .72, { size: .041, depth: .56, rx: .9, ry: -.25 });
            addStarCloud(root, index, 240, 1.12, 3.3, palette.white, layers, .08);
            break;
          case 26:
            addRingPlane(root, { radius: 3.35, tube: .018, color: palette.gold, edgeColor: palette.cyan, opacity: .93, rx: 1.47, ry: -.24, speed: .5, wobble: .05, phase: 1.9, octagon: true, arc: true, arcColor: palette.rose, z: .21 }, layers);
            addRingPlane(root, { radius: 1.02, tube: .02, color: palette.jade, edgeColor: palette.light, opacity: .9, rx: .2, ry: 1.4, speed: -.8, wobble: .07, phase: .4, octagon: true, arc: true, arcColor: palette.violet, z: .3 }, layers);
            break;
          case 27:
            addRuneOrbit(root, 3.42, 48, palette.jade, layers, .35, { rx: .98, ry: -.38, fontSize: 21, width: .09, height: .09, depth: .28, glyphs: ARCANE_GLYPHS, phase: 2.5 });
            break;
          case 28:
            addCrystalRing(root, 3.14, 40, palette.rose, layers, -.7, { size: .057, rx: 1.22, ry: .32 });
            addRayFan(root, 256, .48, 3.48, palette.light, .78, layers, .17, { rx: 1.03, ry: -.18 });
            break;
          case 29:
            addOrbitalPearls(root, 56, 3.4, palette, layers, -.6, { size: .04, depth: .58, rx: .6, ry: 1.08 });
            addStarCloud(root, index, 320, 1.3, 3.55, palette.white, layers, -.06);
            break;
          case 30: // Apotheosis array: maximal layered rings, glyphs, rays and particles.
            for (let k = 0; k < 8; k++) addRingPlane(root, { radius: 2.4 + k * .145, tube: k % 2 ? .014 : .02, color: [palette.gold, palette.cyan, palette.violet, palette.rose, palette.jade][k % 5], edgeColor: palette.white, opacity: .96, rx: .18 + k * .17, ry: 1.32 - k * .14, speed: (k % 2 ? -1 : 1) * (.2 + k * .035), wobble: .05, phase: k * .57, octagon: true, arc: true, arcColor: [palette.cyan, palette.gold, palette.rose][k % 3], z: (k - 3.5) * .055 }, layers);
            addRuneOrbit(root, 3.65, 64, palette.white, layers, .32, { rx: .8, ry: -.5, fontSize: 18, width: .08, height: .08, depth: .3, glyphs: ARCANE_GLYPHS, phase: 3.1 });
            addRayFan(root, 360, .44, 3.7, palette.gold, .82, layers, -.12, { rx: 1.08, ry: .24 });
            addOrbitalPearls(root, 72, 3.55, palette, layers, .68, { size: .038, depth: .62, rx: .75, ry: -.5 });
            addStarCloud(root, index, 420, 1.3, 3.8, palette.white, layers, .045);
            break;
        }
      }
    }

    function addRingPlane(root, opts, layers) {
      const plane = new THREE.Group();
      plane.rotation.set(opts.rx, opts.ry, opts.rz || 0);
      plane.position.z = opts.z || 0;
      root.add(plane);
      const mesh = new THREE.Mesh(torus(opts.radius, opts.tube), material(opts.color, opts.opacity, true));
      mesh.renderOrder = 8;
      plane.add(mesh);
      if (opts.octagon) {
        const oct = new THREE.LineLoop(octagon(opts.radius * 1.025), lineMaterial(opts.edgeColor || opts.color, Math.min(1, opts.opacity + .12)));
        oct.renderOrder = 9;
        plane.add(oct);
      }
      if (opts.arc) {
        const arcMesh = new THREE.Mesh(torus(opts.radius * 1.12, opts.tube * .7, Math.PI * 1.25), material(opts.arcColor || opts.color, .94, true));
        arcMesh.rotation.z = .68;
        arcMesh.renderOrder = 10;
        plane.add(arcMesh);
      }
      layers.push({ object: plane, speed: opts.speed, baseX: opts.rx, baseY: opts.ry, wobble: opts.wobble || .035, phase: opts.phase || 0 });
      return plane;
    }

    function setRenderOrder(object, order) {
      object.traverse((child) => {
        if (child.material) child.renderOrder = order;
      });
    }

    function addBlackHoleDisk(root, innerRadius, outerRadius, color, opacity, layers, opts = {}) {
      const key = `black-hole-annulus:${innerRadius}:${outerRadius}`;
      if (!geometryCache.has(key)) {
        geometryCache.set(key, new THREE.RingGeometry(innerRadius, outerRadius, 80));
      }
      const plane = new THREE.Group();
      const rx = opts.rx == null ? 1.08 : opts.rx;
      const ry = opts.ry == null ? .12 : opts.ry;
      plane.rotation.set(rx, ry, opts.rz || 0);
      plane.position.z = opts.z || 0;
      const band = new THREE.Mesh(geometryCache.get(key), material(color, opacity, true));
      band.renderOrder = opts.order == null ? 7 : opts.order;
      plane.add(band);
      root.add(plane);
      layers.push({ object: plane, speed: opts.speed == null ? .25 : opts.speed, baseX: rx, baseY: ry, wobble: opts.wobble == null ? .025 : opts.wobble, phase: opts.phase || 0 });
      return plane;
    }

    function addBlackHoleLayers(root, index, stage, level, palette, layers) {
      // A dedicated stage replaces the old Vô Cực Càn Khôn geometry entirely.
      // The annuli share cached RingGeometry/material resources, orbital pearls are
      // instanced, and the single star cloud is shared across all Black Hole tiles.
      const rank = Math.max(1, Math.min(30, (Math.max(4, stage) - 4) * 10 + level));

      // Broad, inclined accretion disk: warm inner plasma, amber middle band and
      // cool cyan/violet outer matter. These are translucent annuli, not blur-heavy CSS.
      addBlackHoleDisk(root, .68, 1.08, 0xff542e, .32, layers, { rx: 1.17, ry: .14, speed: .31, z: -.16, phase: .2 });
      addBlackHoleDisk(root, .92, 1.52, 0xff9e36, .23, layers, { rx: 1.04, ry: -.23, speed: -.27, z: -.1, phase: .7 });
      addBlackHoleDisk(root, 1.32, 2.02, 0x4edfff, .13, layers, { rx: .92, ry: .38, speed: .19, z: -.2, phase: 1.1 });
      addBlackHoleDisk(root, 1.72, 2.32, 0x8d63ff, .095, layers, { rx: 1.25, ry: -.31, speed: -.14, z: -.25, phase: 1.7 });

      // Thin, intersecting 3D photon/lensing rings around the event horizon.
      const innerPhoton = addRingPlane(root, { radius: .69, tube: .038, color: palette.light, edgeColor: palette.white, opacity: .99, rx: 1.12, ry: .12, speed: .48, wobble: .025, phase: .35, octagon: false, arc: true, arcColor: palette.gold, z: .12 }, layers);
      setRenderOrder(innerPhoton, 22);
      const cyanPhoton = addRingPlane(root, { radius: .78, tube: .018, color: palette.cyan, edgeColor: palette.white, opacity: .92, rx: .66, ry: -.46, speed: -.63, wobble: .035, phase: .9, octagon: false, arc: true, arcColor: palette.violet, z: .18 }, layers);
      setRenderOrder(cyanPhoton, 23);
      const amberLens = addRingPlane(root, { radius: .96, tube: .022, color: palette.gold, edgeColor: palette.light, opacity: .92, rx: 1.35, ry: .27, speed: .24, wobble: .025, phase: 1.2, octagon: false, arc: true, arcColor: palette.rose, z: .2 }, layers);
      setRenderOrder(amberLens, 21);

      // Pair of low-poly plasma jets; one mesh geometry/material is reused for both.
      const jetGeometryKey = 'black-hole-jet-cone';
      if (!geometryCache.has(jetGeometryKey)) geometryCache.set(jetGeometryKey, new THREE.ConeGeometry(.13, 1.22, 12, 1, true));
      const jetGroup = new THREE.Group();
      jetGroup.rotation.set(.12, .18, .02);
      root.add(jetGroup);
      const jetTop = new THREE.Mesh(geometryCache.get(jetGeometryKey), material(palette.cyan, .23, true));
      jetTop.position.set(.04, 1.18, -.05);
      jetTop.renderOrder = 13;
      jetGroup.add(jetTop);
      const jetBottom = new THREE.Mesh(geometryCache.get(jetGeometryKey), material(palette.rose, .18, true));
      jetBottom.position.set(-.03, -1.18, -.05);
      jetBottom.rotation.z = Math.PI;
      jetBottom.renderOrder = 13;
      jetGroup.add(jetBottom);
      layers.push({ object: jetGroup, speed: .065 + rank * .004, baseX: .12, baseY: .18, wobble: .035 + rank * .001, phase: .4 });

      // Event horizon is the visual anchor. Draw it after the back half of the disk,
      // then put the photon rings and hot spots above it for a true layered 3D silhouette.
      const horizonGeometryKey = 'black-hole-event-horizon-sphere';
      if (!geometryCache.has(horizonGeometryKey)) geometryCache.set(horizonGeometryKey, new THREE.SphereGeometry(.59, 28, 20));
      const horizon = new THREE.Mesh(geometryCache.get(horizonGeometryKey), material(0x010209, 1, false));
      horizon.renderOrder = 18;
      root.add(horizon);
      const shadowGeometryKey = 'black-hole-shadow-disc';
      if (!geometryCache.has(shadowGeometryKey)) geometryCache.set(shadowGeometryKey, new THREE.CircleGeometry(.7, 48));
      const shadow = new THREE.Mesh(geometryCache.get(shadowGeometryKey), material(0x02030a, .98, false));
      shadow.position.z = .19;
      shadow.renderOrder = 19;
      root.add(shadow);

      // Lensing arcs are brought forward over the horizon edge, not behind the core.
      const outerPhoton = addRingPlane(root, { radius: .83, tube: .012, color: palette.white, edgeColor: palette.cyan, opacity: .96, rx: .42, ry: .86, speed: -.34, wobble: .04, phase: 1.55, octagon: false, arc: true, arcColor: palette.violet, z: .25 }, layers);
      setRenderOrder(outerPhoton, 24);

      // A compact instanced pearl orbit and a shared point cloud keep the effect rich
      // without multiplying draw calls or allocating fresh particles every frame.
      addOrbitalPearls(root, 18, 2.15 + rank * .025, palette, layers, -.25 - rank * .006, { size: .034, depth: .38, rx: .82, ry: .2 });
      addStarCloud(root, index, 112, 1.65, 3.7, palette.white, layers, .045 + rank * .002);

      // Each Black Hole level adds a controlled, cumulative detail band. No phase III
      // trigrams, seals, rays or rank-30 Vô Cực array are carried into this new form.
      if (rank >= 2) {
        const ring = addRingPlane(root, { radius: 2.34, tube: .013, color: palette.cyan, edgeColor: palette.light, opacity: .84, rx: .82, ry: .41, speed: .21, wobble: .035, phase: .65, octagon: false, arc: true, arcColor: palette.rose, z: -.18 }, layers);
        setRenderOrder(ring, 9);
      }
      if (rank >= 4) {
        const ring = addRingPlane(root, { radius: 2.58, tube: .018, color: palette.rose, edgeColor: palette.gold, opacity: .86, rx: 1.31, ry: -.26, speed: -.28, wobble: .04, phase: 1.2, octagon: false, arc: true, arcColor: palette.cyan, z: -.24 }, layers);
        setRenderOrder(ring, 9);
        addBlackHoleDisk(root, 2.08, 2.18, 0xffae56, .13, layers, { rx: 1.14, ry: .16, speed: .12, z: -.3, phase: 1.4 });
      }
      if (rank >= 6) {
        addRayFan(root, 96, .98, 2.9, palette.cyan, .28, layers, .12, { rx: 1.13, ry: -.27 });
      }
      if (rank >= 8) {
        const lens = addRingPlane(root, { radius: 2.92, tube: .012, color: palette.violet, edgeColor: palette.white, opacity: .8, rx: .3, ry: 1.02, speed: .16, wobble: .03, phase: 2.1, octagon: false, arc: true, arcColor: palette.gold, z: -.35 }, layers);
        setRenderOrder(lens, 9);
      }
      if (rank >= 10) {
        addBlackHoleDisk(root, 2.78, 2.86, 0x5beeff, .10, layers, { rx: .72, ry: -.42, speed: -.13, z: -.4, phase: 2.8 });
        const halo = addRingPlane(root, { radius: 3.18, tube: .017, color: palette.light, edgeColor: palette.cyan, opacity: .87, rx: .96, ry: .16, speed: -.22, wobble: .035, phase: 2.9, octagon: false, arc: true, arcColor: palette.rose, z: -.42 }, layers);
        setRenderOrder(halo, 9);
      }
      if (rank >= 12) {
        const lens = addRingPlane(root, { radius: 3.34, tube: .013, color: palette.rose, edgeColor: palette.light, opacity: .82, rx: 1.22, ry: -.28, speed: .18, wobble: .028, phase: 2.4, octagon: false, arc: true, arcColor: palette.cyan, z: -.46 }, layers);
        setRenderOrder(lens, 9);
      }
      if (rank >= 14) addStarCloud(root, index, 160, 1.45, 3.62, palette.white, layers, -.055);
      if (rank >= 16) addRayFan(root, 128, .88, 3.2, palette.gold, .25, layers, -.10, { rx: .88, ry: .29 });
      if (rank >= 18) {
        const halo = addRingPlane(root, { radius: 3.48, tube: .015, color: palette.violet, edgeColor: palette.cyan, opacity: .8, rx: .48, ry: .91, speed: -.17, wobble: .032, phase: 2.7, octagon: false, arc: true, arcColor: palette.gold, z: -.5 }, layers);
        setRenderOrder(halo, 9);
      }
      if (rank >= 20) addOrbitalPearls(root, 24, 2.82, palette, layers, .19, { size: .031, depth: .62, rx: 1.02, ry: -.24 });
      if (rank >= 24) addBlackHoleDisk(root, 3.05, 3.12, 0x9b6bff, .08, layers, { rx: 1.08, ry: .21, speed: .10, z: -.54, phase: 3.1 });
      if (rank >= 28) {
        const halo = addRingPlane(root, { radius: 3.76, tube: .012, color: palette.cyan, edgeColor: palette.light, opacity: .76, rx: .62, ry: -.84, speed: -.13, wobble: .025, phase: 3.2, octagon: false, arc: true, arcColor: palette.rose, z: -.58 }, layers);
        setRenderOrder(halo, 9);
      }

      const cycleLabel = stage === 4 ? `HỐ ĐEN · CẤP ${level}/10` : `HỐ ĐEN VÔ TẬN · CHU KỲ ${stage - 3} · CẤP ${level}/10`;
      const label = spriteFor(cycleLabel, `#${palette.gold.toString(16).padStart(6, '0')}`, 42, 2.35, .24, '"Microsoft YaHei", "Noto Serif CJK SC", serif');
      label.position.set(0, 2.66 + rank * .018, .32);
      label.material.opacity = .94;
      label.renderOrder = 26;
      root.add(label);

      root.userData.blackHole = true;
      root.userData.internalScale = 1 + (rank - 1) * .025;
      root.userData.taiji = null;
    }

    function createAura(index, rank = 1, stage = 1, level = 1) {
      const palette = paletteForStage(stage);
      const root = new THREE.Group();
      root.name = stage >= 4 ? `nebula-black-hole-${index}` : `bagua-aura-${index}`;
      scene.add(root);
      const layers = [];

      if (stage >= 4) {
        addBlackHoleLayers(root, index, stage, level, palette, layers);
        root.userData.internalScale = Math.min(1.45, 1 + (Math.min(30, (stage - 4) * 10 + level) - 1) * .015);
        root.userData.layers = layers;
        root.userData.rank = rank;
        root.userData.stage = stage;
        root.userData.level = level;
        root.userData.starPoints = null;
        root.userData.outer = null;
        root.userData.age = 0;
        root.renderOrder = 12;
        return root;
      }

      // Four differently tilted ring planes give the aura actual 3D depth.
      const outer = addRingPlane(root, { radius: 1.62, tube: .024, color: palette.gold, edgeColor: palette.light, opacity: .96, rx: 1.10, ry: .12, speed: .34, wobble: .05, phase: .2, octagon: true, arc: true, arcColor: palette.cyan, z: .10 }, layers);
      addRingPlane(root, { radius: 1.38, tube: .017, color: palette.cyan, edgeColor: palette.white, opacity: .9, rx: .78, ry: -.48, speed: -.48, wobble: .065, phase: 1.4, octagon: true, arc: true, arcColor: palette.violet, z: .06 }, layers);
      addRingPlane(root, { radius: 1.48, tube: .016, color: palette.violet, edgeColor: palette.light, opacity: .85, rx: .16, ry: 1.18, speed: .29, wobble: .055, phase: 2.1, octagon: false, arc: true, arcColor: palette.cyan, z: -.08 }, layers);
      addRingPlane(root, { radius: 1.18, tube: .019, color: palette.gold, edgeColor: palette.cyan, opacity: .88, rx: 1.25, ry: .52, speed: -.62, wobble: .045, phase: .7, octagon: true, arc: false, z: .14 }, layers);
      addRingPlane(root, { radius: 1.78, tube: .012, color: palette.cyan, edgeColor: palette.gold, opacity: .72, rx: .96, ry: -.18, speed: .16, wobble: .04, phase: 2.8, octagon: true, arc: true, arcColor: palette.gold, z: -.13 }, layers);

      // Inner seal plane, just outside the tile border, so the number remains legible.
      const sealPlane = new THREE.Group();
      sealPlane.position.set(0, .02, .28);
      sealPlane.rotation.set(1.08, .10, 0);
      root.add(sealPlane);
      sealPlane.add(new THREE.Mesh(torus(.79, .018), material(0xffe4a0, .88, true)));
      sealPlane.add(new THREE.LineLoop(octagon(.84), lineMaterial(0x67efff, .9)));
      layers.push({ object: sealPlane, speed: -.73, baseX: 1.08, baseY: .10, wobble: .025, phase: 2.3 });

      // Eight trigrams travel together on a tilted orbital plane while their glyphs face the viewer.
      const glyphOrbit = new THREE.Group();
      glyphOrbit.rotation.set(1.04, .12, 0);
      root.add(glyphOrbit);
      const glyphs = ['☰', '☱', '☲', '☳', '☴', '☵', '☶', '☷'];
      const glyphColors = ['#fff0b5', '#6ef3ff', '#f7c96d', '#c7a0ff', '#fff0b5', '#6ef3ff', '#f7c96d', '#c7a0ff'];
      glyphs.forEach((glyph, i) => {
        const a = Math.PI * 2 * i / 8 + Math.PI / 8;
        const sprite = spriteFor(glyph, glyphColors[i], 152, .58, .58, '"Segoe UI Symbol", "Noto Sans Symbols 2", serif');
        sprite.position.set(Math.cos(a) * 1.43, Math.sin(a) * 1.43, .12 + (i % 2) * .08);
        sprite.renderOrder = 15;
        glyphOrbit.add(sprite);
      });
      layers.push({ object: glyphOrbit, speed: -.24, baseX: 1.04, baseY: .12, wobble: .06, phase: .4 });

      // The Taiji seal floats above the tile and rotates independently, like the central seal of the background scene.
      const taijiRing = new THREE.Group();
      taijiRing.position.set(0, 0, .30);
      taijiRing.rotation.set(.24, .12, 0);
      root.add(taijiRing);
      taijiRing.add(new THREE.Mesh(torus(.31, .018), material(palette.gold, .28, true)));
      taijiRing.add(new THREE.Mesh(torus(.23, .01), material(palette.cyan, .24, true)));
      layers.push({ object: taijiRing, speed: .72, baseX: .24, baseY: .12, wobble: .035, phase: 1.2 });
      const taiji = spriteFor('taiji-svg', `#${palette.light.toString(16).padStart(6, '0')}`, 145, .72, .72, '"Segoe UI Symbol", "Noto Sans Symbols 2", serif');
      taiji.position.set(0, 0, .39);
      taiji.material.opacity = .22;
      taiji.renderOrder = 20;
      root.add(taiji);

      const seal = spriteFor(stage === 1 ? `八卦 · ${level}/10` : stage === 2 ? `乾坤八卦 · ${level}/10` : `無極乾坤 · ${level}/10`, `#${palette.gold.toString(16).padStart(6, '0')}`, 42, 2.0, .26, '"Microsoft YaHei", "Noto Serif CJK SC", serif');
      seal.position.set(0, 1.76, .18);
      seal.material.opacity = .92;
      seal.renderOrder = 20;
      root.add(seal);

      // Eight metallic orbs and a halo of flying particles complete the over-the-top effect.
      const orbiters = new THREE.Group();
      orbiters.rotation.set(.95, -.15, 0);
      root.add(orbiters);
      const orbGeoKey = 'sphere:bagua-orb';
      if (!geometryCache.has(orbGeoKey)) geometryCache.set(orbGeoKey, new THREE.SphereGeometry(.052, 10, 10));
      const orbGeo = geometryCache.get(orbGeoKey);
      for (let i = 0; i < 8; i++) {
        const a = Math.PI * 2 * i / 8;
        const orb = new THREE.Mesh(orbGeo, material(i % 2 ? palette.cyan : palette.gold, .98, true));
        orb.position.set(Math.cos(a) * (1.61 + (i % 2) * .14), Math.sin(a) * (1.61 + (i % 2) * .14), .15 + (i % 3) * .06);
        orbiters.add(orb);
      }
      layers.push({ object: orbiters, speed: .38, baseX: .95, baseY: -.15, wobble: .045, phase: 1.7 });

      const spokePoints = [];
      for (let i = 0; i < 32; i++) {
        const a = Math.PI * 2 * i / 32;
        const r1 = 1.04 + (i % 4) * .035;
        const r2 = 1.78 - (i % 3) * .035;
        spokePoints.push(new THREE.Vector3(Math.cos(a) * r1, Math.sin(a) * r1, 0));
        spokePoints.push(new THREE.Vector3(Math.cos(a) * r2, Math.sin(a) * r2, 0));
      }
      const spokesKey = 'bagua-spokes-32';
      if (!geometryCache.has(spokesKey)) geometryCache.set(spokesKey, new THREE.BufferGeometry().setFromPoints(spokePoints));
      const spokes = new THREE.LineSegments(geometryCache.get(spokesKey), lineMaterial(palette.gold, .45));
      const spokePlane = new THREE.Group();
      spokePlane.rotation.set(1.08, .08, 0);
      spokePlane.add(spokes);
      root.add(spokePlane);
      layers.push({ object: spokePlane, speed: -.09, baseX: 1.08, baseY: .08, wobble: .02, phase: .9 });

      const starPositions = [];
      // Deterministic pseudo-random positions; no Math.random() on every frame.
      let seed = (Number(index) + 19) * 7919;
      function rnd() { seed = (seed * 16807) % 2147483647; return (seed - 1) / 2147483646; }
      for (let i = 0; i < 72; i++) {
        const a = rnd() * Math.PI * 2;
        const r = 1.02 + rnd() * .92;
        starPositions.push(Math.cos(a) * r, Math.sin(a) * r, (rnd() - .5) * .55);
      }
      const starGeometryKey = `bagua-stars:${index}`;
      if (!geometryCache.has(starGeometryKey)) {
        const starGeometry = new THREE.BufferGeometry();
        starGeometry.setAttribute('position', new THREE.Float32BufferAttribute(starPositions, 3));
        geometryCache.set(starGeometryKey, starGeometry);
      }
      const starGeometry = geometryCache.get(starGeometryKey);
      const starMaterialKey = 'points:bagua-stars';
      if (!materialCache.has(starMaterialKey)) {
        materialCache.set(starMaterialKey, new THREE.PointsMaterial({ color: palette.white, size: .035, transparent: true, opacity: .9, depthWrite: false, depthTest: false, blending: THREE.AdditiveBlending, sizeAttenuation: true }));
      }
      const starMaterial = materialCache.get(starMaterialKey);
      const starPoints = new THREE.Points(starGeometry, starMaterial);
      starPoints.renderOrder = 18;
      root.add(starPoints);
      layers.push({ object: starPoints, speed: .055, baseX: 0, baseY: 0, wobble: .04, phase: 2.0 });

      addEvolutionLayers(root, rank, stage, palette, layers, index);
      root.userData.layers = layers;
      root.userData.taiji = taiji;
      root.userData.rank = rank;
      root.userData.stage = stage;
      root.userData.level = level;
      root.userData.starPoints = starPoints;
      root.userData.outer = outer;
      root.userData.age = 0;
      root.renderOrder = 12;
      return root;
    }

    function ensureRenderer() {
      if (renderer) return true;
      try {
        canvas = document.createElement('canvas');
        canvas.className = 'bagua-aura-3d-canvas';
        canvas.setAttribute('aria-hidden', 'true');
        wrap.appendChild(canvas);
        renderer = new THREE.WebGLRenderer({ canvas, alpha: true, antialias: false, powerPreference: 'low-power', stencil: false, depth: true, preserveDrawingBuffer: false });
        // Keep this overlay intentionally low-resolution: aura line art stays crisp enough,
        // while the framebuffer takes a fraction of the memory of a HiDPI renderer.
        renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 0.85));
        renderer.setClearColor(0x000000, 0);
        renderer.autoClear = true;
        scene = new THREE.Scene();
        camera = new THREE.OrthographicCamera(-1, 1, 1, -1, .1, 5000);
        camera.position.set(0, 0, 2000);
        camera.lookAt(0, 0, 0);
        return true;
      } catch (error) {
        try { if (renderer) { renderer.dispose(); if (renderer.forceContextLoss) renderer.forceContextLoss(); } } catch (_) {}
        if (canvas && canvas.parentNode) canvas.parentNode.removeChild(canvas);
        canvas = null; renderer = null; scene = null; camera = null;
        return false;
      }
    }

    function getActiveCells() {
      // Flex replaces the board with a full-screen model; don't keep a hidden WebGL
      // scene animating behind that overlay.
      if (document.body.classList.contains('effects-off') || document.body.classList.contains('flex-view-active')) return [];
      return Array.from(board.querySelectorAll('.cell.aura-bagua-on'));
    }

    function syncCanvasSize() {
      if (!layoutDirty && cachedCanvasRect) return { width: pixelWidth, height: pixelHeight, rect: cachedCanvasRect };
      const rect = canvas.getBoundingClientRect();
      const w = Math.max(1, Math.round(rect.width));
      const h = Math.max(1, Math.round(rect.height));
      if (w !== pixelWidth || h !== pixelHeight) {
        pixelWidth = w; pixelHeight = h;
        renderer.setSize(w, h, false);
        camera.left = -w / 2;
        camera.right = w / 2;
        camera.top = h / 2;
        camera.bottom = -h / 2;
        camera.updateProjectionMatrix();
      }
      cachedCanvasRect = rect;
      layoutDirty = false;
      return { width: w, height: h, rect };
    }

    function removeMissingGroups(activeKeys) {
      for (const [key, group] of auraByIndex) {
        if (activeKeys.has(key)) continue;
        scene.remove(group);
        auraByIndex.delete(key);
      }
    }

    function updateAuras(now, delta) {
      const cells = getActiveCells();
      if (!cells.length) return false;
      if (!ensureRenderer()) return false;
      if (canvas.style.display !== 'block') canvas.style.display = 'block';
      const targetOpacity = document.body.classList.contains('effects-low') ? '.66' : '1';
      if (canvas.style.opacity !== targetOpacity) canvas.style.opacity = targetOpacity;
      document.documentElement.classList.add('bagua-webgl-ready');
      const layoutChanged = layoutDirty;
      const canvasInfo = syncCanvasSize();
      const canvasRect = canvasInfo.rect;
      const activeKeys = new Set();
      const t = now * .001;
      const lowEffects = document.body.classList.contains('effects-low');
      const layerScale = lowEffects ? .76 : 1;
      const starsMaterial = materialCache.get('points:bagua-stars');
      if (starsMaterial) {
        const opacity = lowEffects ? .58 : .9;
        if (starsMaterial.opacity !== opacity) starsMaterial.opacity = opacity;
      }

      cells.forEach((cell) => {
        const key = String(cell.dataset.index == null ? cell.getAttribute('data-index') : cell.dataset.index);
        activeKeys.add(key);
        let aura = auraByIndex.get(key);
        // DOM nodes and their layout usually change only after a move/resize. Avoid forcing
        // style/layout recalculation for every aura on every animation frame.
        const refreshCell = !aura || aura.userData.cellElement !== cell || layoutChanged;
        if (refreshCell) {
          const tileStyle = window.getComputedStyle(cell);
          const rank = Math.max(1, parseInt(tileStyle.getPropertyValue('--bagua-rank'), 10) || 1);
          const stage = Math.max(1, parseInt(tileStyle.getPropertyValue('--bagua-stage'), 10) || 1);
          const level = Math.max(1, parseInt(tileStyle.getPropertyValue('--bagua-level'), 10) || 1);
          if (!aura || aura.userData.rank !== rank || aura.userData.stage !== stage || aura.userData.level !== level) {
            if (aura) scene.remove(aura);
            aura = createAura(key, rank, stage, level);
            auraByIndex.set(key, aura);
          }
          const rect = cell.getBoundingClientRect();
          const centerX = rect.left + rect.width / 2 - canvasRect.left;
          const centerY = rect.top + rect.height / 2 - canvasRect.top;
          aura.userData.cachedX = centerX - canvasInfo.width / 2;
          aura.userData.cachedY = canvasInfo.height / 2 - centerY;
          aura.userData.cachedSize = Math.min(rect.width, rect.height);
          aura.userData.cellElement = cell;
        }
        aura.position.set(aura.userData.cachedX, aura.userData.cachedY, 0);
        aura.scale.setScalar(aura.userData.cachedSize * (aura.userData.internalScale || 1));
        aura.userData.age += delta;
        aura.userData.layers.forEach((layer) => {
          if (!reducedMotion) layer.object.rotation.z += delta * layer.speed * layerScale;
          const wobble = reducedMotion ? 0 : Math.sin(t * .42 + layer.phase) * layer.wobble;
          layer.object.rotation.x = layer.baseX + wobble;
          layer.object.rotation.y = layer.baseY + Math.cos(t * .31 + layer.phase) * (reducedMotion ? 0 : layer.wobble * .72);
        });
        if (!reducedMotion && aura.userData.taiji) aura.userData.taiji.rotation.z += delta * .52 * layerScale;
      });
      removeMissingGroups(activeKeys);
      renderer.render(scene, camera);
      return true;
    }

    function clearAndPause() {
      // No WebGL aura should remain allocated while Flex, effects-off, or a board
      // without Bagua tiles is visible. Hiding a canvas alone does NOT release the
      // GPU textures/framebuffer, which can trip browser Out Of Memory at max aura.
      if (frameId) cancelAnimationFrame(frameId);
      frameId = 0;
      if (scene) {
        for (const group of auraByIndex.values()) scene.remove(group);
        auraByIndex.clear();
      }
      document.documentElement.classList.remove('bagua-webgl-ready');

      // Dispose shared resources exactly once, because geometries/materials/textures
      // are cached and reused across aura groups.
      for (const texture of textureCache.values()) { try { texture.dispose(); } catch (_) {} }
      for (const mat of materialCache.values()) { try { mat.dispose(); } catch (_) {} }
      for (const geo of geometryCache.values()) { try { geo.dispose(); } catch (_) {} }
      textureCache.clear();
      materialCache.clear();
      geometryCache.clear();

      if (renderer) {
        try { if (renderer.renderLists && renderer.renderLists.dispose) renderer.renderLists.dispose(); } catch (_) {}
        try { renderer.dispose(); } catch (_) {}
        // Explicitly relinquish WebGL memory rather than retaining a hidden context.
        try { if (renderer.forceContextLoss) renderer.forceContextLoss(); } catch (_) {}
      }
      if (canvas && canvas.parentNode) canvas.parentNode.removeChild(canvas);
      canvas = null;
      renderer = null;
      scene = null;
      camera = null;
      pixelWidth = 0;
      pixelHeight = 0;
      cachedCanvasRect = null;
      layoutDirty = true;
    }

    function animate(now) {
      frameId = 0;
      if (document.hidden) return;
      if (lastRenderTime && now - lastRenderTime < FRAME_INTERVAL_MS) {
        frameId = requestAnimationFrame(animate);
        return;
      }
      lastRenderTime = now;
      const cells = getActiveCells();
      if (!cells.length) { clearAndPause(); return; }
      const delta = lastTime ? Math.min((now - lastTime) / 1000, .05) : 0;
      lastTime = now;
      try {
        if (!updateAuras(now, delta)) {
          clearAndPause();
          return; // The CSS 3D fallback stays visible if WebGL is unavailable.
        }
      } catch (error) {
        // A failed WebGL draw (including GPU allocation failure) must not leave the
        // page holding a half-initialized renderer. Release it and keep CSS aura alive.
        clearAndPause();
        return;
      }
      frameId = requestAnimationFrame(animate);
    }

    function schedule() {
      layoutDirty = true;
      if (document.hidden) return;
      if (!getActiveCells().length) { clearAndPause(); return; }
      if (!frameId) frameId = requestAnimationFrame(animate);
    }

    const boardObserver = new MutationObserver(schedule);
    boardObserver.observe(board, { childList: true, subtree: true, attributes: true, attributeFilter: ['class'] });
    const settingsObserver = new MutationObserver(schedule);
    settingsObserver.observe(document.body, { attributes: true, attributeFilter: ['class'] });
    window.addEventListener('resize', schedule, { passive: true });
    window.addEventListener('scroll', schedule, { passive: true, capture: true });
    document.addEventListener('visibilitychange', () => {
      if (document.hidden) {
        if (frameId) cancelAnimationFrame(frameId);
        frameId = 0;
      } else schedule();
    });
    schedule();
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot, { once: true });
  else boot();
})();
