/* Receives settings from NEBULA 2048. Kept isolated inside background.html iframe. */
(() => {
  'use strict';
  let pendingSettings = null;
  let pendingSuspended = false;

  function applyBackgroundSettings(settings) {
    const app = window.app;
    if (!app || !app.renderer || !app.codeBg) {
      pendingSettings = settings;
      return false;
    }
    const allowedModes = ['cosmic', 'scene', 'matrix', 'stars'];
    const mode = allowedModes.includes(settings.mode) ? settings.mode : 'cosmic';
    const system = settings.system === 'wuxing' ? 'wuxing' : 'bagua';
    const allowedThemes = ['celestial', 'cyan', 'gold', 'emerald', 'crimson', 'silver'];
    const theme = allowedThemes.includes(settings.theme) ? settings.theme : 'celestial';
    const quality = ['low', 'standard', 'max'].includes(settings.quality) ? settings.quality : 'standard';
    const allowedBackdrops = ['nebula','aurora','galaxy','ocean','inferno','sakura','emerald','cyberpunk','golden','arctic'];
    const backdrop = allowedBackdrops.includes(settings.backdrop) ? settings.backdrop : 'nebula';
    document.body.dataset.nebulaBackdrop = backdrop;

    if (app.matrixSystem !== system) {
      app.setMatrixSystem(system);
      app.skipIntro();
    }
    if (app.currentThemeKey !== theme) app.setTheme(theme);

    const sceneEnabled = mode !== 'matrix';
    const ringsEnabled = mode !== 'stars';
    app._nebulaSceneDisabled = !sceneEnabled;
    if (app.container) app.container.style.display = sceneEnabled ? 'block' : 'none';
    if (app.baguaGroup) app.baguaGroup.visible = ringsEnabled;

    const codeEnabled = !!settings.codeEnabled && (mode === 'cosmic' || mode === 'matrix');
    app.codeBg.setEnabled(codeEnabled);
    app.codeBg.setOpacity(Math.max(0, Math.min(0.85, Number(settings.codeOpacity) || 0)));
    const codeCanvas = document.getElementById('bg-code-canvas');
    if (codeCanvas) codeCanvas.style.display = codeEnabled ? 'block' : 'none';

    // Render the decorative scene at a sensible internal resolution. This preserves
    // geometry/materials while cutting fill-rate cost on HiDPI displays.
    const pixelRatio = quality === 'low' ? Math.min(window.devicePixelRatio || 1, 0.9)
      : quality === 'max' ? Math.min(window.devicePixelRatio || 1, 1.6)
      : Math.min(window.devicePixelRatio || 1, 1.18);
    app._minRenderIntervalMs = quality === 'low' ? 1000 / 24 : quality === 'max' ? 1000 / 40 : 1000 / 30;
    // Keep the WebGL scene dark enough for readable geometry but translucent enough for colorful CSS backdrops.
    if (app.renderer.setClearColor) app.renderer.setClearColor(0x020408, 0.38);
    app.renderer.setPixelRatio(pixelRatio);
    app.renderer.setSize(window.innerWidth, window.innerHeight, false);
    if (app.particles) {
      const p = app.particles;
      if (p.__nebulaBaseCount == null) p.__nebulaBaseCount = p.count;
      if (p.__nebulaBaseNebulaCount == null) p.__nebulaBaseNebulaCount = p.nebulaCount;
      const ratio = quality === 'low' ? 0.38 : quality === 'max' ? 1 : 0.7;
      p.count = Math.max(1, Math.floor(p.__nebulaBaseCount * ratio));
      p.nebulaCount = Math.max(1, Math.floor(p.__nebulaBaseNebulaCount * ratio));
      if (p.points && p.points.geometry) p.points.geometry.setDrawRange(0, p.count);
      if (p.nebulaPoints && p.nebulaPoints.geometry) p.nebulaPoints.geometry.setDrawRange(0, p.nebulaCount);
      p.points && (p.points.visible = sceneEnabled);
      p.nebulaPoints && (p.nebulaPoints.visible = sceneEnabled);
      p.singularitySprite && (p.singularitySprite.visible = sceneEnabled);
      p.shockwaveMesh && (p.shockwaveMesh.visible = sceneEnabled);
    }
    app.speedMultiplier = quality === 'low' ? 0.55 : quality === 'max' ? 1.25 : 0.85;

    const imageLayer = document.getElementById('bg-image-layer');
    if (settings.customImage && typeof settings.customImage === 'string' && settings.customImage.startsWith('data:image/')) {
      if (app.bgImageLayer) {
        app.applyCustomBackground(settings.customImage);
        app.bgImageLayer.style.display = 'block';
      }
    } else if (imageLayer) {
      imageLayer.style.backgroundImage = 'none';
      imageLayer.style.display = 'none';
    }
    pendingSettings = null;
    return true;
  }

  window.addEventListener('message', event => {
    if (event.source !== window.parent || !event.data) return;
    if (event.data.type === 'NEBULA_BACKGROUND_SUSPEND') {
      pendingSuspended = !!event.data.suspended;
      if (window.app && typeof window.app.setRenderSuspended === 'function') {
        window.app.setRenderSuspended(pendingSuspended);
      }
      return;
    }
    if (event.data.type !== 'NEBULA_BACKGROUND_SETTINGS') return;
    applyBackgroundSettings(event.data.settings || {});
    if (window.app && typeof window.app.setRenderSuspended === 'function') {
      window.app.setRenderSuspended(pendingSuspended);
    }
  });

  window.addEventListener('DOMContentLoaded', () => {
    if (pendingSettings) applyBackgroundSettings(pendingSettings);
    if (window.app && typeof window.app.setRenderSuspended === 'function') {
      window.app.setRenderSuspended(pendingSuspended);
    }
    if (window.parent !== window) {
      window.parent.postMessage({ type: 'NEBULA_BACKGROUND_READY' }, '*');
    }
  });
})();
