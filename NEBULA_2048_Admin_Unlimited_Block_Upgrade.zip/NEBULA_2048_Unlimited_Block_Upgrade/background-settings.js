/* NEBULA 2048 background controls. Preferences are separate from game save data. */
(() => {
  'use strict';
  const STORAGE_KEY = 'nebula2048.backgroundSettings.v1';
  const DEFAULTS = {
    mode: 'cosmic', system: 'bagua', theme: 'celestial', backdrop: 'nebula', quality: 'standard', auraStyle: 'evolve',
    opacity: 0.82, codeEnabled: true, codeOpacity: 0.24, customImage: ''
  };
  const $ = id => document.getElementById(id);
  let settings = { ...DEFAULTS };
  let frameReady = false;
  let imageJob = 0;

  try {
    const saved = JSON.parse(localStorage.getItem(STORAGE_KEY) || 'null');
    if (saved && typeof saved === 'object') {
      settings = { ...DEFAULTS, ...saved };
      if (!['cosmic','scene','matrix','stars','off'].includes(settings.mode)) settings.mode = DEFAULTS.mode;
      if (!['bagua','wuxing'].includes(settings.system)) settings.system = DEFAULTS.system;
      if (!['celestial','cyan','gold','emerald','crimson','silver'].includes(settings.theme)) settings.theme = DEFAULTS.theme;
      if (!['nebula','aurora','galaxy','ocean','inferno','sakura','emerald','cyberpunk','golden','arctic'].includes(settings.backdrop)) settings.backdrop = DEFAULTS.backdrop;
      if (!['low','standard','max'].includes(settings.quality)) settings.quality = DEFAULTS.quality;
      if (!['evolve','matrix','plasma','inferno','frost','arcane','void','glitch','solaris','celestial'].includes(settings.auraStyle)) settings.auraStyle = DEFAULTS.auraStyle;
      settings.opacity = clamp(settings.opacity, 0.15, 1, DEFAULTS.opacity);
      settings.codeOpacity = clamp(settings.codeOpacity, 0, 0.85, DEFAULTS.codeOpacity);
      settings.codeEnabled = settings.codeEnabled !== false;
      if (typeof settings.customImage !== 'string' || !settings.customImage.startsWith('data:image/')) settings.customImage = '';
    }
  } catch (_) { settings = { ...DEFAULTS }; }

  function clamp(value, min, max, fallback) {
    const n = Number(value);
    return Number.isFinite(n) ? Math.max(min, Math.min(max, n)) : fallback;
  }

  function save() {
    try { localStorage.setItem(STORAGE_KEY, JSON.stringify(settings)); }
    catch (_) { setStatus('KHÔNG LƯU ĐƯỢC', true); }
  }

  function isActive() { return settings.mode !== 'off'; }

  // Flex has a much larger aura than the normal board. Pause AND unload the
  // background iframe while Flex is visible so Chromium releases its WebGL context,
  // framebuffers and particle buffers instead of retaining hidden GPU allocations.
  // Settings are stored outside the iframe and are sent again when the backdrop returns.
  function syncFlexRenderPause() {
    const suspended = document.body.classList.contains('flex-view-active');
    const host = $('nebulaBackgroundHost');
    const frame = $('nebulaBackgroundFrame');
    if (host) host.style.display = isActive() && !suspended ? 'block' : 'none';
    if (!frame) return;

    const src = frame.getAttribute('src') || '';
    if (suspended) {
      if (src && src !== 'about:blank' && frame.dataset.nebulaReady === '1') {
        frameReady = false;
        frame.dataset.nebulaFlexReleased = '1';
        frame.dataset.nebulaReady = '0';
        frame.setAttribute('src', 'about:blank');
      } else if (frame.contentWindow && src && src !== 'about:blank') {
        // If still loading, ask it to suspend. The load handler will unload it once ready.
        frame.contentWindow.postMessage({ type: 'NEBULA_BACKGROUND_SUSPEND', suspended: true }, '*');
      }
      return;
    }

    if (frame.dataset.nebulaFlexReleased === '1') {
      frame.dataset.nebulaFlexReleased = '0';
      if (isActive()) {
        frameReady = false;
        frame.setAttribute('src', new URL('background.html', window.location.href).href);
      }
      return;
    }
    if (frame.contentWindow && src && src !== 'about:blank') {
      frame.contentWindow.postMessage({ type: 'NEBULA_BACKGROUND_SUSPEND', suspended: false }, '*');
    }
  }

  function sendSettings() {
    const host = $('nebulaBackgroundHost');
    const frame = $('nebulaBackgroundFrame');
    document.body.classList.toggle('nebula-bg-glass', isActive());
    if (host) host.style.opacity = String(settings.opacity);
    setStatus(isActive() ? 'NỀN ĐANG BẬT' : 'NỀN ĐÃ TẮT');
    syncFlexRenderPause();
    // Do not recreate a released background iframe while Flex is still active.
    if (document.body.classList.contains('flex-view-active')) return;
    if (!frame) return;
    const targetSrc = new URL('background.html', window.location.href).href;
    if (!isActive()) {
      frameReady = false;
      if (frame.getAttribute('src') !== 'about:blank') frame.setAttribute('src', 'about:blank');
      return;
    }
    if (frame.getAttribute('src') === 'about:blank' || !frame.getAttribute('src')) {
      frameReady = false;
      frame.setAttribute('src', targetSrc);
      return;
    }
    if (frameReady && frame.contentWindow) {
      frame.contentWindow.postMessage({ type: 'NEBULA_BACKGROUND_SETTINGS', settings }, '*');
      syncFlexRenderPause();
    }
  }

  function setStatus(text, warning = false) {
    const el = $('bgSettingsStatus');
    if (!el) return;
    el.textContent = text;
    el.style.color = warning ? '#ff9da9' : (isActive() ? '#8ee8f5' : '#9aa7bf');
    el.style.borderColor = warning ? 'rgba(251,113,133,.35)' : 'rgba(94,231,247,.22)';
  }

  function commit(changes = {}) {
    settings = { ...settings, ...changes };
    save();
    syncControls();
    sendSettings();
  }

  function syncControls() {
    const selectValues = {
      bgModeSetting: settings.mode, bgSystemSetting: settings.system,
      bgThemeSetting: settings.theme, bgQualitySetting: settings.quality, bgAuraStyleSetting: settings.auraStyle
    };
    for (const [id, value] of Object.entries(selectValues)) if ($(id)) $(id).value = value;
    document.body.dataset.auraTheme = settings.auraStyle || 'evolve';
    document.querySelectorAll('[data-backdrop]').forEach(button => {
      const selected = button.dataset.backdrop === settings.backdrop;
      button.classList.toggle('is-active', selected);
      button.setAttribute('aria-pressed', selected ? 'true' : 'false');
    });
    if ($('bgOpacitySetting')) $('bgOpacitySetting').value = String(settings.opacity);
    if ($('bgOpacityValue')) $('bgOpacityValue').textContent = `${Math.round(settings.opacity * 100)}%`;
    if ($('bgCodeEnabledSetting')) $('bgCodeEnabledSetting').checked = !!settings.codeEnabled;
    if ($('bgCodeOpacitySetting')) $('bgCodeOpacitySetting').value = String(settings.codeOpacity);
    if ($('bgCodeOpacityValue')) $('bgCodeOpacityValue').textContent = `${Math.round(settings.codeOpacity * 100)}%`;
    const clear = $('bgClearImageBtn');
    if (clear) clear.disabled = !settings.customImage;
  }

  function compressImage(file) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onerror = () => reject(new Error('Không đọc được ảnh.'));
      reader.onload = () => {
        const img = new Image();
        img.onerror = () => reject(new Error('File ảnh không hợp lệ.'));
        img.onload = () => {
          const maxDimension = 1920;
          const scale = Math.min(1, maxDimension / Math.max(img.naturalWidth, img.naturalHeight));
          const canvas = document.createElement('canvas');
          canvas.width = Math.max(1, Math.round(img.naturalWidth * scale));
          canvas.height = Math.max(1, Math.round(img.naturalHeight * scale));
          const ctx = canvas.getContext('2d');
          if (!ctx) return reject(new Error('Không khởi tạo được bộ xử lý ảnh.'));
          ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
          try { resolve(canvas.toDataURL('image/jpeg', 0.82)); }
          catch (error) { reject(error); }
        };
        img.src = String(reader.result || '');
      };
      reader.readAsDataURL(file);
    });
  }

  document.addEventListener('DOMContentLoaded', () => {
    const frame = $('nebulaBackgroundFrame');
    if (frame) {
      frame.addEventListener('load', () => {
        const src = frame.getAttribute('src') || '';
        if (!src || src === 'about:blank') {
          frameReady = false;
          frame.dataset.nebulaReady = '0';
          // If Flex opened while the iframe was still loading, release it now that
          // the old document has completed navigation and its context can be discarded.
          if (document.body.classList.contains('flex-view-active') && frame.dataset.nebulaFlexReleased !== '1' && isActive()) {
            frame.dataset.nebulaFlexReleased = '1';
          }
          return;
        }
        frame.dataset.nebulaReady = '1';
        frameReady = true;
        sendSettings();
      });
    }
    $('backgroundSettingsJumpBtn')?.addEventListener('click', () => {
      $('statsPanel')?.scrollIntoView({ behavior: 'smooth', block: 'start' });
    });
    $('bgModeSetting')?.addEventListener('change', e => commit({ mode: e.target.value }));
    $('bgSystemSetting')?.addEventListener('change', e => commit({ system: e.target.value }));
    $('bgThemeSetting')?.addEventListener('change', e => commit({ theme: e.target.value }));
    $('bgAuraStyleSetting')?.addEventListener('change', e => commit({ auraStyle: e.target.value }));
    $('bgBackdropPicker')?.addEventListener('click', e => {
      const button = e.target.closest('[data-backdrop]');
      if (!button) return;
      commit({ backdrop: button.dataset.backdrop });
    });
    $('bgQualitySetting')?.addEventListener('change', e => commit({ quality: e.target.value }));
    $('bgOpacitySetting')?.addEventListener('input', e => commit({ opacity: clamp(e.target.value, .15, 1, DEFAULTS.opacity) }));
    $('bgCodeEnabledSetting')?.addEventListener('change', e => commit({ codeEnabled: e.target.checked }));
    $('bgCodeOpacitySetting')?.addEventListener('input', e => commit({ codeOpacity: clamp(e.target.value, 0, .85, DEFAULTS.codeOpacity) }));
    $('bgCustomImageInput')?.addEventListener('change', async e => {
      const file = e.target.files && e.target.files[0];
      if (!file) return;
      if (!file.type.startsWith('image/')) { setStatus('FILE KHÔNG PHẢI ẢNH', true); e.target.value = ''; return; }
      if (file.size > 20 * 1024 * 1024) { setStatus('ẢNH TỐI ĐA 20 MB', true); e.target.value = ''; return; }
      const job = ++imageJob;
      setStatus('ĐANG XỬ LÝ ẢNH…');
      try {
        const customImage = await compressImage(file);
        if (job !== imageJob) return;
        settings.customImage = customImage;
        save(); syncControls(); sendSettings();
      } catch (error) {
        setStatus(error.message || 'KHÔNG THỂ TẢI ẢNH', true);
      } finally { e.target.value = ''; }
    });
    $('bgClearImageBtn')?.addEventListener('click', () => commit({ customImage: '' }));
    $('bgResetSettingsBtn')?.addEventListener('click', () => {
      settings = { ...DEFAULTS };
      save(); syncControls(); sendSettings();
    });
    window.addEventListener('message', event => {
      if (event.source !== frame?.contentWindow || !event.data || event.data.type !== 'NEBULA_BACKGROUND_READY') return;
      frameReady = true;
      frame.dataset.nebulaReady = '1';
      sendSettings();
    });
    const flexPauseObserver = new MutationObserver(syncFlexRenderPause);
    flexPauseObserver.observe(document.body, { attributes: true, attributeFilter: ['class'] });
    syncControls();
    sendSettings();
  });
})();
