NEBULA 2048 — BigInt Edition

1. Giữ index.html, animation.js, animation.css và adminpanel.js trong cùng một thư mục.
2. Mở index.html bằng trình duyệt. Không đổi tên hai file animation nếu chưa sửa đường dẫn trong index.html.
3. Bảng Admin chỉ xuất hiện khi adminpanel.js có mặt.

Đợt sửa lỗi:
- Fix renderBoss khi đã hạ hết Boss. Bản cũ cố chuyển Infinity thành BigInt nên dừng khi tải game.
- Dữ liệu localStorage không bị reset bởi bản vá này.

Lưu ý: hãy sao lưu dữ liệu game trước khi thay file nếu tiến trình đang quan trọng.

COLOR AURA UPDATE (2026-10-24)
- Aura and animated multicolor tile-face gradient begin at 2048; values below 2048 keep their normal tile styling.
- Aura has 30 tiers. Every doubling raises the tier and increases the aura reach, glow strength, and motion speed.
- Additional layers unlock progressively: star dust (tier 3), energy rings (5), cosmic rays (7), orbiting plasma nodes (9), nebula flare (11), singularity ring (15), quantum ripple (20), and apotheosis flare (25).
- At tier 30 the strongest aura layer is active; the tile value is still handled as BigInt and visual tiers are calculated from its exponent.
- Reduced-motion preferences are respected. Game logic, BigInt number handling, save schema, and optional adminpanel.js loading are unchanged.

ANIMATION MODULES
- animation.css: toàn bộ CSS aura, keyframes và các lớp hiệu ứng. Thêm/chỉnh kiểu hiển thị ở đây.
- animation.js: logic cấp aura, bảng màu, ngưỡng mở khóa hiệu ứng và HTML các lớp hiệu ứng. Thêm cấp/lớp mới ở đây.
- 2048 mở khóa aura cấp 1; mỗi lần giá trị ô tăng gấp đôi thì cấp aura tăng một, tối đa cấp 30.
- Chạy test từ thư mục game bằng: node nebula2048.test.js

COSMIC BACKGROUND UPDATE (2026-10-24)
- Added a lightweight animated Canvas 2D backdrop inspired by MinhDz-Eight_Trigrams: shader-like code streams, multicolor cosmic dust, and slow rotating Bagua/orbital rings.
- The background sits behind the game UI, ignores pointer input, and does not require Three.js or any external library.
- Existing Effects setting controls its intensity: Low reduces it, Standard is balanced, Max increases density/glow, Off hides it.
- Background effects are implemented in animation.js and styled in animation.css; game logic and save data are unchanged.


BINARY AURA UPDATE (2026-10-24)
- Each aura-enabled tile emits glowing binary-code streams reading 01010011001.
- Binary visual effects unlock in separate ranks rather than bundling all code effects at 1M: 2048+ = rank 1 / one effect; 1M+ = rank 2 / two effects; 1B+ = rank 3 / four effects; 1T+ = rank 4 / six effects; 1Qa+ = rank 5 / eight effects.
- The extra layers unlock gradually: orbital binary ring (rank 2), digital rain + pulse ring (rank 3), flying bit fragments + glyphs (rank 4), circuit frame + binary core (rank 5).
- Higher ranks continue increasing stream count (up to 28), spread distance, glow, and motion; the eight distinct effect layers are retained and strengthen at higher values.
- Effects Off hides tile aura layers, Low reduces their intensity, and reduced-motion preference disables the animation loop.
- No external assets or libraries are required.
