/* Offline regression tests for NEBULA 2048's persistent BigInt rules. Run: node nebula2048.test.js */
'use strict';
const fs = require('fs');
const assert = require('assert');
const source = fs.readFileSync('index.html', 'utf8');
const animation = fs.readFileSync('animation.js', 'utf8');
const animationCss = fs.readFileSync('animation.css', 'utf8');
const suffixes = [null, 'K', 'M', 'B', 'T', 'Qa', 'Qi', 'Sx', 'Sp', 'Oc', 'No', 'De', 'Ud', 'Dd', 'Td', 'Qad', 'Qid', 'Sxd', 'Spd', 'Ocd', 'Nod', 'Vig', 'Uv', 'Dv', 'Tv', 'Qav', 'Qiv', 'Sxv', 'Spv', 'Ocv', 'Nov', 'Tri', 'Utr', 'Dtr', 'Ttr', 'Qatr', 'Qitr', 'Sxtr', 'Sptr', 'Octr', 'Notr', 'Qag', 'Uqa', 'Dqa', 'Tqa', 'Qaqa', 'Qiqa', 'Sxqa', 'Spqa', 'Ocqa', 'Noqa', 'Qig', 'Uqi', 'Dqi', 'Tqi', 'Qaqi', 'Qiqi', 'Sxqi', 'Spqi', 'Ocqi', 'Noqi', 'Sex', 'Use', 'Dse', 'Tse', 'Qase', 'Qise', 'Sxse', 'Spse', 'Ocse', 'Nose', 'Sep', 'Usp', 'Dsp', 'Tsp', 'Qasp', 'Qisp', 'Spsp', 'Ocsp', 'Nosp', 'Oct', 'Uoc', 'Doc', 'Toc', 'Qaoc', 'Qioc', 'Sxoc', 'Spoc', 'Ococ', 'Nooc', 'Non', 'Unn', 'Dnn', 'Tnn', 'Qann', 'Qinn', 'Sxnn', 'Spnn', 'Ocnn', 'Nonn', 'Cen', 'Uc'];
function format(n) { const text = BigInt(n).toString(); if (n < 1000n) return text; const e = Math.floor((text.length - 1) / 3) * 3; const s = suffixes[e / 3]; return s && e <= 306 ? `${text.slice(0, text.length - e)}${s}` : `${text[0]}.${text.slice(1, 3).padEnd(2, '0')}e${text.length - 1}`; }
function sale(count) { return 1n << BigInt(Math.max(0, count - 1)); }
function prestige(count) { return 1000n << BigInt(count); }

// Fresh state and legacy-save migration fields are defined in production code.
assert.match(source, /schemaVersion:\s*4/);
assert.match(source, /function migrateSave/);
assert.match(source, /preserveExistingSave/);
// Invalid import parsing must be guarded and backup must remain present.
assert.match(source, /Khôi phục thất bại/);
assert.match(source, /BACKUP_STORAGE_KEY/);
// BigInt merge and values above Number.MAX_VALUE stay exact.
const huge = (2n ** 2048n) * 2n;
assert.equal(huge, 2n ** 2049n);
assert.equal(format(1000n), '1K');
assert.equal(format(10n ** 303n).endsWith('Uc'), true);
assert.equal(format(10n ** 400n), '1.00e400');
// Prestige economy through thousands of rebirths has no floating point ceiling.
assert.equal(sale(0), 1n); assert.equal(sale(1), 1n); assert.equal(sale(2), 2n); assert.equal(sale(7), 64n);
assert.equal(prestige(0), 1000n); assert.equal(prestige(1), 2000n); assert.equal(prestige(1000), 1000n << 1000n);
// Endless Boss threshold remains a valid integer after named Bosses are exhausted.
assert.equal(1024n << 7n, 131072n);
assert.match(source, /Boss Vô Tận/);
assert.match(source, /hp:\s*asBigInt/);
assert.match(animation, /const ultra = n >= 2048n;/);
assert.match(animation, /const auraTier = ultra \? Math\.max\(1, Math\.min\(30, exponent - 10\)\) : 0;/);
assert.match(animation, /const binaryLevel = !ultra \? 0 : n < 1_000_000n \? 1/);
assert.match(animation, /const binaryEffectCount = binaryLevel === 0 \? 0 : binaryLevel === 1 \? 1 : Math\.min\(8, \(binaryLevel - 1\) \* 2\)/);
assert.match(animation, /auraTier >= 25 \? '<span class="aura-extra aura-apotheosis"><\/span>'/);
assert.match(animation, /binaryEffectCount >= 8 \? 'aura-binary-circuit-on aura-binary-core-on'/);
assert.match(animation, /--aura-glow-far/);
assert.match(animationCss, /\.cell\.aura-apotheosis-on \.aura-apotheosis/);
assert.match(animation, /auraTier >= 20 \? 'aura-quantum-on' : ''/);
assert.match(animation, /--aura-slow-speed/);
assert.match(animation, /class=\"aura-extra aura-binary\"/);
assert.match(animation, /01010011001/);
assert.match(animation, /--binary-distance/);
assert.match(animationCss, /@keyframes binary-code-eject/);
assert.match(animationCss, /\.cell\.aura-binary-on \.aura-binary/);
assert.match(animationCss, /body\.effects-off \.cell\.has-aura \.aura-extra/);
assert.match(source, /href="animation.css"/);
assert.match(source, /src="animation.js"/);
assert.match(animationCss, /@keyframes tile-aura-spin/);
assert.match(animationCss, /aura-quantum/);
// Exercise tier boundaries in the actual separated animation module.
const vm = require('vm');
const animationContext = { window: {} };
vm.runInNewContext(animation, animationContext);
const meta = animationContext.window.NebulaAnimation.tileVisualMeta;
assert.equal(meta(1024n).auraTier, 0);
assert.equal(meta(2048n).auraTier, 1);
assert.equal(meta(2048n).binaryLevel, 1);
assert.equal(meta(2048n).binaryEffectCount, 1);
assert.equal(meta(2048n).extras.includes('01010011001'), true);
assert.equal(meta(2048n).extras.includes('aura-binary'), true);
assert.equal((meta(2048n).extras.match(/class="binary-stream"/g) || []).length, 4);
const oneM = meta(1_000_000n);
assert.equal(oneM.binaryLevel, 2);
assert.equal(oneM.binaryEffectCount, 2);
assert.equal(oneM.extras.includes('aura-binary-orbit'), true);
assert.equal(oneM.extras.includes('aura-binary-rain'), false);
assert.equal((oneM.extras.match(/class="binary-stream"/g) || []).length, 6);
const oneB = meta(1_000_000_000n);
assert.equal(oneB.binaryLevel, 3);
assert.equal(oneB.binaryEffectCount, 4);
assert.equal(oneB.extras.includes('aura-binary-orbit'), true);
assert.equal(oneB.extras.includes('aura-binary-rain'), true);
assert.equal(oneB.extras.includes('aura-binary-pulse'), true);
assert.equal((oneB.extras.match(/class="binary-stream"/g) || []).length, 8);
const oneT = meta(1_000_000_000_000n);
assert.equal(oneT.binaryLevel, 4);
assert.equal(oneT.binaryEffectCount, 6);
assert.equal(oneT.extras.includes('aura-binary-fragments'), true);
assert.equal(oneT.extras.includes('aura-binary-glyphs'), true);
const oneQa = meta(1_000_000_000_000_000n);
assert.equal(oneQa.binaryLevel, 5);
assert.equal(oneQa.binaryEffectCount, 8);
assert.equal(oneQa.extras.includes('aura-binary-circuit'), true);
assert.equal(oneQa.extras.includes('aura-binary-core'), true);
assert.equal(meta(4096n).auraTier, 2);
assert.equal(meta(2n ** 40n).auraTier, 30);
assert.equal(meta(10n ** 90n).binaryEffectCount, 8);
assert.equal((meta(10n ** 90n).extras.match(/class="binary-stream"/g) || []).length, 28);
// Atomic rebirth, achievements, quests, settings and optional admin support remain wired in.
assert.match(source, /const rollback = deepCopy\(game\)/);
assert.match(source, /const ACHIEVEMENTS/); assert.match(source, /const QUESTS/); assert.match(source, /const EQUIPMENT/);
assert.match(source, /adminpanel\.js/);
console.log('NEBULA 2048 BigInt, save, prestige, endless Boss, and meta-system regression tests passed.');
