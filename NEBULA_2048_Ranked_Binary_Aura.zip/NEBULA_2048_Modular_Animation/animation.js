/* NEBULA 2048 — aura tier logic, separated from the game engine. */
(function (global) {
  'use strict';

  function toBigInt(value) {
    try {
      if (typeof value === 'bigint') return value;
      if (value == null || value === '') return 0n;
      return BigInt(value);
    } catch (_) {
      return 0n;
    }
  }

  function binaryExponent(value) {
    const n = toBigInt(value);
    return n > 0n ? n.toString(2).length - 1 : 0;
  }

  // 2048 unlocks tier 1. Every doubling adds one tier, capped at tier 30.
  // Add new unlockable visual layers in this module without touching the game engine.
  function tileVisualMeta(value) {
    const n = toBigInt(value);
    const exponent = binaryExponent(n);
    const cycle = exponent % 360;
    const hue1 = (cycle * 41 + 197) % 360;
    const hue2 = (hue1 + 68 + (cycle % 5) * 7) % 360;
    const hue3 = (hue1 + 157 + (cycle % 7) * 5) % 360;
    const hue4 = (hue1 + 238 + (cycle % 3) * 11) % 360;
    const hue5 = (hue1 + 304) % 360;
    const ultra = n >= 2048n;
    const auraTier = ultra ? Math.max(1, Math.min(30, exponent - 10)) : 0;
    const auraOpacity = auraTier ? Math.min(.94, .27 + auraTier * .022) : 0;
    const auraOpacityBorder = auraOpacity * .8;
    const auraOpacityMid = auraOpacity * .55;
    const auraOpacityFar = auraOpacity * .25;
    const auraBlur = auraTier ? Math.min(23, 3 + auraTier * .66) : 0;
    const auraExpand = auraTier ? Math.min(45, 3 + auraTier * 1.4) : 0;
    const auraGlow = auraTier ? Math.min(190, 12 + auraTier * 5.2) : 0;
    const auraGlowMid = auraGlow * 1.7;
    const auraGlowFar = auraGlow * 2.4;
    const auraSpeed = auraTier ? Math.max(1.25, 7.6 - auraTier * .19) : 7.6;
    const auraBreatheSpeed = auraTier ? Math.max(.72, 2.9 - auraTier * .065) : 2.9;
    const auraFastSpeed = Math.max(.9, auraSpeed * .76);
    const auraSlowSpeed = Math.max(1.4, auraSpeed * 1.4);
    const auraVerySlowSpeed = Math.max(2, auraSpeed * 1.8);
    const auraQuantumSpeed = Math.max(2.5, auraSpeed * 2.2);
    // Binary-code effects are unlocked in distinct magnitude bands, not all at once.
    // 2048+ = rank 1; >=1M = rank 2 / 2 effects; >=1B = rank 3 / 4 effects.
    // Each further 1,000x magnitude adds another rank and two visual layers up to 8.
    const binaryLevel = !ultra ? 0 : n < 1_000_000n ? 1 : Math.min(99, 2 + Math.floor((n.toString().length - 7) / 3));
    const binaryEffectCount = binaryLevel === 0 ? 0 : binaryLevel === 1 ? 1 : Math.min(8, (binaryLevel - 1) * 2);
    const binaryCount = binaryLevel ? Math.min(28, 4 + (binaryLevel - 1) * 2) : 0;
    const binaryDistance = binaryLevel ? Math.min(180, 38 + (binaryLevel - 1) * 8) : 38;
    const binarySpeed = binaryLevel ? Math.max(1.05, 3.4 - (binaryLevel - 1) * .16) : 3.4;
    const binaryOpacity = binaryLevel ? Math.min(.98, .58 + (binaryLevel - 1) * .035) : .58;
    const binaryStreams = binaryLevel ? Array.from({ length: binaryCount }, (_, i) => {
      const angle = Math.round((360 / binaryCount) * i + binaryLevel * 7) % 360;
      const delay = -((i / binaryCount) * binarySpeed).toFixed(2);
      return `<span class="binary-stream" style="--binary-angle:${angle}deg;--binary-delay:${delay}s">01010011001</span>`;
    }).join('') : '';
    const binaryExtra = binaryLevel ? `<span class="aura-extra aura-binary" aria-hidden="true">${binaryStreams}</span>` : '';
    const binaryLayers = [
      binaryEffectCount >= 2 ? '<span class="aura-extra aura-binary-orbit"></span>' : '',
      binaryEffectCount >= 4 ? '<span class="aura-extra aura-binary-rain"></span>' : '',
      binaryEffectCount >= 4 ? '<span class="aura-extra aura-binary-pulse"></span>' : '',
      binaryEffectCount >= 6 ? '<span class="aura-extra aura-binary-fragments"></span>' : '',
      binaryEffectCount >= 6 ? '<span class="aura-extra aura-binary-glyphs"></span>' : '',
      binaryEffectCount >= 8 ? '<span class="aura-extra aura-binary-circuit"></span>' : '',
      binaryEffectCount >= 8 ? '<span class="aura-extra aura-binary-core"></span>' : ''
    ].filter(Boolean).join('');
    const extras = binaryExtra + binaryLayers
      + (auraTier >= 3 ? '<span class="aura-extra aura-stars"></span>' : '')
      + (auraTier >= 5 ? '<span class="aura-extra aura-rings"></span>' : '')
      + (auraTier >= 7 ? '<span class="aura-extra aura-rays"></span>' : '')
      + (auraTier >= 9 ? '<span class="aura-extra aura-orbs"></span>' : '')
      + (auraTier >= 11 ? '<span class="aura-extra aura-flare"></span>' : '')
      + (auraTier >= 15 ? '<span class="aura-extra aura-singularity"></span>' : '')
      + (auraTier >= 20 ? '<span class="aura-extra aura-quantum"></span>' : '')
      + (auraTier >= 25 ? '<span class="aura-extra aura-apotheosis"></span>' : '');
    const style = `--tile-hue:${hue1};--tile-hue2:${hue2};--tile-hue3:${hue3};--tile-hue4:${hue4};--tile-hue5:${hue5};--aura-opacity:${auraOpacity};--aura-opacity-border:${auraOpacityBorder};--aura-opacity-mid:${auraOpacityMid};--aura-opacity-far:${auraOpacityFar};--aura-blur:${auraBlur}px;--aura-expand:${auraExpand}%;--aura-inset:-${auraExpand}%;--aura-glow:${auraGlow}px;--aura-glow-mid:${auraGlowMid}px;--aura-glow-far:${auraGlowFar}px;--aura-speed:${auraSpeed}s;--aura-fast-speed:${auraFastSpeed}s;--aura-slow-speed:${auraSlowSpeed}s;--aura-very-slow-speed:${auraVerySlowSpeed}s;--aura-quantum-speed:${auraQuantumSpeed}s;--aura-breathe-speed:${auraBreatheSpeed}s;--binary-distance:${binaryDistance}px;--binary-speed:${binarySpeed}s;--binary-opacity:${binaryOpacity};--binary-level:${binaryLevel};--binary-effect-count:${binaryEffectCount};`;
    const effectClasses = [
      binaryLevel >= 1 ? 'aura-binary-on' : '',
      binaryEffectCount >= 2 ? 'aura-binary-orbit-on' : '',
      binaryEffectCount >= 4 ? 'aura-binary-rain-on aura-binary-pulse-on' : '',
      binaryEffectCount >= 6 ? 'aura-binary-fragments-on aura-binary-glyphs-on' : '',
      binaryEffectCount >= 8 ? 'aura-binary-circuit-on aura-binary-core-on' : '',
      auraTier >= 3 ? 'aura-stars-on' : '',
      auraTier >= 5 ? 'aura-rings-on' : '',
      auraTier >= 7 ? 'aura-rays-on' : '',
      auraTier >= 9 ? 'aura-orbs-on' : '',
      auraTier >= 11 ? 'aura-flare-on' : '',
      auraTier >= 15 ? 'aura-singularity-on' : '',
      auraTier >= 20 ? 'aura-quantum-on' : '',
      auraTier >= 25 ? 'aura-apotheosis-on' : ''
    ].filter(Boolean).join(' ');
    return { ultra, auraTier, binaryLevel, binaryEffectCount, auraClass: auraTier ? `has-aura aura-tier-${auraTier} ${effectClasses}` : '', style, extras };
  }

  global.NebulaAnimation = Object.freeze({ tileVisualMeta, binaryExponent });
})(window);


/* NEBULA Cosmic Background FX — inspired by the reference project's cyber-code,
   cosmic stardust, and rotating Bagua/orbital visuals. Lightweight Canvas 2D,
   deliberately kept behind the interface and independent from game logic. */
(function (global) {
  'use strict';

  function startCosmicBackground() {
    if (!document.body || document.getElementById('nebula-cosmic-background')) return;
    const canvas = document.createElement('canvas');
    canvas.id = 'nebula-cosmic-background';
    canvas.className = 'nebula-cosmic-background';
    canvas.setAttribute('aria-hidden', 'true');
    document.body.insertBefore(canvas, document.body.firstChild);
    const ctx = canvas.getContext('2d', { alpha: true });
    if (!ctx) return;

    const codeLines = [
      '// COSMIC FIELD :: NEBULA_2048',
      'const STAR_DUST = initializeUniverse();',
      'uniform vec3 u_glowColor;',
      'void main(void) { energy += stardust * orbit; }',
      'const ORBITAL_RINGS = ["☰", "☱", "☲", "☳", "☴", "☵", "☶", "☷"];',
      'gl.enable(gl.BLEND); // additive light',
      'const quantum = Math.sin(time * frequency);',
      'particle.position += velocity * deltaTime;',
      'if (auraTier >= 25) return APOTHEOSIS;',
      'precision highp float; // stellar shader',
      'const SINGULARITY = { spin: 0.008, state: "ACTIVE" };',
      'for (const orbit of celestialRings) orbit.precess(time);',
      'gl_FragColor = vec4(cyan, violet, gold, glow);',
      'requestAnimationFrame(renderNebula);',
      '// CÀN KHÔN · VẠN TƯỢNG · STARFIELD',
      'const wavelengths = ["cyan", "violet", "amber"];',
      'particles.forEach(p => p.twinkle(time));',
      'return cosmicFlow.normalize(eventHorizon);',
      'const nebula = new Nebula({ density: adaptive });',
      'shader.orbitAngle += shader.precession * delta;',
      'const entropy = universe.sampleQuantumNoise();',
      'if (mergePower > threshold) emitShockwave();',
      'const color = mix(primary, accent, pulse);',
      'gl.bindBuffer(gl.ARRAY_BUFFER, starBuffer);',
      '// 天地玄黃 · 宇宙洪荒 · 星塵流轉',
      'state = state === "normal" ? "converge" : state;',
      'const gravity = calculateSingularity(mass);',
      'orbit.rotation = mat3(axis, precession, spin);',
      'void updateCosmicField(float time) {',
      '  energyField = smoothstep(0.0, 1.0, pulse);',
      '}'
    ];
    const trigramGlyphs = ['☰', '☱', '☲', '☳', '☴', '☵', '☶', '☷'];
    const colors = ['#66e8f7', '#a99bff', '#8debd0', '#f8ca78', '#ff9fce'];
    let width = 0, height = 0, dpr = 1, particles = [], scrollY = 0;
    let lastFrame = 0, lastTime = 0, animationId = 0;
    const reducedMotion = !!(global.matchMedia && global.matchMedia('(prefers-reduced-motion: reduce)').matches);

    function currentMode() {
      const select = document.getElementById('effectsSetting');
      if (select && select.value) return select.value;
      if (document.body.classList.contains('effects-off')) return 'off';
      if (document.body.classList.contains('effects-low')) return 'low';
      return 'standard';
    }

    function resize() {
      width = Math.max(320, global.innerWidth || 320);
      height = Math.max(320, global.innerHeight || 320);
      dpr = Math.min(global.devicePixelRatio || 1, 1.35);
      canvas.width = Math.round(width * dpr);
      canvas.height = Math.round(height * dpr);
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      const amount = Math.max(55, Math.min(180, Math.round(width * height / 10500)));
      particles = Array.from({ length: amount }, (_, i) => ({
        x: Math.random() * width,
        y: Math.random() * height,
        r: .55 + Math.random() * 1.75,
        vx: (Math.random() - .5) * 6,
        vy: 3 + Math.random() * 11,
        phase: Math.random() * Math.PI * 2,
        speed: .5 + Math.random() * 1.5,
        color: colors[i % colors.length]
      }));
      draw(0, 0);
    }

    function drawNebula(time, intensity) {
      const blobs = [
        { x: .14, y: .2, r: .35, color: `rgba(52, 92, 220, ${.12 * intensity})`, drift: .035 },
        { x: .83, y: .3, r: .3, color: `rgba(0, 210, 220, ${.095 * intensity})`, drift: .045 },
        { x: .72, y: .82, r: .34, color: `rgba(151, 70, 240, ${.095 * intensity})`, drift: .028 },
        { x: .24, y: .78, r: .24, color: `rgba(248, 170, 95, ${.045 * intensity})`, drift: .022 }
      ];
      for (const b of blobs) {
        const x = width * (b.x + Math.sin(time * b.drift) * .035);
        const y = height * (b.y + Math.cos(time * b.drift * 1.3) * .035);
        const radius = Math.max(width, height) * b.r;
        const gradient = ctx.createRadialGradient(x, y, 0, x, y, radius);
        gradient.addColorStop(0, b.color);
        gradient.addColorStop(1, 'rgba(0,0,0,0)');
        ctx.fillStyle = gradient;
        ctx.fillRect(0, 0, width, height);
      }
    }

    function drawOrbitalMandala(time, intensity) {
      const mobile = width < 700;
      const cx = width * (mobile ? .5 : .77);
      const cy = height * (mobile ? .36 : .47);
      const radius = Math.min(width, height) * (mobile ? .235 : .285);
      if (radius < 42) return;
      ctx.save();
      ctx.translate(cx, cy);
      ctx.globalAlpha = .19 * intensity;
      ctx.lineWidth = 1;
      for (let i = 0; i < 5; i++) {
        ctx.save();
        ctx.rotate(time * (.018 + i * .004) * (i % 2 ? -1 : 1) + i * .41);
        ctx.strokeStyle = [colors[0], colors[1], colors[2], colors[3], colors[4]][i];
        ctx.shadowColor = ctx.strokeStyle;
        ctx.shadowBlur = 9 * intensity;
        ctx.beginPath();
        ctx.ellipse(0, 0, radius * (1 + (i % 2) * .16), radius * (.28 + i * .105), 0, 0, Math.PI * 2);
        ctx.stroke();
        ctx.restore();
      }
      ctx.globalAlpha = .16 * intensity;
      ctx.setLineDash([3, 8]);
      ctx.strokeStyle = '#b9e8ff';
      ctx.beginPath();
      ctx.arc(0, 0, radius * .72, -time * .04, Math.PI * 2 - time * .04);
      ctx.stroke();
      ctx.setLineDash([]);
      for (let i = 0; i < 8; i++) {
        const a = i * Math.PI / 4 - time * .025;
        const x = Math.cos(a) * radius * .82;
        const y = Math.sin(a) * radius * .82;
        ctx.save();
        ctx.translate(x, y);
        ctx.rotate(a + Math.PI / 2);
        ctx.fillStyle = i % 2 ? '#9b9dff' : '#8deaf5';
        ctx.globalAlpha = .46 * intensity;
        ctx.font = `bold ${Math.max(10, radius * .095)}px serif`;
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText(trigramGlyphs[i], 0, 0);
        ctx.restore();
      }
      ctx.globalAlpha = .26 * intensity;
      ctx.fillStyle = '#c3f8ff';
      ctx.shadowColor = '#66e8f7';
      ctx.shadowBlur = 16 * intensity;
      ctx.font = ` ${Math.max(34, radius * .36)}px serif`;
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText('☯', 0, 0);
      ctx.restore();
    }

    function drawCode(time, intensity) {
      const lineHeight = width < 650 ? 19 : 23;
      const fontSize = width < 650 ? 10 : 12;
      const totalHeight = codeLines.length * lineHeight;
      const offset = (scrollY % totalHeight);
      ctx.save();
      ctx.font = `${fontSize}px Consolas, "Courier New", monospace`;
      ctx.textBaseline = 'top';
      for (let block = -1; block <= Math.ceil(height / totalHeight) + 1; block++) {
        for (let i = 0; i < codeLines.length; i++) {
          const y = block * totalHeight + i * lineHeight - offset;
          if (y < -lineHeight || y > height + lineHeight) continue;
          const line = codeLines[i];
          if (line.trim().startsWith('//')) ctx.fillStyle = `rgba(125, 220, 155, ${.46 * intensity})`;
          else if (/uniform|void|const|for \(/.test(line)) ctx.fillStyle = `rgba(103, 183, 255, ${.54 * intensity})`;
          else if (/gl\.|shader|orbit/.test(line)) ctx.fillStyle = `rgba(92, 234, 214, ${.5 * intensity})`;
          else ctx.fillStyle = `rgba(205, 224, 255, ${.37 * intensity})`;
          ctx.fillText(String(i + 1).padStart(2, '0') + '  |  ' + line, 18, y, width - 30);
        }
      }
      ctx.restore();
    }

    function drawParticles(delta, time, intensity, countScale) {
      const count = Math.max(28, Math.floor(particles.length * countScale));
      for (let i = 0; i < count; i++) {
        const p = particles[i];
        if (!reducedMotion) {
          p.x += p.vx * delta;
          p.y += p.vy * delta;
          if (p.y > height + 12) { p.y = -12; p.x = Math.random() * width; }
          if (p.x < -12) p.x = width + 12;
          if (p.x > width + 12) p.x = -12;
        }
        const twinkle = .38 + (Math.sin(time * p.speed + p.phase) + 1) * .31;
        const alpha = twinkle * intensity * .7;
        ctx.save();
        ctx.globalAlpha = alpha;
        ctx.fillStyle = p.color;
        ctx.shadowColor = p.color;
        ctx.shadowBlur = p.r * 5 * intensity;
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
        ctx.fill();
        if (i % 8 === 0) {
          ctx.globalAlpha = alpha * .45;
          ctx.strokeStyle = p.color;
          ctx.lineWidth = .7;
          ctx.beginPath();
          ctx.moveTo(p.x, p.y);
          ctx.lineTo(p.x - p.vx * 1.5, p.y - p.vy * 1.2);
          ctx.stroke();
        }
        ctx.restore();
      }
      // Sparse links create the same airy, orbital field as the reference's 3D dust.
      const linkCount = Math.min(count, 90);
      for (let i = 0; i < linkCount; i++) {
        const a = particles[i];
        for (let j = i + 1; j < Math.min(i + 5, linkCount); j++) {
          const b = particles[j];
          const dx = a.x - b.x, dy = a.y - b.y;
          const distance = Math.sqrt(dx * dx + dy * dy);
          if (distance < 95) {
            ctx.strokeStyle = `rgba(101, 202, 255, ${(1 - distance / 95) * .07 * intensity})`;
            ctx.lineWidth = .6;
            ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.lineTo(b.x, b.y); ctx.stroke();
          }
        }
      }
    }

    function draw(timestamp, deltaSeconds) {
      const mode = currentMode();
      ctx.clearRect(0, 0, width, height);
      if (mode === 'off') return;
      const intensity = mode === 'max' ? 1.35 : mode === 'low' ? .42 : .82;
      const countScale = mode === 'max' ? 1 : mode === 'low' ? .38 : .68;
      const time = timestamp / 1000;
      drawNebula(time, intensity);
      drawOrbitalMandala(time, intensity);
      drawParticles(deltaSeconds, time, intensity, countScale);
      drawCode(time, mode === 'max' ? .29 : mode === 'low' ? .075 : .15);
      // Soft vignette keeps the edges atmospheric without affecting contrast of game panels.
      const vignette = ctx.createRadialGradient(width * .5, height * .43, Math.min(width, height) * .16, width * .5, height * .43, Math.max(width, height) * .78);
      vignette.addColorStop(0, 'rgba(1, 4, 12, 0)');
      vignette.addColorStop(1, `rgba(1, 3, 10, ${mode === 'max' ? .08 : .13})`);
      ctx.fillStyle = vignette;
      ctx.fillRect(0, 0, width, height);
    }

    function animate(timestamp) {
      animationId = global.requestAnimationFrame(animate);
      if (timestamp - lastFrame < 30) return; // Cap the background at ~33 FPS.
      const delta = lastTime ? Math.min((timestamp - lastTime) / 1000, .06) : .03;
      lastFrame = timestamp;
      lastTime = timestamp;
      if (!reducedMotion) scrollY += 7 * delta;
      draw(timestamp, reducedMotion ? 0 : delta);
    }

    global.addEventListener('resize', resize, { passive: true });
    resize();
    if (reducedMotion) draw(0, 0);
    else animationId = global.requestAnimationFrame(animate);
    // Keep a handle available for diagnostics / future effect modules.
    global.NebulaBackgroundFX = Object.freeze({ canvas, resize, redraw: () => draw(performance.now(), 0), stop: () => global.cancelAnimationFrame(animationId) });
  }

  if (typeof document !== 'undefined') {
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', startCosmicBackground, { once: true });
    } else {
      startCosmicBackground();
    }
  }
})(window);
